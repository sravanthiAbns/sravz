﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class AspDay1second : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string mail = "";
            string prod = "";
            if (!Page.IsPostBack)
            {
                if (Request.QueryString.Count == 2)
                {
                    prod = Request.QueryString[0];
                    mail = Request.QueryString[1];
                }
                Label1.Text = "Thanks for purchasing" + prod + "you will get an emnail on ur email id" + mail;
            }
        }
    }
}