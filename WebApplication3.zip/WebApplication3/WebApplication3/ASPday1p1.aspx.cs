﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class ASPday1p1 : System.Web.UI.Page
    {

        List<GST> gstlist = null;


        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                gstlist = new List<GST> {
                   new GST {SlabName="Food Items",TaxRate=5 },
                   new GST {SlabName="Electronic Items",TaxRate=12 },
                   new GST {SlabName="Automobile Items",TaxRate=18 },

            };
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add(new ListItem("Select a slab", "0"));
                DropDownList1.AppendDataBoundItems = true;

                DropDownList1.DataSource = gstlist;

                DropDownList1.DataTextField = "SlabName";
                DropDownList1.DataValueField = "TaxRate";

                DropDownList1.DataBind();
            }
            //else
            //{
            //    Label1.Text = "Info from Server";
            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (Convert.ToInt32(DropDownList1.SelectedItem.Value) > 0 && (DropDownList2.SelectedIndex) > 0)
            {
                // Label1.Text = "Welcome to ASp.Net";
                double taxrate = Convert.ToDouble(DropDownList1.SelectedItem.Value);
                double gstAmount = 0.0;
                gstAmount = Convert.ToDouble(TextBox1.Text) + (Convert.ToDouble(TextBox1.Text) * taxrate) / 100;
                Label1.Text = DropDownList2.SelectedItem.Text + "(" + DropDownList1.SelectedItem.Text + ")" + "purchased for amount" + gstAmount.ToString();

            }
        }

       

        protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
        {

            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("Select a product");
            // Label1.Text = DropDownList1.SelectedItem.Value + "-" +DropDownList1.SelectedItem.Text;
            switch (Convert.ToInt32(DropDownList1.SelectedItem.Value))
            {
                case 5:
                    DropDownList2.Items.Add("Pizza");
                    DropDownList2.Items.Add("Burger");
                    DropDownList2.Items.Add("Coffee");
                    break;
                case 12:
                    DropDownList2.Items.Add("LED TV");
                    DropDownList2.Items.Add("Lappy");
                    DropDownList2.Items.Add("Monbile");
                    break;

                case 18:
                    DropDownList2.Items.Add("car");
                    DropDownList2.Items.Add("Bike");
                    DropDownList2.Items.Add("Phone");
                    break;

            }

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ASPDay1second.aspx");
        }
    }
}