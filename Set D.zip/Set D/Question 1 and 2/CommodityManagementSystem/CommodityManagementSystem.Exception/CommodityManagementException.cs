﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommodityManagementSystem.Exceptions
{
    public class CommodityManagementException:ApplicationException
    {
        public CommodityManagementException()
        {

        }

        public CommodityManagementException(string message):base(message)
        {

        }

        public CommodityManagementException(string message, Exception innerException):base(message,innerException)
        {

        }
    }
}
