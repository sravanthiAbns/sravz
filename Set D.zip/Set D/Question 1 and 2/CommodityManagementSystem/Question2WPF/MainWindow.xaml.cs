﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        ExamEntities context = new ExamEntities();
        static int slabperc;
        public MainWindow()
        {
            InitializeComponent();
           List<string> dataList = (from slab in context.GST_TaxSlab_EmployeeId
                                    select slab.SlabName).ToList();

            comboSlabName.ItemsSource = dataList;
        }

        private void comboSlabName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            txtCommodityId.Visibility = Visibility.Visible;
            txtCommodityName.Visibility = Visibility.Visible;
            txtDescription.Visibility = Visibility.Visible;
            txtPrice.Visibility = Visibility.Visible;
            lblSlabPercentage.Visibility = Visibility.Visible;
            label.Visibility = Visibility.Visible;
            label1.Visibility = Visibility.Visible;
            label2.Visibility = Visibility.Visible;
            label3.Visibility = Visibility.Visible;
            label4.Visibility = Visibility.Visible;

            string slabname = comboSlabName.SelectedItem.ToString();
             slabperc = (from slab in context.GST_TaxSlab_EmployeeId
                           where slab.SlabName.Equals(slabname)
                           select slab.SlabPercentage).FirstOrDefault();
            
            lblSlabPercentage.Content = "The tax percentage is " + slabperc;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            int commId = Convert.ToInt32(txtCommodityId.Text);

            var tobeUpdated =
                (from slab in context.Commodity_EmployeeId
                 where slab.CommodityId==commId
                 select slab).FirstOrDefault();

            tobeUpdated.CommodityName = txtCommodityName.Text;
            tobeUpdated.Description = txtDescription.Text;
            tobeUpdated.UnitPrice= Convert.ToInt32(txtPrice.Text);
            tobeUpdated.GST = Convert.ToDecimal(calculateGST(tobeUpdated.UnitPrice));

            context.SaveChanges();
        }

        public double calculateGST(int unitPrice)
        {
            double calculatedgst = ((double)slabperc / 100) * unitPrice;

            return calculatedgst;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            int slabId = Convert.ToInt32(txtCommodityId.Text);

            Commodity_EmployeeId tobeUpdated =
                (from slab in context.Commodity_EmployeeId
                 
                 select slab).FirstOrDefault();

            txtCommodityName.Text=tobeUpdated.CommodityName ;
            txtDescription.Text = tobeUpdated.Description;
            txtPrice.Text=  Convert.ToString(tobeUpdated.UnitPrice);
            

           
        }
    }
}
