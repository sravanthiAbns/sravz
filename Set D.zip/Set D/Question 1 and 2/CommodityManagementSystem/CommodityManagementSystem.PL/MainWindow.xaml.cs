﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CommodityManagementSystem.BAL;
using CommodityManagementSystem.Exceptions;
using CommodityManagemntSystem.Entities;

namespace CommodityManagementSystem.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CMSBussinessRules busObj = new CMSBussinessRules();
        static int slabPerc;
        
        public MainWindow()
        {
            InitializeComponent();
            
            List<string> dataList = busObj.getAllSlabNames();
            
            comboSlabName.ItemsSource = dataList;
             
            




        }

     

        private void comboSlabName_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            txtCommodityId.Visibility = Visibility.Visible;
            txtCommodityName.Visibility = Visibility.Visible;
            txtDescription.Visibility = Visibility.Visible;
            txtPrice.Visibility = Visibility.Visible;
            lblSlabPercentage.Visibility = Visibility.Visible;
            label.Visibility = Visibility.Visible;
            label1.Visibility = Visibility.Visible;
            label2.Visibility = Visibility.Visible;
            label3.Visibility = Visibility.Visible;
            label4.Visibility = Visibility.Visible;
            btnAddCommodity.Visibility = Visibility.Visible;
            btnCalculateGST.Visibility = Visibility.Visible;
            slabPerc = busObj.getSlabPercentage(comboSlabName.SelectedItem.ToString());
            lblSlabPercentage.Content = "The tax percentage is " + slabPerc;
            
            
            
        }

        private void btnCalculateGST_Click(object sender, RoutedEventArgs e)
        {
            
            CMSBussinessRules busObj = new CMSBussinessRules();
            int uprice = Convert.ToInt32(txtPrice.Text);

            double calculatedgst = calculateGST(uprice);
            MessageBox.Show("Unit Price: " + uprice + "\n" + "Tax Percentage: " + slabPerc + "\n" + "GST: " + calculatedgst);
        }

        private void btnAddCommodity_Click(object sender, RoutedEventArgs e)
        {
            CMSBussinessRules busObj = new CMSBussinessRules();
            CommodityEntity newCommodity = new CommodityEntity();
            newCommodity.CommodityId = Convert.ToInt32(txtCommodityId.Text);
            newCommodity.CommodityName = txtCommodityName.Text;
            newCommodity.Description = txtDescription.Text;
            newCommodity.UnitPrice = Convert.ToInt32(txtPrice.Text);
            newCommodity.GST = calculateGST(newCommodity.UnitPrice);


            bool panAdded = busObj.addCommdity(newCommodity,comboSlabName.Text);
            if (panAdded)
                MessageBox.Show("Commodity Added Successfully");
            else
                MessageBox.Show("Commodity not Added");

        }

        public double calculateGST(int unitPrice)
        {
            double calculatedgst = ((double)slabPerc /100)* unitPrice;

            return calculatedgst;
        }

     
    }
}
