﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommodityManagementSystem.DAL;
using CommodityManagemntSystem.Entities;
using CommodityManagementSystem.Exceptions;

namespace CommodityManagementSystem.BAL
{
    public class CMSBussinessRules
    {
        public List<string> getAllSlabNames()
        {
            DataAccess dataObj = new DataAccess();
            return dataObj.getAllSlabNamesDL();
        }

        public int getSlabPercentage(string slabName)
        {
            DataAccess dataObj = new DataAccess();
            return dataObj.getSlabPercentageDL(slabName);
        }

        public bool addCommdity(CommodityEntity newCommodity, string slabName)
        {
            if(ValidateALL(newCommodity))
            {
                DataAccess dataObj = new DataAccess();
                return dataObj.addCommdityDL(newCommodity, slabName);
            }
            else
            {
                
                throw new CommodityManagementException("Validation Error");
                
            }
            

        }

        private bool ValidateALL(CommodityEntity newComm)
        {
            try
            {
                if (newComm.CommodityName.Equals(" ") || newComm.Description.Equals(" "))
                {
                    return false;
                }
                else if (newComm.UnitPrice <= 30 || newComm.GST <= 0)
                    return false;
            }
            catch(Exception)
            {
                throw new CommodityManagementException("Validation Error");
            }
            return true;
        }
    }
}
