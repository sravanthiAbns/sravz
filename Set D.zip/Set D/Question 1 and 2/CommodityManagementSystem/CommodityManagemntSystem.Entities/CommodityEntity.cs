﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommodityManagemntSystem.Entities
{
    public class CommodityEntity
    {
        public int CommodityId { get; set; }
        public string CommodityName { get; set; }
        public string Description { get; set; }
        public int UnitPrice { get; set; }
        public double GST { get; set; }
        public int SlabId { get; set; }
    }
}
