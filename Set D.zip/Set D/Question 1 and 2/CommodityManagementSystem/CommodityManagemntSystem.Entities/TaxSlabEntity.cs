﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommodityManagemntSystem.Entities
{
    public class TaxSlabEntity
    {
        public int SlabId { get; set; }
        public string SlabName { get; set; }
        public int SlabPercentage { get; set; }

       
    }
}
