﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommodityManagemntSystem.Entities;
using CommodityManagementSystem.Exceptions;
using System.Data.Common;
using System.Data;

namespace CommodityManagementSystem.DAL
{
    public class DataAccess
    {

        public  List<string> getAllSlabNamesDL()
        {
            List<string> dataList = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetTaxSlabs";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    dataList = new List<string>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        TaxSlabEntity slabNames = new TaxSlabEntity();
                        //slabNames.SlabId = Convert.ToInt32(dataTable.Rows[rowCounter][0]);
                        slabNames.SlabName = (string)dataTable.Rows[rowCounter][0];
                        //slabNames.SlabPercentage = Convert.ToInt32(dataTable.Rows[rowCounter][2]);
                        

                        dataList.Add(slabNames.SlabName);
                    }
                    
                    
                        
                    
                        
                    
                }
            }
            catch (DbException ex)
            {
                throw new CommodityManagementException(ex.Message);
            }
            return dataList;
        }

        //public int getUnitPrice(int commodityId)
        //{
        //    int unitPrice = 0;

        //    try
        //    {
        //        DbCommand command = DataConnection.CreateCommand();
        //        command.CommandText = "getUnitPrice";

        //        DbParameter param = command.CreateParameter();
        //        param.ParameterName = "@comId";
        //        param.DbType = DbType.Int32;
        //        param.Value = commodityId;
        //        command.Parameters.Add(param);

        //        param = command.CreateParameter();
        //        param.ParameterName = "@uprice";
        //        param.DbType = DbType.Int32;
        //        param.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(param);

        //        DataConnection.ExecuteScalarCommand(command);
        //        unitPrice = Convert.ToInt32(param.Value);

        //    }
        //    catch (DbException ex)
        //    {
        //        throw new CommodityManagementException(ex.Message);
        //    }
        //    return unitPrice;
        //}

        public bool addCommdityDL(CommodityEntity newCommodity,string slabName)
        {

            try
            {

                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addNewCommodity";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@commodityId ";
                param.DbType = DbType.Int32;
                param.Value = newCommodity.CommodityId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@commodityName ";
                param.DbType = DbType.String;
                param.Value = newCommodity.CommodityName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Description";
                param.DbType = DbType.String;
                param.Value = newCommodity.Description;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@price";
                param.DbType = DbType.Int32;
                param.Value = newCommodity.UnitPrice;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@GST";
                param.DbType = DbType.Int32;
                param.Value = newCommodity.GST;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@slabName";
                param.DbType = DbType.String;
                param.Value = slabName;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);
                
                if (affectedRows > 0)
                    return true;

            }
            catch (DbException ex)
            {
                throw new CommodityManagementException(ex.Message);
            }
            return false;
        }

        public int getSlabPercentageDL(string slabName)
        {
            int slabPercentage = 0;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetSlabPercentage";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@slabName";
                param.DbType = DbType.String;
                param.Value = slabName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@slabPerc";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                 DataConnection.ExecuteScalarCommand(command);
                slabPercentage = Convert.ToInt32(param.Value);
                
            }
            catch (DbException ex)
            {
                throw new CommodityManagementException(ex.Message);
            }
            return slabPercentage;
        }
    }
}
