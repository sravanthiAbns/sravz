﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace CommodityManagementSystem.DAL
{
    class CommodityManagementConfiguration
    {
        private static string connectionString;
        private static string providerName;

        public static string ConnectionString
        {
            get
            {
                return connectionString;
            }

            set
            {
                connectionString = value;
            }
        }

        public static string ProviderName
        {
            get
            {
                return providerName;
            }

            set
            {
                providerName = value;
            }
        }

        static CommodityManagementConfiguration()
        {
            connectionString = ConfigurationManager.ConnectionStrings["CMSconString"].ConnectionString;
            providerName = ConfigurationManager.ConnectionStrings["CMSconString"].ProviderName;
        }
    }
}
