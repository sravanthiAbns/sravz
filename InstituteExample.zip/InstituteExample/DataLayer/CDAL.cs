﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using InstituteExceptionLayer;
using EntityLayer;

namespace DataLayer
{
    public class CDAL
    {
        public List<string> mGetAllInstitutes()
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            List<string> institutelist = null;
            try
            {
                conn = new SqlConnection("Data Source=.;Initial Catalog=InstituteDatabase;Integrated Security=True");
                command = new SqlCommand("GetAllInstitute",conn);
                command.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader datareader = command.ExecuteReader();
                while(datareader.HasRows)
                {
                    institutelist = new List<string>();
                    while (datareader.Read())
                    {
                        institutelist.Add(datareader[0].ToString());
                    }
                    datareader.NextResult();
                }
            }
            catch (Exception ex)
            {
                throw new InstituteException(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return institutelist;
        }

        public List<string> mGetAllCourses()
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            List<string> courseList = null;
            try
            {
                conn = new SqlConnection("Data Source=.;Initial Catalog=InstituteDatabase;Integrated Security=True");
                command = new SqlCommand("GetAllCourse", conn);
                command.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader datareader = command.ExecuteReader();
                while (datareader.HasRows)
                {
                    courseList = new List<string>();
                    while (datareader.Read())
                    {
                        courseList.Add(datareader[0].ToString());
                    }
                    datareader.NextResult();
                }
            }
            catch (Exception ex)
            {
                throw new InstituteException(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return courseList;
        }
        public CDetailReceipt mAddAdmissionDetails(CFormEntity formobj)
        {
            SqlConnection conn = null;
            SqlCommand command = null;
            CDetailReceipt detailsobj = null;
            try
            {
                conn = new SqlConnection("Data Source=.;Initial Catalog=InstituteDatabase;Integrated Security=True");
                command = new SqlCommand("AdmissionStudent", conn);
                command.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlParameter param = new SqlParameter();

                param.ParameterName = "@admissionid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@studentid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@courseid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@instituteid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@studentname";
                param.DbType = DbType.String;
                param.Value = formobj.STUDENTNAME;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.DateTime;
                param.Value = formobj.DOB;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@coursename";
                param.DbType = DbType.String;
                param.Value = formobj.COURSENAME;
                command.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@institutename";
                param.DbType = DbType.String;
                param.Value = formobj.INSTITUTENAME;
                command.Parameters.Add(param);

                int affectedrows = command.ExecuteNonQuery();
                if(affectedrows>0)
                {
                    detailsobj.ADMISSIONID = Convert.ToInt32(param.Value);
                }
            }
            catch (Exception ex)
            {
                throw new InstituteException(ex.Message);
            }

            return detailsobj;
        }
    }
}
