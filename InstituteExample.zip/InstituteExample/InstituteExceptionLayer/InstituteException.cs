﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstituteExceptionLayer
{
    public class InstituteException: ApplicationException
    {
        public InstituteException() : base()
        {

        }
        public InstituteException(string message) : base(message)
        {

        }
        public InstituteException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
