﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class CBAL
    {
        public static List<string> mGetAllInstitutesBAL()
        {
            return new CDAL().mGetAllInstitutes();
        }
        public static List<string> mGetAllCoursesBAL()
        {
            return new CDAL().mGetAllCourses();
        }
    }
}
