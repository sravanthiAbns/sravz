﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PresentationLayer
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<string> institutelist = CBAL.mGetAllInstitutesBAL();
                foreach (string item in institutelist)
                {
                    DropDownList1.Items.Add(item);
                }

                List<string> courceslist = CBAL.mGetAllCoursesBAL();
                foreach (string item in courceslist)
                {
                    DropDownList2.Items.Add(item);
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}