﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PresentationLayer
{
    public partial class InstitiuteSelection : System.Web.UI.Page
    {
        string _username = "rayed";
        string _password = "rayed";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtboxUsername.Text.Equals(_username) && txtboxPassword.Text.Equals(_password))
            {
                Response.Redirect("Register.aspx");
            }
            else
                ErrorLabel.Text = "Credentials do not match";
        }
    }
}