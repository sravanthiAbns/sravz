﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class CFormEntity
    {
        public string INSTITUTENAME { get; set; }
        public string COURSENAME { get; set; }
        public string STUDENTNAME { get; set; }
        public DateTime DOB { get; set; }
    }
}
