﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class CDetailReceipt
    {
        public int ADMISSIONID { get; set; }
        public int STUDENTID { get; set; }
        public int COURSEID { get; set; }
        public int INSTITUTEID { get; set; }
    }
}
