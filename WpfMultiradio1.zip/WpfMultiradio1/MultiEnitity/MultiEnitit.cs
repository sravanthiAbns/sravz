﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiEnitity
{
    public class MultiEnitit
    {
        public int empID { get; set; }
        public string empname { get; set; }
        public string empgend { get; set; }
        public string emplocation { get; set; }
        public DateTime dateofStart { get; set; }

    }
}
