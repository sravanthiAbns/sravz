﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MultiEnitity;
using MultiExceptions;
using MultiDAL;
using System.Windows;
using System.Windows.Forms;

namespace MultiBAL
{
    public class Multibal
    {
        private static bool Validproject(MultiEnitit pent)
        {
            StringBuilder sb = new StringBuilder();
            bool validproj = true;
            //if (pent.projID <= 0)
            //{
            //    validproj = false;
            //    sb.Append(Environment.NewLine + "Invalid Project ID");
            //}
            if (pent.empname == string.Empty)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "Guest Name Required");
            }
            //if (pent.projBudget < 25000)
            //{
            //    validproj = false;
            //    sb.Append(Environment.NewLine + "budget should be above the limit");
            //}
            if (validproj == false)
                throw new Exceptions(sb.ToString());
            return validproj;

        }
        public static bool AddGuestBL(MultiEnitit newproj)
        {
            bool projAdded = false;
            try
            {
                if (Validproject(newproj))
                {
                    Multidal proj = new Multidal();
                    projAdded = proj.addproj(newproj);
                }
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projAdded;
        }

        public static List<MultiEnitit> GetAllProjBL()
        {
            List<MultiEnitit> projlist = null;
            try
            {
                Multidal projbal = new Multidal();
                projlist = projbal.getAllprojDet();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return projlist;
        }
        public static MultiEnitit SearchprojBL(int searchprojid)
        {
            MultiEnitit searchproj = null;
            try
            {
                Multidal projdAL = new Multidal();
                searchproj = projdAL.SearchProjDAL(searchprojid);
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            return searchproj;

        }
        public static bool UpdateProjBL(MultiEnitit updateproj)
        {
            bool projUpdated = false;
            try
            {
                if (Validproject(updateproj))
                {
                    Multidal guestdAL = new Multidal();
                    projUpdated = guestdAL.UpdateprojDAL(updateproj);
                }
            }
            catch (Exceptions ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projUpdated;
        }

        public static bool DeleteProjBL(int deleteProjID)
        {
            bool projDeleted = false;
            try
            {
                if (deleteProjID > 0)
                {
                    Multidal guestdAL = new Multidal();
                    projDeleted = guestdAL.Delemp(deleteProjID);
                }
                else
                {
                    throw new Exceptions("Invalid Guest ID");
                }
            }
            catch (Exceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projDeleted;
        }


    }
}
