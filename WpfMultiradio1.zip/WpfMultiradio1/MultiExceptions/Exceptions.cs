﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MultiExceptions
{
    public class Exceptions : ApplicationException
    {
        public Exceptions()
            : base()
        {
        }

        public Exceptions(string message)
            : base(message)
        {
        }
        public Exceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
