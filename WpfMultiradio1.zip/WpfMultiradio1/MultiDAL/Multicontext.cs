﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Common;
using System.Data;
using System.Configuration;

namespace MultiDAL
{
    class Multicontext
    {
        private static string providername;

        public static string providerName
        {
            get { return Multicontext.providername; }
            set { Multicontext.providername = value; }
        }
        private static string connectionstring;
        public static string connectionString
        {
            get { return Multicontext.connectionstring; }
            set { Multicontext.connectionstring = value; }
        }

        // use of constructor
        static Multicontext()
        {
            //defined in constructor
            // y only field name but property , meaning of this sentence

            providername = ConfigurationManager.ConnectionStrings["projectConnection"].ProviderName;

            connectionString = ConfigurationManager.ConnectionStrings["projectConnection"].ConnectionString;
        }

    }
}
