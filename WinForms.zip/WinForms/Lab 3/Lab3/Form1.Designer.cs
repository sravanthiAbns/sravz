﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtname = new System.Windows.Forms.Label();
            this.txtbirthdate = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnregistration = new System.Windows.Forms.Button();
            this.imgcal = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).BeginInit();
            this.SuspendLayout();
            // 
            // txtname
            // 
            this.txtname.AutoSize = true;
            this.txtname.Location = new System.Drawing.Point(38, 47);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(35, 13);
            this.txtname.TabIndex = 0;
            this.txtname.Text = "Name";
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.AutoSize = true;
            this.txtbirthdate.Location = new System.Drawing.Point(38, 108);
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.Size = new System.Drawing.Size(54, 13);
            this.txtbirthdate.TabIndex = 1;
            this.txtbirthdate.Text = "Birth Date";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(117, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(114, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 100);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(114, 20);
            this.textBox2.TabIndex = 3;
            // 
            // btnregistration
            // 
            this.btnregistration.Location = new System.Drawing.Point(156, 153);
            this.btnregistration.Name = "btnregistration";
            this.btnregistration.Size = new System.Drawing.Size(75, 23);
            this.btnregistration.TabIndex = 4;
            this.btnregistration.Text = "Register";
            this.btnregistration.UseVisualStyleBackColor = true;
            // 
            // imgcal
            // 
            this.imgcal.Image = ((System.Drawing.Image)(resources.GetObject("imgcal.Image")));
            this.imgcal.Location = new System.Drawing.Point(247, 100);
            this.imgcal.Name = "imgcal";
            this.imgcal.Size = new System.Drawing.Size(50, 42);
            this.imgcal.TabIndex = 5;
            this.imgcal.TabStop = false;
            this.imgcal.Click += new System.EventHandler(this.imgcal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 287);
            this.Controls.Add(this.imgcal);
            this.Controls.Add(this.btnregistration);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtbirthdate);
            this.Controls.Add(this.txtname);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Registration Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtname;
        private System.Windows.Forms.Label txtbirthdate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnregistration;
        private System.Windows.Forms.PictureBox imgcal;
    }
}

