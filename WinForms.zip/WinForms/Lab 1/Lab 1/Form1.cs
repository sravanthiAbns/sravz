﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome " + txtName.Text + " !!!");
        }

        private void btnWelcome_MouseEnter(object sender, EventArgs e)
        {
            //Sender is source of event ie: btnWelcome button
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnWelcome_MouseLeave(object sender, EventArgs e)
        {
            //Sender is source of event ie: btnWelcome button
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnClose.Click += new EventHandler(btnClose_Click);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtName_MouseClick(object sender, MouseEventArgs e)
        {
            TextBox t = sender as TextBox;
            t.BackColor = Color.Yellow;
        }
    }
}
