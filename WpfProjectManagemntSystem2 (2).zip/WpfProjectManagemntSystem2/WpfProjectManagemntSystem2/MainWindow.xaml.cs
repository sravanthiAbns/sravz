﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ProjBAL;
using ProjEntities;
using ProjExceptions;
using System.Configuration;

namespace WpfProjectManagemntSystem2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter adapter;
        private SqlCommandBuilder builder;
        private DataSet dataSet;
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void textBox4_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtprojd_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtprojname_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtprojlocation_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtprojprojbudgt_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var obj = dataGrid.SelectedItem;
            if(dataGrid.SelectedIndex > 0)
            {

            txtprojd.Text = ((projentity)obj).projID.ToString();
            txtprojname.Text= ((projentity)obj).projname.ToString();
            txtprojlocation.Text = ((projentity)obj).projlocation.ToString();
            txtprojprojbudgt.Text = ((projentity)obj).projBudget.ToString();
            datepicker.Text = ((projentity)obj).dateofStart.ToString();
            }
        }

       

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deleteprojID;
                deleteprojID = Convert.ToInt32(txtprojd.Text);
               projentity deleteproj = ProjbaL.SearchprojBL(deleteprojID);
                if (deleteproj != null)
                {
                    bool projdeleted =ProjbaL.DeleteProjBL(deleteprojID);
                    if (projdeleted)
                        MessageBox.Show("project Deleted");
                    else
                       MessageBox.Show("project not Deleted ");
                }
                else
                {
                    MessageBox.Show("No projects Available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                projentity newProj = new projentity();
                
                //newProj.projID = Convert.ToInt32(txtprojd.Text);
               
                newProj.projname = txtprojname.Text;
              
                newProj.projlocation = txtprojlocation.Text;
                newProj.projBudget = Convert.ToDouble(txtprojprojbudgt.Text);
                newProj.dateofStart = Convert.ToDateTime(datepicker.Text);

                bool projAdded = ProjbaL.AddGuestBL(newProj);
                if (projAdded)
                    MessageBox.Show("project Added");
                else
                    MessageBox.Show("project not Added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchprojID;
                searchprojID = Convert.ToInt32(txtprojd.Text);
                projentity searchproj = ProjbaL.SearchprojBL(searchprojID);
                if (searchproj != null)
                {
                    txtprojname.Text = searchproj.projname;
                    txtprojlocation.Text = searchproj.projlocation;
                    txtprojprojbudgt.Text = searchproj.projBudget.ToString();
                    datepicker.Text = searchproj.dateofStart.ToString();

                }
                else
                {
                    MessageBox.Show("projectid not found");
                }
            }
            catch(Projexceptions ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            int updateprojID;
            updateprojID = Convert.ToInt32(txtprojd.Text);
            projentity updatedGuest = ProjbaL.SearchprojBL(updateprojID);
            if (updatedGuest != null)
            {

                updatedGuest.projname = txtprojname.Text;

                //Console.WriteLine("Update PhoneNumber :");
                updatedGuest.projlocation = txtprojlocation.Text;

                bool guestUpdated =ProjbaL.UpdateProjBL(updatedGuest);
                if (guestUpdated)
                    MessageBox.Show("project Details Updated");
                else
                    MessageBox.Show("project Details not Updated ");
            }
        }

        private void showall_Click(object sender, RoutedEventArgs e)
        {
            updategrid();
        }

        private void updategrid()
        {
            try
            {
                List<projentity> projlist = ProjbaL.GetAllProjBL();
                dataGrid.ItemsSource = projlist;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void window_Loaded(object sender, RoutedEventArgs e)
        {
            connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["training"].ConnectionString;

            command = connection.CreateCommand();
            adapter = new SqlDataAdapter(command);
            builder = new SqlCommandBuilder(adapter);
            dataSet = new DataSet();
        }
    }
}
