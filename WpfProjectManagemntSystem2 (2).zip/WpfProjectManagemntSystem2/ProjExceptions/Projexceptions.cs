﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjExceptions
{
    public class Projexceptions:ApplicationException
    {
        public Projexceptions()
            : base()
        {
        }

        public Projexceptions(string message)
            : base(message)
        {
        }
        public Projexceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
