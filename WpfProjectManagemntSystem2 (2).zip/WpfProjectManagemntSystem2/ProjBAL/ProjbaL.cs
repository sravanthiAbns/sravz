﻿using System;
using System.Collections.Generic;
using System.Text;
using ProjEntities;
using ProjExceptions;
using ProjDAL;
using System.Data;
using System.Data.Common;
using System.Windows;

namespace ProjBAL
{
    public class ProjbaL
    {
        private static bool Validproject(projentity pent)
        {
            StringBuilder sb = new StringBuilder();
            bool validproj = true;
            //if (pent.projID <= 0)
            //{
            //    validproj = false;
            //    sb.Append(Environment.NewLine + "Invalid Project ID");
            //}
            if (pent.projname == string.Empty)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "Guest Name Required");
            }
            if (pent.projBudget < 25000)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "budget should be above the limit");
            }
            if (validproj == false)
                throw new Projexceptions(sb.ToString());
            return validproj;

        }
        public static bool AddGuestBL(projentity newproj)
        {
            bool projAdded = false;
            try
            {
                if (Validproject(newproj))
                {
                    projDAL proj = new projDAL();
                    projAdded = proj.addproj(newproj);
                }
            }
            catch (Projexceptions ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projAdded;
        }

        public static List<projentity> GetAllProjBL()
        {
            List<projentity> projlist = null;
            try
            {
                projDAL projbal = new projDAL();
                projlist = projbal.getAllprojDet();
            }
            catch (Projexceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return projlist;
        }
        public static projentity SearchprojBL(int searchprojid)
        {
            projentity searchproj = null;
            try
            {
                projDAL projdAL = new projDAL();
                searchproj = projdAL.SearchProjDAL(searchprojid);
            }
            catch (Projexceptions ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            return searchproj;

        }
        public static bool UpdateProjBL(projentity updateproj)
        {
            bool projUpdated = false;
            try
            {
                if (Validproject(updateproj))
                {
                    projDAL guestdAL = new projDAL();
                    projUpdated = guestdAL.UpdateprojDAL(updateproj);
                }
            }
            catch (Projexceptions ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projUpdated;
        }

        public static bool DeleteProjBL(int deleteProjID)
        {
            bool projDeleted = false;
            try
            {
                if (deleteProjID > 0)
                {
                    projDAL guestdAL = new projDAL();
                    projDeleted = guestdAL.DeleteProjDAL(deleteProjID);
                }
                else
                {
                    throw new Projexceptions("Invalid Guest ID");
                }
            }
            catch (Projexceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projDeleted;
        }
    }
    }
