Create Database CineStarDB;

Use CineStarDB
Go

--Genre table creation
CREATE TABLE Genre (
	GenreID int Primary Key Identity(1000,1),
	GenreName varchar(25) NOT NULL,
	Description varchar(500) NOT NULL,
)
Go

	--genre Procedure for new entry
	GO
	Create proc NewGenreEntry (
		@genreName varchar(25),
		@desc varchar(40)
	)
	AS
	BEGIN
		BEGIN TRY
			Insert into Genre Values(@genreName,@desc)
			END TRY
		BEGIN CATCH
			return ERROR_MESSAGE();
		END CATCH
	END
	SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE'

	--genre procedure for updating entry
	GO
	Alter proc UpdateGenre (
		@genreID int, 
		@genreName varchar(25),
		@desc varchar(40)) AS
	BEGIN
		BEGIN TRY
			Update Genre
			Set 
			GenreName = @genreName, Description = @desc
			Where GenreID = @genreID
		END TRY
		BEGIN CATCH
			return ERROR_MESSAGE();
		END CATCH
	END
	--genre procedure for deleting entry in Genre
	GO
	Create proc DeleteGenreName (
		@genreName varchar(30)
	)
	AS
	BEGIN
		BEGIN TRY
			Delete from Genre
			Where @genreName= GenreName
		END TRY
		BEGIN CATCH
			return ERROR_MESSAGE();
		END CATCH
	END
	
--Movies Table creation
CREATE TABLE Movies (
	MovieID int Primary Key Identity(1000,1),
	MovieName varchar(50) NOT NULL,
	ReleaseDate Date NOT NULL, 
	GenreID int,
	Description varchar(500),
	FOREIGN KEY(GenreID) REFERENCES Genre(GenreID) on update cascade on delete cascade
);

    --Movies Procedure for new entry
	GO
	Alter proc NewMovieEntry ( 
		@movieName varchar(50),
		@releaseDate DateTime,
		@genreID int,
		@desc varchar(40)
	)
	AS
	BEGIN
		Insert into Movies values(@movieName,@releaseDate,@genreID,@desc);
	END

	--Movies procedure for updating entry 
	GO
	Alter procedure UpdateMovieEntry (
		@movieid int,
		@movieName varchar(50),
		@releaseDate DateTime,
		@genreID numeric(4),
		@desc varchar(40)
	)
	AS
	BEGIN
		Update Movies Set 
		MovieName = @movieName,
		ReleaseDate = @releaseDate,
		GenreID = @genreID,
		Description = @desc
		Where MovieID = @movieid
	END


	--return recent movie name
	Go
	Create proc RecentMovieDetails
	As
	Begin
		Select movieid, moviename,description from movies 
		where (DATEDiFF(DAY,releasedate,GETDATE()))<=7 
	End

	exec recentmoviedetails;  
	
	-- return all details
	Go 
	Create proc AllMovieDetails
	As
	Begin
		Select movieId, moviename, movies.description, genrename
		From movies join genre on(movies.genreid=genre.genreid)
	End

	--retrning movie details of a movieid
	Go
	Alter proc GetMovieDetails (
		@movieid int
	)
	As
	Begin
		Select moviename, movies.description, genrename
		From movies join genre on(movies.genreid=genre.genreid)
		Where movieid = @movieid;
	End
	exec GetMovieDetails 1000

	-- return showdetails of a movieid
	Go
	Alter proc GetShowDetails (
		@movieid int
	)
	As
	Begin
		Select moviename, screenname, showtime, price, Capacity
		From Movies, Screens, Shows
		Where movies.movieid = shows.movieid and 
		shows.screenid = screens.screenid and 
		movies.movieid = @movieid;
	End
	Exec GetShowDetails 1000;

	-- c
	Go
	Alter proc AddTicketDetails (
		@viewerid int,
		@showid int,
		@nooftickets int
	)
	As
	Begin
		Declare @screenid int
		Set @screenid = (select screenid from shows where
		@showid = showid);
		Update screens
		Set capacity = capacity-@nooftickets
		Where @screenid = screenid;
		Insert into Tickets values (
			getdate(), @viewerid, @showid,
			@nooftickets
		);
	End
	Go

	Create Proc GetViewerIDAddTicket (
		@userName varchar(15)
	)
	As
	Begin
		Select ViewersID from Viewers where Username = @userName;
	End

	exec AddTicketDetails 3000,2000,4;

--creating Screens table
CREATE TABLE Screens (
	ScreenID int PRIMARY KEY Identity(1000,1), 
	ScreenName varchar(50) NOT NULL,
	Capacity int,
);

CREATE TABLE Viewers (
	ViewersID int Primary Key Identity(1000,1), 
	FirstName varchar(15) NOT NULL,
	LastName varchar(15), 
	MobileNo numeric(10) NOT NULL, 
	Email varchar(50) NOT NULL,
	Username varchar(15) UNIQUE, 
	Password varchar(512),
);

CREATE TABLE Shows ( 
	ShowID int Primary Key Identity(1000,1),
	ScreenID int NOT NULL,
	MovieID int NOT NULL, 
	Showtime Time NOT NULL, 
	Price int NOT NULL,
	FOREIGN KEY(ScreenID) REFERENCES Screens(ScreenID) on update cascade on delete cascade,
	FOREIGN KEY(MovieID) REFERENCES Movies(MovieID) on update cascade on delete cascade,
);

CREATE TABLE Tickets (
	TicketsID int Primary Key Identity(1000,1), 
	TansactionDate DateTime,
	ViewersID int, 
	ShowID int,
	NoOfTickets int,
	FOREIGN KEY(ViewersID) REFERENCES Viewers(ViewersID) on update cascade on delete cascade,
	FOREIGN KEY(ShowID) REFERENCES Shows(ShowID) on update cascade on delete cascade
);

CREATE TABLE Users (
	ID int Primary Key Identity(1000,1),
	Username varchar(15) UNIQUE, 
	Password varchar(512)
);

	-- user(admin) authentication procedure
	Go
	Create proc UserLogin (
	@username varchar(15),
	@password varchar(512)
	)
	As
	Begin
		Select * from Users where @username = Username and @password = Password
	End

	-- viewer authentication procedure
	Go 
	Create proc ViewerLogin (
	@username varchar(15),
	@password varchar(512)
	)
	As
	Begin
		Select * from Viewers where @username = Username and @password = Password
	End

	-- viewer signup procedure
	Go
	Create proc ViewerSignup (
	@firstname varchar(15),
	@lastname varchar(15),
	@mobileno numeric(10,0),
	@email varchar(50),
	@username varchar(15),
	@password varchar(512)
	)
	As
	Begin
		Insert into Viewers values(@firstname,@lastname,@mobileno,@email,@username,@password);
	End 