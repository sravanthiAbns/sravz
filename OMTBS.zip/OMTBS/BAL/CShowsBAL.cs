﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    class CShowsBAL
    {
        public DataTable MGetShowDetailsBAL(int movieID)
        {
            if (movieID == 0)
                throw new Exception("Enter MovieID ");
            else
                return new CShowsDAL().MGetShowDetailsDAL(movieID);
        }
    }
}
