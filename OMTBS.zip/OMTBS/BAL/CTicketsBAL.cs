﻿using DAL;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    class CTicketsBAL
    {
        public bool AddTicketValidations(TicketsEntities ticketObj)
        {
            bool isValid = true;
            StringBuilder errorMessage = new StringBuilder();
            if(ticketObj.TICKETS_VIEWERSID == 0)
            {
                isValid = false;
                errorMessage.AppendLine("ViewerID missing");
            }
            if(ticketObj.TICKETS_SHOWID == 0)
            {
                isValid = false;
                errorMessage.AppendLine("TicketID missing");
            }
            if(ticketObj.TICKETS_NOOFTICKETS == 0)
            {
                isValid = false;
                errorMessage.AppendLine("Enter the number of tickets");
            }
            if(errorMessage.Length != 0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        public bool MAddTicketDetailsBAL(TicketsEntities ticket)
        {
            if(AddTicketValidations(ticket))
            {
                return new CTicketsDAL().MAddTicketDetailsDAL(ticket);
            }
            return false;
        }
    }
}