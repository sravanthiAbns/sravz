﻿using DAL;
using EntitiesLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BAL
{
    public class CViewersBAL
    {
        static bool CredentialsValidation(ViewersEntities viewerObj)
        {
            StringBuilder errorMessage = new StringBuilder();
            bool isValid = true;
            if (viewerObj.VIEWERS_USERNAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Enter a username");
            }
            if (viewerObj.VIEWERS_PASSWORD.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Provide a password");
            }
            if (errorMessage.Length != 0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        static bool SignupDetailsValidation(ViewersEntities viewerObj)
        {
            StringBuilder errorMessage = new StringBuilder();
            bool isValid = true;
            if(viewerObj.VIEWERS_FIRSTNAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Provide your First Name");
            }
            if (!Regex.IsMatch(viewerObj.VIEWERS_EMAIL, "[a-zA-Z0-9]+@[a-zA-Z]+.com")) 
            {
                isValid = false;
                errorMessage.AppendLine("Provide email in a correct format");
            }
            if(viewerObj.VIEWERS_USERNAME.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Username cannot be empty");
            }
            if(viewerObj.VIEWERS_PASSWORD.Equals(string.Empty))
            {
                isValid = false;
                errorMessage.AppendLine("Password cannot be empty");
            }
            if(!Regex.IsMatch(viewerObj.VIEWERS_MOBILENO.ToString(),"[0-9]{10}")) {
                isValid = false;
                errorMessage.AppendLine("Phone number should be of 10 digits.");
            }
            if(errorMessage.Length != 0)
            {
                throw new Exception(errorMessage.ToString());
            }
            return isValid;
        }
        public static bool MViewersLoginAuthenticationBAL(ViewersEntities viewerObj)
        {
            if(CredentialsValidation(viewerObj))
                return new CViewersDAL().MViewersLoginAuthenticationDAL(viewerObj);
            return false;
        }
        public static bool MViewersSignupBAL(ViewersEntities viewerObj)
        {
            if(SignupDetailsValidation(viewerObj))
                return new CViewersDAL().MViewersSignupDAL(viewerObj);
            return false;
        }
        public static int MGetViewerIDByNameBAL(string name) {
            if (!name.Equals(string.Empty))
                return new CViewersDAL().MGetViewerIDByNameDAL(name);
            else
                return -1;
        }
    }
}
