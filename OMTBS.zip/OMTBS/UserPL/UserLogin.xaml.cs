﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EntitiesLayer;
using BAL;

namespace UserPL {
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Window {
        public UserLogin() {
            InitializeComponent();
        }

        private void userLoginButton_Click(object sender, RoutedEventArgs e) {
            UsersEntities user = new UsersEntities();
            user.USERS_USERNAME = userUsernameTextBox.Text;
            user.USERS_PASSWORD = userPasswordTextBox.Text;
            if (CUsersBAL.MUserLoginAuthenticationBAL(user)) {
                MessageBox.Show("Welcome");
                var userHomePage = new UserHomePage();
                userHomePage.Show();
            } else {
                MessageBox.Show("Invalid Credentials");
            }
        }
    }
}
