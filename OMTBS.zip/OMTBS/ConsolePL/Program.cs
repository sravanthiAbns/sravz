﻿using System;
using System.Collections.Generic;
using DAL;
using EntitiesLayer;
using System.Data;
using BAL;

namespace ConsolePL {
    class Program {
        static void Main(string[] args) {
            //GenreEntities genreObj = new GenreEntities();
            //genreObj.GENRE_GENRENAME = Console.ReadLine();
            //genreObj.GENRE_GENREDESCRIPTION = Console.ReadLine();
            //try
            //{
            //    CGenreBAL.MNewGenreEntryBAL(genreObj);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            //try
            //{
            //    GenreEntities genreObj = new GenreEntities();
            //    genreObj.GENRE_GENREID = Convert.ToInt32(Console.ReadLine());
            //    genreObj.GENRE_GENRENAME = Console.ReadLine();
            //    genreObj.GENRE_GENREDESCRIPTION = Console.ReadLine();
            //    CGenreBAL.MUpdateGenreBAL(genreObj);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            //GenreEntities genreObj = new GenreEntities();
            //genreObj.GENRE_GENRENAME = Console.ReadLine();
            //CGenreBAL.MDeleteGenreDAL(genreObj.GENRE_GENRENAME);

            //List<MoviesEntities> list = new List<MoviesEntities>();
            //list = new CMoviesDAL().MGetAllMoviesDAL();
            //Console.WriteLine(list.Count);
            //foreach (MoviesEntities entity in list) {
            //    Console.WriteLine(entity.MOVIES_MOVIENAME);
            //}
            //List<MoviesEntities> movie = new List<MoviesEntities>();
            //movie = new CMoviesDAL().MGetMovieDetailsByIDDAL(1000);
            //Console.WriteLine(movie.Count);
            //Console.WriteLine(movie[0].MOVIES_MOVIENAME);

            //DataTable table = new DataTable();
            //table = new CShowsDAL().MGetShowDetailsDAL(1000);
            //Console.WriteLine(table.Rows[0][0]);
            //Console.WriteLine(table.Rows[0][1]);
            //Console.WriteLine(table.Rows[0][2]);
            //Console.WriteLine(table.Rows[0][3]);
            //Console.WriteLine(table.Rows[0][4]);

            //TicketsEntities ticket = new TicketsEntities();
            //ticket.TICKETS_VIEWERSID = 1000;
            //ticket.TICKETS_SHOWID = 1002;
            //ticket.TICKETS_NOOFTICKETS = 5;
            //new CTicketsDAL().MAddTicketDetailsDAL(ticket);

            //int ch = Convert.ToInt32(Console.ReadLine());
            //GenreEntities genreentity = new GenreEntities();
            //switch(ch) {
            //    case 1:
            //        genreentity.GENRE_GENRENAME = Console.ReadLine();
            //        genreentity.GENRE_GENREDESCRIPTION = Console.ReadLine();
            //        CGenreBAL.MNewGenreEntryBAL(genreentity);
            //        break;
            //    case 2:
            //        genreentity.GENRE_GENREID = Convert.ToInt32(Console.ReadLine());
            //        genreentity.GENRE_GENRENAME = Console.ReadLine();
            //        genreentity.GENRE_GENREDESCRIPTION = Console.ReadLine();
            //        CGenreBAL.MUpdateGenreBAL(genreentity);
            //        break;
            //    case 3:
            //        string genrename = Console.ReadLine();
            //        CGenreBAL.MDeleteGenreDAL(genrename);
            //        break;
            //}

            //UsersEntities userObj = new UsersEntities();
            //userObj.USERS_USERNAME = Console.ReadLine();
            //userObj.USERS_PASSWORD = Console.ReadLine();
            //if(CUsersBAL.MUserLoginAuthenticationBAL(userObj))
            //    Console.WriteLine("true");
            //else Console.WriteLine("false");

            //try
            //{
            //    ViewersEntities viewerObj = new ViewersEntities();
            //    viewerObj.VIEWERS_USERNAME = Console.ReadLine();
            //    viewerObj.VIEWERS_PASSWORD = Console.ReadLine();
            //    if (CViewersBAL.MViewersLoginAuthenticationBAL(viewerObj))
            //        Console.WriteLine("true");
            //    else Console.WriteLine("false");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            //try
            //{
            //    ViewersEntities viewerObj = new ViewersEntities();
            //    viewerObj.VIEWERS_FIRSTNAME = Console.ReadLine();
            //    viewerObj.VIEWERS_LASTNAME = Console.ReadLine();
            //    viewerObj.VIEWERS_MOBILENO = Convert.ToDecimal(Console.ReadLine());
            //    viewerObj.VIEWERS_EMAIL = Console.ReadLine();
            //    viewerObj.VIEWERS_USERNAME = Console.ReadLine();
            //    viewerObj.VIEWERS_PASSWORD = Console.ReadLine();
            //    CViewersBAL.MViewersSignupBAL(viewerObj);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            try {
                int ID = CViewersBAL.MGetViewerIDByNameBAL("cjain252");
                Console.WriteLine(ID);
            } catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
