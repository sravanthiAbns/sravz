﻿using System;
using System.Configuration;

namespace DAL {
    public class ConnectionStrings {
        static string connectionString;
        static string providerName;
        static ConnectionStrings() {
            connectionString = ConfigurationManager.ConnectionStrings["CineStarDBConnection"].ConnectionString;
            providerName = ConfigurationManager.ConnectionStrings["CineStarDBConnection"].ProviderName;
        }
        public static string CONNECTION_STRING {
            get { return connectionString; }
            set { connectionString = value; }
        }
        public static string PROVIDER_NAME {
            get { return providerName; }
            set { providerName = value; }
        }
    }
}
