﻿using EntitiesLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CViewersDAL
    {
        //Method to Authenticate a Viewer using username and password
        public bool MViewersLoginAuthenticationDAL(ViewersEntities viewerObj)
        {
            bool isAuthenticated = false;
            DbCommand command = null;
            DbParameter param = null;

            try
            {
                //Create command and pass parameters for procedure
                command = DataConnection.CreateCommand();
                command.CommandText = "ViewerLogin";

                param = command.CreateParameter();
                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_USERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_PASSWORD;
                command.Parameters.Add(param);

                //Execute the created command and store data in DataTable
                DataTable data = DataConnection.ExecuteSelectCommand(command);

                if (data.Rows.Count > 0)
                    isAuthenticated = true;
            }
            catch (Exception ex)
            {
                throw new ViewerException(ex.Message);
            }
            return isAuthenticated;
        }
        //User Signup Method
        public bool MViewersSignupDAL(ViewersEntities viewerObj)
        {
            bool isViewerSignedup = false;
            DbCommand command = null;
            DbParameter param = null;
            try
            {
                //Create command and pass parameters for storedprocedure
                command = DataConnection.CreateCommand();
                command.CommandText = "ViewerSignup";

                param = command.CreateParameter();
                param.ParameterName = "@firstname";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_FIRSTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lastname";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_LASTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@mobileno";
                param.DbType = DbType.Double;
                param.Value = viewerObj.VIEWERS_MOBILENO;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@email";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_EMAIL;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@username";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_USERNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = viewerObj.VIEWERS_PASSWORD;
                command.Parameters.Add(param);

                //Execute the created command
                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    isViewerSignedup = true;
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            catch (Exception ex) {
                throw new ViewerException(ex.Message);
            }
            return isViewerSignedup;
        }
        public int MGetViewerIDByNameDAL(string name) {
            int ID = 0;
            DbCommand command = null;
            DbParameter param = null;
            try {
                //Create command and pass parameters for storedprocedure
                command = DataConnection.CreateCommand();
                command.CommandText = "GetViewerIDAddTicket";

                param = command.CreateParameter();
                param.ParameterName = "@userName";
                param.DbType = DbType.String;
                param.Value = name;
                command.Parameters.Add(param);

                //Execute the created command
                object obj = DataConnection.ExecuteScalarCommand(command);

                if (obj != null)
                    ID = Convert.ToInt32(obj);

                return ID;
            } catch (Exception ex) {
                throw new ViewerException(ex.ToString());
            }
        }
    }
}
