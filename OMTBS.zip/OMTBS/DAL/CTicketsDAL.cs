﻿using System;
using System.Collections.Generic;
using EntitiesLayer;
using System.Data.Common;
using System.Data;
using ExceptionLayer;

namespace DAL {
    public class CTicketsDAL {
        //Method to Add new Ticket Details
        public bool MAddTicketDetailsDAL(TicketsEntities ticket) {
            bool ticketGenerated = false;
            DbCommand cmd = null;
            DbParameter param = null;

            try {
                //Create command and pass parameters for procedure
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "AddTicketDetails";

                param = cmd.CreateParameter();
                param.ParameterName = "@viewerid";
                param.DbType = DbType.Int32;
                param.Value = ticket.TICKETS_VIEWERSID;
                cmd.Parameters.Add(param);

                param = cmd.CreateParameter();
                param.ParameterName = "@showid";
                param.DbType = DbType.Int32;
                param.Value = ticket.TICKETS_SHOWID;
                cmd.Parameters.Add(param);

                param = cmd.CreateParameter();
                param.ParameterName = "@nooftickets";
                param.DbType = DbType.Int32;
                param.Value = ticket.TICKETS_NOOFTICKETS;
                cmd.Parameters.Add(param);

                //Execute the created command
                int affectedRows = DataConnection.ExecuteNonQueryCommand(cmd);

                if(affectedRows > 0) {
                    ticketGenerated = true;
                }

            } catch (Exception ex) {
                throw new TicketException(ex.Message); 
            }

            return ticketGenerated;
        }
    }
}
