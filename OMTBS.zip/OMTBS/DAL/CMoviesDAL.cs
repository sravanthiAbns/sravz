﻿using System;
using System.Data;
using System.Data.Common;
using EntitiesLayer;
using System.Collections.Generic;
using ExceptionLayer;

namespace DAL {
    public class CMoviesDAL {
        //Method to Add new Movie
        public bool MAddNewMovieDAL(MoviesEntities newMovie) {
            bool movieAdded = false;
            DbCommand cmd = null;
            DbParameter param = null;
            try {
                //Create command and pass parameters for procedure
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "NewMovieEntry";

                param = cmd.CreateParameter();
                param.ParameterName = "@movieName";
                param.DbType = DbType.String;
                param.Value = newMovie.MOVIES_MOVIENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@releaseDate";
                param.DbType = DbType.DateTime;
                param.Value = newMovie.MOVIES_RELEASEDATE;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Int32;
                param.Value = newMovie.MOVIES_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = newMovie.MOVIES_DESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                //Execute created command
                int affectedRows = DataConnection.ExecuteNonQueryCommand(cmd);
                if(affectedRows > 0) {
                    movieAdded = true;
                }
            } catch (Exception ex) {
                throw new MoviesException(ex.Message);
            }
            return movieAdded;
        }

        //Method to Update existing movie
        public bool MUpdateMovieDAL(MoviesEntities movie) {
            bool movieUpdated = false;
            DbCommand cmd = null;
            DbParameter param = null;
            try {
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "UpdateMovieEntry";

                param = cmd.CreateParameter();
                param.ParameterName = "@movieid";
                param.DbType = DbType.Int32;
                param.Value = movie.MOVIES_MOVIEID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@movieName";
                param.DbType = DbType.String;
                param.Value = movie.MOVIES_MOVIENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@releaseDate";
                param.DbType = DbType.DateTime;
                param.Value = movie.MOVIES_RELEASEDATE;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Int32;
                param.Value = movie.MOVIES_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = movie.MOVIES_DESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                int affectedRows = DataConnection.ExecuteNonQueryCommand(cmd);
                if (affectedRows > 0) {
                    movieUpdated = true;
                }
            } catch (Exception ex) {
                throw new MoviesException(ex.Message);
            }
            return movieUpdated;
        }

        //Method to get a list of recent movies
        public List<MoviesEntities> MGetRecentMoviesDAL() {
            List<MoviesEntities> recentMoviesList = null;
            DbCommand cmd = null;
            DataTable dataTable = null;
            try {
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "RecentMovieDetails";

                dataTable = new DataTable();
                dataTable = DataConnection.ExecuteSelectCommand(cmd);
                recentMoviesList = new List<MoviesEntities>();
                if(dataTable.Rows.Count > 0) {
                    for(int index=0;index<dataTable.Rows.Count;index++) {
                        MoviesEntities movie = new MoviesEntities();
                        movie.MOVIES_MOVIEID = Convert.ToInt32(dataTable.Rows[index][0]);
                        movie.MOVIES_MOVIENAME = dataTable.Rows[index][1].ToString();
                        movie.MOVIES_DESCRIPTION = dataTable.Rows[index][2].ToString();
                        recentMoviesList.Add(movie);
                    }
                } else {
                    Console.WriteLine("No Recent Movies Found");
                }
            } catch (Exception ex) {
                throw new MoviesException(ex.Message);
            }
            
            return recentMoviesList;
        }

        //Method to get a list of all movies
        public List<MoviesEntities> MGetAllMoviesDAL() {
            List<MoviesEntities> recentMoviesList = null;
            DbCommand cmd = null;
            DataTable dataTable = null;
            try {
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "AllMovieDetails";

                dataTable = new DataTable();
                dataTable = DataConnection.ExecuteSelectCommand(cmd);
                recentMoviesList = new List<MoviesEntities>();
                if (dataTable.Rows.Count > 0) {
                    for (int index = 0; index < dataTable.Rows.Count; index++) {
                        MoviesEntities movie = new MoviesEntities();
                        movie.MOVIES_MOVIEID = Convert.ToInt32(dataTable.Rows[index][0]);
                        movie.MOVIES_MOVIENAME = dataTable.Rows[index][1].ToString();
                        movie.MOVIES_DESCRIPTION = dataTable.Rows[index][2].ToString();
                        recentMoviesList.Add(movie);
                    }
                } else {
                    Console.WriteLine("No Recent Movies Found");
                }
            } catch (Exception ex) {
                throw new MoviesException(ex.Message);
            }

            return recentMoviesList;
        }

        //Method to get Movie Details based on ID
        public MoviesEntities MGetMovieDetailsByIDDAL(int movieID) {
            List<MoviesEntities> movieList = null;
            MoviesEntities movie = null;
            DbCommand cmd = null;
            DataTable table = null;
            DbParameter param = null;
            try {
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "GetMovieDetails";

                param = cmd.CreateParameter();
                param.ParameterName = "@movieid";
                param.DbType = DbType.Int32;
                param.Value = movieID;
                cmd.Parameters.Add(param);
                param = null;

                table = new DataTable();
                table = DataConnection.ExecuteSelectCommand(cmd);
                if(table != null) {
                    movie = new MoviesEntities();
                    movieList = new List<MoviesEntities>();
                    movie.MOVIES_MOVIENAME = table.Rows[0][0].ToString();
                    movie.MOVIES_DESCRIPTION = table.Rows[0][1].ToString();
                    movie.MOVIES_GENRENAME = table.Rows[0][2].ToString();
                    //movieList.Add(movie);
                }
            } catch (Exception ex) {
                throw new MoviesException(ex.Message);
            }
            return movie;
        }
    }
}
