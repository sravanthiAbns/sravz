﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using ExceptionLayer;

namespace DAL {
    public class CShowsDAL {
        //Method to GetShowDetails of a movie based on MovieID
        public DataTable MGetShowDetailsDAL(int movieID) {
            DataTable table = null;
            DbCommand cmd = null;
            DbParameter param = null;
            try {
                //Create command and pass parameters for procedure
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "GetShowDetails";

                param = cmd.CreateParameter();
                param.ParameterName = "@movieid";
                param.DbType = DbType.Int32;
                param.Value = movieID;
                cmd.Parameters.Add(param);
                param = null;

                //Execute command and store data in DataTable
                table = new DataTable();
                table = DataConnection.ExecuteSelectCommand(cmd);
            } catch (Exception ex) {
                throw new ShowsException(ex.Message);
            }
            return table;
        }
    }
}
