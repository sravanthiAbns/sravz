﻿using System;

namespace EntitiesLayer {
    public class GenreEntities {
        public int GENRE_GENREID { get; set; }
        public string GENRE_GENRENAME { get; set; }
        public string GENRE_GENREDESCRIPTION { get; set; }
    }
}
