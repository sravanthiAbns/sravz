﻿using System;

namespace EntitiesLayer {
    public class TicketsEntities {
        public int TICKETS_TICKETSID { get; set; }
        public DateTime TICKETS_TRANSACTIONDATE { get; set; }
        public int TICKETS_VIEWERSID { get; set; }
        public int TICKETS_NOOFTICKETS { get; set; }
        public int TICKETS_SHOWID { get; set; }
    }
}
