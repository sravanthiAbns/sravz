﻿using System;

namespace EntitiesLayer {
    public class ViewersEntities {
        public int VIEWERS_VIEWERSID { get; set; }
        public string VIEWERS_FIRSTNAME { get; set; }
        public string VIEWERS_LASTNAME { get; set; }
        public decimal VIEWERS_MOBILENO { get; set; }
        public string VIEWERS_EMAIL { get; set; }
        public string VIEWERS_USERNAME { get; set; }
        public string VIEWERS_PASSWORD { get; set; }
    }
}
