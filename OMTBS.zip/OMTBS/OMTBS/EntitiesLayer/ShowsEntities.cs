﻿using System;

namespace EntitiesLayer {
    public class ShowsEntities {
        public int SHOWS_SHOWID { get; set; }
        public int SHOWS_MOVIEID { get; set; }
        public int SHOWS_PRICE { get; set; }
        public long SHOWS_SHOWTIME { get; set; }
        public int SHOWS_SCREENID { get; set; }
    }
}
