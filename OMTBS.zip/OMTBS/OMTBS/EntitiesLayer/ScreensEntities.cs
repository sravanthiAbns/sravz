﻿using System;

namespace EntitiesLayer {
    public class ScreensEntities {
        public int SCREENS_SCREENID { get; set; }
        public string SCREENS_SCREENNAME { get; set; }
        public int SCREENS_CAPACITY { get; set; }
    }
}
