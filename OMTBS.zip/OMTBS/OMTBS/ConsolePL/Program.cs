﻿using System;
using System.Collections.Generic;
using DAL;
using EntitiesLayer;

namespace ConsolePL {
    class Program {
        static void Main(string[] args) {
            //List<MoviesEntities> list = new List<MoviesEntities>();
            //list = new CMoviesDAL().MGetAllMoviesDAL();
            //Console.WriteLine(list.Count);
            //foreach (MoviesEntities entity in list) {
            //    Console.WriteLine(entity.MOVIES_MOVIENAME);
            //}
            List<MoviesEntities> movie = new List<MoviesEntities>();
            movie = new CMoviesDAL().MGetMovieDetailsByIDDAL(1000);
            Console.WriteLine(movie.Count);
            Console.WriteLine(movie[0].MOVIES_MOVIENAME);
        }
    }
}
