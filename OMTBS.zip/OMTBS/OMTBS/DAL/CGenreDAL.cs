﻿using System;
using System.Windows;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using EntitiesLayer;

namespace DAL {
    public class CGenreDAL {
        static string connectionString;
        static string providerName;
        static DbProviderFactory factory = null;
        public CGenreDAL() {
            connectionString = ConnectionStrings.CONNECTION_STRING;
            providerName = ConnectionStrings.PROVIDER_NAME;
            factory = DbProviderFactories.GetFactory(providerName);
        }
        public bool MNewGenreEntryDAL(GenreEntities genreEntity) {
            bool genreAdded = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;

            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "NewGenreEntry";

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Decimal;
                param.Value = genreEntity.GENRE_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@genreName";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENRENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENREDESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if(affectedRows > 0) {
                    genreAdded = true;
                }
            } catch (Exception ex) {
                
            }

            return genreAdded;
        }

        public bool MUpdateGenreDAL(GenreEntities genreEntity) {
            bool genreUpdated = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;
            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UpdateGenre";

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Decimal;
                param.Value = genreEntity.GENRE_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@genreName";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENRENAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@desc";
                param.DbType = DbType.String;
                param.Value = genreEntity.GENRE_GENREDESCRIPTION;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0) {
                    genreUpdated = true;
                }
            } catch (Exception ex) {

            }
            return genreUpdated;
        }
        public bool MDeleteGenreDAL(GenreEntities genreEntity) {
            bool genreDeleted = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;

            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "deleteGenreName";

                param = cmd.CreateParameter();
                param.ParameterName = "@genreID";
                param.DbType = DbType.Decimal;
                param.Value = genreEntity.GENRE_GENREID;
                cmd.Parameters.Add(param);
                param = null;

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0) {
                    genreDeleted = true;
                }
            } catch (Exception ex) {

            }

            return genreDeleted;
        }
    }
}
