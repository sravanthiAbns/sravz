﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    class ScreenException : ApplicationException
    {
        public ScreenException() : base()
        {

        }
        public ScreenException(string message) : base(message)
        {

        }
        public ScreenException(string message, Exception innerException) : base(message,innerException)
        {

        }
    }
}
