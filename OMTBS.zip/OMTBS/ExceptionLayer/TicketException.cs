﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class TicketException : ApplicationException
    {
        public TicketException() : base()
        {

        }
        public TicketException(string message, Exception innerException) : base(message,innerException)
        {

        }
        public TicketException(string message) : base(message)
        {

        }
    }
}
