﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;
using EntitiesLayer;

namespace OnlineBookingHomePage {
    /// <summary>
    /// Interaction logic for ViewerLogin.xaml
    /// </summary>
    public partial class ViewerLogin : Window {
        public ViewerLogin() {
            InitializeComponent();
        }

        private void viewerLoginButton_Click(object sender, RoutedEventArgs e) {
            ViewersEntities viewer = new ViewersEntities();
            viewer.VIEWERS_USERNAME = viewerUsernameTextBox.Text;
            viewer.VIEWERS_PASSWORD = viewerPasswordTextBox.Text;
            if (CViewersBAL.MViewersLoginAuthenticationBAL(viewer)) {
                MessageBox.Show("Welcome");
            } else {
                MessageBox.Show("Invalid Credentials");
            }
        }
    }

}
