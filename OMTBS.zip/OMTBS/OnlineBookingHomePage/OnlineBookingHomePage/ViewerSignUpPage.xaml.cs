﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Common;
using EntitiesLayer;
using BAL;

namespace OnlineBookingHomePage
{
    /// <summary>
    /// Interaction logic for SignUpPage.xaml
    /// </summary>
    public partial class SignUpPage : Window
    {
        public SignUpPage()
        {
            InitializeComponent();
        }

        private void signUpButton_Click(object sender, RoutedEventArgs e) {
            ViewersEntities viewer = new ViewersEntities();
            viewer.VIEWERS_FIRSTNAME = firstNameTextbox.Text;
            viewer.VIEWERS_LASTNAME = lastNameTextbox.Text;
            viewer.VIEWERS_MOBILENO = Convert.ToDecimal(contactNoTextbox.Text);
            viewer.VIEWERS_EMAIL = emailTextbox.Text;
            viewer.VIEWERS_USERNAME = userNameTextbox.Text;
            viewer.VIEWERS_PASSWORD = passwordTextbox.Text;
            try {
                CViewersBAL.MViewersSignupBAL(viewer);
            } catch (Exception ex) {
                if(ex.Message.ToLower().Contains("unique")) {
                    MessageBox.Show("User already exists");
                } else {
                    MessageBox.Show(ex.ToString());
                }
            }
        }
    }
}
