﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PanException;
using PanManagementBL;

using ClassEntity;

namespace PAN_MANAGEMENT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PanEntity newPan = null;
                newPan = new PanEntity();
                

                newPan.PANNO = Convert.ToInt32(textBox1.Text);
                
                newPan.Name = textBox2.Text;

                newPan.city = textBox3.Text;
               
                newPan.Address = textBox4.Text;

                newPan.DateofCreation =Convert.ToDateTime( datepicker1.Text);
                bool panAdded =  BAL.AddPANNo(newPan);
                if (panAdded)
                    Console.WriteLine("Guest Added");
                else
                    Console.WriteLine("Guest not Added");
            }
            catch (PANException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deletePANNo = Convert.ToInt32(textBox1.Text);
                PanEntity deletePAN = BAL.SearchPANBL(deletePANNo);
                if(deletePAN != null)
                {
                    bool pandeleted = BAL.DeletePanBL(deletePANNo);
                    if (pandeleted)
                        label.Content = "PAN Deleted";
                    else
                        label.Content = "PAN Not Deleted";
                }
            }
            catch(PANException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Updatebutton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int updatePAN = Convert.ToInt32(textBox1.Text);
                PanEntity updatedPAN = BAL.SearchPANBL(updatePAN);

                if (updatedPAN != null)
                {
                    updatedPAN.Name = textBox2.Text;
                    updatedPAN.city = textBox3.Text;
                    updatedPAN.Address = textBox4.Text;
                    updatedPAN.DateofCreation = Convert.ToDateTime(datepicker1.Text);
                    bool PANUpdated = BAL.UpdatePANBL(updatedPAN);
                    label.Content = "PAN Details Updated";
                }
                else
                    label.Content = "PAN Details Not Available";
                
            }
            catch(PANException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                PanEntity obj = (PanEntity)(object)dataGrid.SelectedItem;
                textBox1.Text = obj.PANNO.ToString();
                textBox2.Text = obj.Name;
                textBox3.Text = obj.city;
                textBox4.Text = obj.Address;
                datepicker1.Text = Convert.ToString(obj.DateofCreation);

            }
            catch (PANException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
