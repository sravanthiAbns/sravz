﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace PanManagementDAL
{
    class Configuration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return Configuration.providerName; }
            set { Configuration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return Configuration.connectionString; }
            set { Configuration.connectionString = value; }
        }

        static Configuration()
        {
            providerName = ConfigurationManager.ConnectionStrings["phoneBookConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["phoneBookConnection"].ConnectionString;

        }
    }
}
