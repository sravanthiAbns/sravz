﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleDataset2
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection(@"Data Source=BLRWFD20620\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True");
            con.Open();

            // create adapter object fro update n other queries
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT employeeid,firstname from employees",con);
            
            // sqlcommandbuilder is for update , del..
            SqlCommandBuilder build = new SqlCommandBuilder(adapter);

            //create dataset fro mulitple columns,rows.......... dtaset is aclientside object
            DataSet dt = new DataSet();

            //fill dataset using query defined previously for dtaapdapter
            adapter.Fill(dt, "emp");

            //show data
                        //Console.WriteLine("name : {0}",
                        //dt.Tables["emp"].Rows[2]["firstname"]);

                        //foreach(DataTable dtb in dt.Tables)
                        //{
                        //    foreach(DataRow dr in dtb.Rows)
                        //    {
                        //        foreach(DataColumn dc in dr.Table.Columns)
                        //        {
                        //            Console.WriteLine("\t"+dr[dc].ToString());
                        //        }
                        //        Console.WriteLine();
                        //    }
                        //}

           
            dt.Tables["emp"].Rows[2]["firstName"] = "abns";
            //adapter.Update(dt, "emp");
            Console.WriteLine("name : {0}",
           dt.Tables["emp"].Rows[2]["firstname"]);
           
            // change in emp table , row 2 , ename
            //Console.WriteLine("changes: {0}", dt.HasChanges());
            //Console.WriteLine("changes in Table[0]: {0}", dt.Tables[0].GetChanges().Rows.Count);
            

            DataRow[] updaterows = dt.Tables["emp"].Select("employeeid=2");
            DataRow UpdateRow = updaterows[0];
            UpdateRow[1] = "srvanthi";
            Console.WriteLine(UpdateRow.RowState);

            // rollback 
           // dt.RejectChanges();

            Console.WriteLine("changes: {0}", dt.HasChanges());
            Console.WriteLine("changes in Table[0]: {0}", dt.Tables[0].GetChanges().Rows.Count);

            DataTable tbl2 = dt.Tables[0].GetChanges();
            Console.Read();
        }
    }
}
