﻿using System;
using ProjectManagementEntities;
using ProjectManagementDAL;
using System.Collections.Generic;

namespace ProjectManagementBAL {
    public class CBAL {
        public static bool MAddProjectBAL(CEntities entity) {
            CDAL dal = new CDAL();
            return dal.MAddData(entity);
        }
        public static List<CEntities> MGetAllDataBAL() {
            CDAL dal = new CDAL();
            return dal.MGetAllData();
        }
    }
}
