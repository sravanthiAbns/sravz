﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProjectManagementBAL;
using ProjectManagementEntities;

namespace ProjectManagementSystem {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
        }

        private void addButton_Click(object sender, RoutedEventArgs e) {
            CEntities entity = new CEntities();
            entity.PROJECT_NAME = projectNameTextBox.Text;
            entity.PROJECT_LOCATION = projectLocationTextBox.Text;
            entity.PROJECT_BUDGET = Convert.ToDouble(projectBudgetTextBox.Text);
            entity.DATE_OF_START = Convert.ToDateTime(dateOfStartDatePicker.Text);
            CBAL.MAddProjectBAL(entity);
        }

        private void showAllButton_Click(object sender, RoutedEventArgs e) {
            dataGrid.ItemsSource = CBAL.MGetAllDataBAL();
        }
    }
}
