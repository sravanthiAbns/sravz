﻿using System;
using System.Configuration;

namespace ProjectManagementDAL {
    class ProjectConnectionStrings {
        static string connectionString;
        static string providerName;
        public ProjectConnectionStrings() {
            connectionString = ConfigurationManager.ConnectionStrings["projectConnection"].ConnectionString;
            providerName = ConfigurationManager.ConnectionStrings["projectConnection"].ProviderName;
        }
        public static string CONNECTION_STRING {
            get {
                return connectionString;
            }
            set {
                connectionString = value;
            }
        }
        public static string PROVIDER_NAME {
            get {
                return providerName;
            }
            set {
                providerName = value;
            }
        }
    }
}
