﻿using System;
using System.Collections.Generic;
using ProjectManagementEntities;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;
using System.Windows;

namespace ProjectManagementDAL {
    public class CDAL {
        List<CEntities> entitiesList = new List<CEntities>();
        static string connectionString;
        static string providerName;
        static DbProviderFactory factory;
        static ProjectConnectionStrings connectionStrings;
        public CDAL() {
            connectionStrings = new ProjectConnectionStrings();
            connectionString = ProjectConnectionStrings.CONNECTION_STRING;
            providerName = ProjectConnectionStrings.PROVIDER_NAME;
            factory = DbProviderFactories.GetFactory(providerName);
        }

        public bool MAddData(CEntities entity) {
            bool dataAdded = false;
            DbConnection conn = null;
            DbCommand cmd = null;
            DbParameter param = null;
            int affectedRows = 0;
            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "AddProject";

                param = cmd.CreateParameter();
                param.ParameterName = "@ProjectName";
                param.DbType = DbType.String;
                param.Value = entity.PROJECT_NAME;
                cmd.Parameters.Add(param);

                param = cmd.CreateParameter();
                param.ParameterName = "@ProjectLocation";
                param.DbType = DbType.String;
                param.Value = entity.PROJECT_LOCATION;
                cmd.Parameters.Add(param);

                param = cmd.CreateParameter();
                param.ParameterName = "@ProjectBudget";
                param.DbType = DbType.Double;
                param.Value = entity.PROJECT_BUDGET;
                cmd.Parameters.Add(param);

                param = cmd.CreateParameter();
                param.ParameterName = "@ProjectDateOfStart";
                param.DbType = DbType.DateTime;
                param.Value = entity.DATE_OF_START;
                cmd.Parameters.Add(param);

                cmd.Connection.Open();
                affectedRows = cmd.ExecuteNonQuery();

                if(affectedRows > 0) {
                    dataAdded = true;
                }
            } catch (Exception Ex) {
                MessageBox.Show(Ex.ToString());
            } finally {
                cmd.Connection.Close();
            }

            return dataAdded;
        }

        public bool MUpdateData(CEntities entity) {
            bool dataUpdated = false;

            return dataUpdated;
        }

        public CEntities MSearchData(int projectID) {
            return null;
        }

        public bool MDeleteData(int projectID) {
            bool dataDeleted = false;

            return dataDeleted;
        }

        public List<CEntities> MGetAllData() {
            List<CEntities> projectList = null;
            DbConnection conn = null;
            DbCommand cmd = null;
            try {
                conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;
                cmd = conn.CreateCommand();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetAllData";

                conn.Open();
                DbDataReader reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                reader.Close();

                projectList = new List<CEntities>();

                for(int index = 0; index < table.Rows.Count; index++) {
                    CEntities entity = new CEntities();
                    entity.PROJECT_ID = (int)table.Rows[index][0];
                    entity.PROJECT_NAME = (string) table.Rows[index][1];
                    entity.PROJECT_LOCATION = (string) table.Rows[index][2];
                    entity.PROJECT_BUDGET = Convert.ToDouble(table.Rows[index][3]);
                    entity.DATE_OF_START = (DateTime)table.Rows[index][4];
                    projectList.Add(entity);
                    entity = null;
                }

            } catch (Exception Ex) {
                MessageBox.Show(Ex.ToString());
            } finally {
                cmd.Connection.Close();
            }
            return projectList;
        }
    }
}
