﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagementEntities {
    public class CEntities {
        public int PROJECT_ID { get; set; }
        public string PROJECT_NAME { get; set; }
        public string PROJECT_LOCATION { get; set; }
        public double PROJECT_BUDGET { get; set; }
        public DateTime DATE_OF_START { get; set; }
    }
}
