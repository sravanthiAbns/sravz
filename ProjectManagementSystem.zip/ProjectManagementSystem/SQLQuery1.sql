use ProjectManagement

Create Table ProjectData (
	ProjectID int IDENTITY(1,1),
	ProjectName varchar(50),
	ProjectLocation varchar(50),
	ProjectBudget real,
	DateOfStart DateTime,
	Primary Key (ProjectID)
)
go

Create Proc AddProject
	@ProjectName varchar(50),
	@ProjectLocation varchar(50),
	@ProjectBudget real,
	@ProjectDateOfStart DateTime
AS
BEGIN
	Insert into ProjectData values (
		@ProjectName, 
		@ProjectLocation,
		@ProjectBudget,
		@ProjectDateOfStart
	)
END

go
Create Proc GetAllData
As
Begin
	Select * from ProjectData;
End