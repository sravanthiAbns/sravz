﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter directory path:");
            string str = Console.ReadLine();
            DirectoryInfo d = new System.IO.DirectoryInfo(str);
            FileInfo[] files = d.GetFiles();
            DirectoryInfo[] subdirectory = d.GetDirectories();
            Console.WriteLine("No of files: "+files.Count());
            Console.WriteLine("No of folders: " + subdirectory.Count());
        }
    }
}
