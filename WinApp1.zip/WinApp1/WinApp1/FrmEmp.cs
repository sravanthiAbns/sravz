﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp1
{
    public partial class FrmEmp : Form
    {
        public string str;
        public FrmEmp()
        {
            InitializeComponent();
        }

        private void FrmEmp_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected_1(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            str += "DOJ -" + dateTimePicker1.Text + "\n";
            str += "CITY -" +comboBox2.Text + "\n";
            str += "Mobile -" + maskedTextBox1.Text + "\n";
            str += "Skills -";

            foreach (string item in listBox1.SelectedItems)
            {
                str += item + "";
            }
            str += "\n";
            str += "Languages -";
            foreach (Object o in groupBox2.Controls)
            {
                if(o is CheckBox)
                    if (((CheckBox)o).Checked == true)
                    {
                        str += ((CheckBox)o).Text + "";
                    }
            }
            str += "\n";
            str += "Gender - ";
            if (radioButton1.Checked == true)
                str += radioButton1.Text;
            else
            {
                str += radioButton2.Text;
            }
            MessageBox.Show(str);
            richTextBox1.Text = str;
            richTextBox1.SaveFile(@"d:\emp1.txt", RichTextBoxStreamType.PlainText);
            
        }
     


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
