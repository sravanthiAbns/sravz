﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp1
{
    public partial class MainMDIFrm : Form
    {
        public MainMDIFrm()
        {
            InitializeComponent();
        }

        private void MainMDIFrm_Load(object sender, EventArgs e)
        {
          
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form frm = new newform();
            frm.MdiParent = this;
            frm.Show();
        }

        private void form2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new FrmEmp();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
