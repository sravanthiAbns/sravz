﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ContentControls
{
    /// <summary>
    /// Interaction logic for EmployeeForm.xaml
    /// </summary>
    public partial class EmployeeForm : Window
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = combostates.SelectedIndex;
            string state=((ListBoxItem)combostates.SelectedItem).Content.ToString();
            combocities.Items.Clear();
            combocities.Items.Add("Select a city");
            if (index == 0)
            {
                return;
            }
            if (state == "AndhraPradesh")
            {
                combocities.Items.Add("Vijayawada");
                combocities.Items.Add("Visakhapatnam");
                combocities.Items.Add("Rajahmundry");

            }
            else
            {
                combocities.Items.Add("Mumbai");
                combocities.Items.Add("Pune");
               

            }

            

        }

        private void subbtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder data = new StringBuilder();
            data.Append(txtname.Text + "/n");
            DateTime dt = (DateTime)dateobj.SelectedDate;
            data.Append(dt.ToShortDateString());
            if (radioButton.IsChecked == true)
                data.Append("Male" + "\n");
            else
                data.Append("Female" + "\n");
            if (chkskill1.IsChecked == true)
                data.Append("C");
            if(chkskil2.IsChecked==true)
                data.Append("C++");
            if (chkskil3.IsChecked == true)
                data.Append("C#");
            data.Append("\n");
            data.Append(combocities.Text + "(" + combostates.Text + ")");
            MessageBox.Show(data.ToString());
        }

        private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void ComboBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
