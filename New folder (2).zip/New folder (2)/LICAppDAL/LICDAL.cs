﻿using System;
using System.Collections.Generic;
using System.Linq;
using LICAppEntities;
using LICAppExceptions;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;

namespace LICAppDAL
{
    public class LICDAL
    {
        //method for finding slabname
        public List<Policy> GetPolicyName()
        {
            List<Policy> pList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getPolicyDetails";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    pList = new List<Policy>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Policy p = new Policy();
                        p.POLICYID = (int)dataTable.Rows[rowCounter][0];
                        p.POLICYNAME = (string)dataTable.Rows[rowCounter][1];
                        pList.Add(p);
                    }



                }
            }
            catch (DbException ex)
            {
                throw new LICExceptions(ex.Message);
            }
            return pList;
        }


        public List<Branches> GetBranchName()
        {
            List<Branches> bList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getBranchDetails";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    bList = new List<Branches>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Branches b= new Branches();
                       b.BRANCHID = (int)dataTable.Rows[rowCounter][0];
                        b.BRANCHNAME = (string)dataTable.Rows[rowCounter][1];
                        bList.Add(b);
                    }



                }
            }
            catch (DbException ex)
            {
                throw new LICExceptions(ex.Message);
            }
            return bList;
        }




        public bool AddCustomers(Customers cm)
        {
            bool cmAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "insertCustomerDetails";

                DbParameter param = command.CreateParameter();
                
                

                param = command.CreateParameter();
                param.ParameterName = "@custName";
                param.DbType = DbType.String;
                param.Value = cm.CUSTNAME;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@custDOB";
                param.DbType = DbType.DateTime;
                param.Value = cm.CUSTDOB;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@custAddress";
                param.DbType = DbType.String;
                param.Value = cm.ADDRESS;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@policyId";
                param.DbType = DbType.Int32;
                param.Value = cm.POLICYID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@branchId";
                param.DbType = DbType.Int32;
                param.Value = cm.BRANCHID;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    cmAdded = true;
            }
            catch (DbException ex)
            {

                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new LICExceptions(errormessage);
            }
            return cmAdded;
        }
    }
}
