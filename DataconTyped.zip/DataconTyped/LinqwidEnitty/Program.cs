﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqwidEnitty
{
    class Program
    {
        static void Main(string[] args)
        {
            // let d object name be context, it is like adapter
           trainingEntities context = new trainingEntities();
            ////var result = from emp in context.Employee1
            ////             where emp.empsal > 25000
            ////             select emp;
            ////foreach(Employee1 e in result)
            ////{
            ////    Console.WriteLine("{0} {1}", e.empname, e.empsal);
            ////}
            ////Console.ReadLine();

            //Employee1 newEmp = new Employee1();
            //newEmp.empno = 1015;
            //newEmp.empname = "Emp1015";
            //newEmp.empsal = 26789;
            //newEmp.emptype = "C";
            //context.Employee1.Add(newEmp);

            // delete a record
            Employee1 tobedeleted = (from emp in context.Employee1 where
                                   emp.empno == 1
                                   select emp).FirstOrDefault();
            context.Employee1.Remove(tobedeleted);

            // update
            Employee1 tobupdated = (from emp in context.Employee1
                                    where emp.empno == 2
                                    select emp).FirstOrDefault();
            tobupdated.empname = "sravanthi";


            context.SaveChanges();// only once
        }
    }
}
