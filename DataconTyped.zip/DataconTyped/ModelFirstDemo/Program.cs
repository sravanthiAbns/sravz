﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelFirstDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Model1Container context = new Model1Container();
            Bus obj = new Bus() { Company = "Volvo", Year = 2017 };
            context.Buses.Add(obj);
            context.SaveChanges();
        }
    }
}
