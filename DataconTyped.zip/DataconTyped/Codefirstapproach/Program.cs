﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codefirstapproach
{
    class Programs
    {
        //will create the table automatically
        static void Main(string[] args)
        {
            CarDBContext context = new CarDBContext();
            Car carobj = new Car()
            {
                Company = "Hyundai",
                YearOfMake = 2017,
                Model = "i20"
            };
            context.cars.Add(carobj);
            context.SaveChanges();
            
        }
    }
}
