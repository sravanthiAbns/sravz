﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace Codefirstapproach
{
    class CarDBContext : DbContext
    {
        public CarDBContext() : base("DBConString") { }

        public DbSet<Car> cars { get; set; }
    }
}
