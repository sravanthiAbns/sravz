﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> phrases = new List<string>() { "an apple a day", "the quick brown fox" };

            var query = from phrase in phrases
                        from word in phrase.Split(' ')
                        select word;

            var query2 = phrases.Where(x => x.StartsWith("a"));

            foreach (string s in query)
                Console.WriteLine(s);

            //define your data source
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8 };

            // define LINQ query
            // query syntax of linq
            var result = from item in numbers
                         where item % 2 == 0
                         select item;

            // deffered exceution 
            // Execute LINQ Query
             
            foreach (int s in result)
                Console.WriteLine(s);
            // will display theoutput after d above cmnd

            // method syntax of linq
            var result2 = numbers.Where(x => x % 2 == 0);

            // mixed syntax
            int countofnums = (from item in numbers
                               where item % 2 == 0
                               select item).Count();
            // returns a single value
            // executive scalar

            Console.WriteLine(countofnums);
            Console.ReadLine();
        }
    }
}
