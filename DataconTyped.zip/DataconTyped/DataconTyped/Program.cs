﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DataconTyped
{
    class Program
    {
        static void Main(string[] args)
        {
            Empdataset ds = new Empdataset();
            EmpdatasetTableAdapters.EmployeeTableAdapter adapter = new EmpdatasetTableAdapters.EmployeeTableAdapter();
            adapter.Fill(ds.Employee);
            Console.WriteLine(ds.Employee.Rows.Count);

            foreach(Empdataset.EmployeeRow er in ds.Employee.Rows)
            {
                Console.WriteLine(er.EmpId);
            }
            Empdataset.EmployeeRow emprow = ds.Employee.FindByEmpId(2);
            Console.WriteLine(emprow.FirstName);

            DataRow newrow = ds.Employee.NewRow();
            Empdataset.EmployeeRow row = (Empdataset.EmployeeRow)newrow;
            row.FirstName = "sravs";
            row.LastName = "Akula";
            row.Gender = "F";
            row.Age = 12;
            row.Address = "vizag";
            ds.Employee.Rows.Add(row);
            adapter.Update(ds);
        }
    }
}
