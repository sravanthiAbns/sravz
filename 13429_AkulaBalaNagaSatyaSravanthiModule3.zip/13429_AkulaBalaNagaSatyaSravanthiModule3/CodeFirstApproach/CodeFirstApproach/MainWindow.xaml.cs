﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Contexts context = new Contexts();
        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Restaurants newEmp = new Restaurants();
                newEmp.RestarantID = Convert.ToInt32(textBox.Text);

                newEmp.RestarantName = textBox1.Text;
                newEmp.RestarantAddress = textBox1.Text;
                newEmp.RestarantEmailID = textBox1.Text;
                newEmp.RestarantPhoneNo = textBox1.Text;
                newEmp.RestarantCuisines = textBox1.Text;
                newEmp.openingtime = textBox1.Text;
                newEmp.closingtime = textBox1.Text;


                context.emp.Add(newEmp);
                context.SaveChanges();
                var result2 = from rest in context.emp
                              select rest;
                MessageBox.Show("restaurant details are added succesfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("details cannot be inserted");
            }
        }
    }
}
