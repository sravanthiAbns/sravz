﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CodeFirstApproach
{
    class Contexts : DbContext
    {
        public Contexts() : base("DBConString") { }

        public DbSet<Restaurants> emp { get; set; }
    }
}
