﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace CodeFirstApproach
{
    class Restaurants
    {
        [Key]
        public int RestarantID { get; set; }
        public string RestarantName { get; set; }

        public string RestarantAddress { get; set; }
        public string RestarantEmailID { get; set; }
        public string RestarantPhoneNo { get; set; }
        public string RestarantCuisines { get; set; }

        public string openingtime { get; set; }
        public string closingtime { get; set; }



    }
}
