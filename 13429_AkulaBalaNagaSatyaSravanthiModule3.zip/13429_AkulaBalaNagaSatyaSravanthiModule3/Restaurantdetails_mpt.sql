


use training
create table Restarants(
RestuarantID int primary key ,
RestuarantName varchar(100),
RestuarantAddress varchar(100),
RestuarantEmail varchar(100),
RestuarantPhone varchar(15),
Cuisines varchar(100),
OpeningTime varchar(100),
ClosingTime varchar(100)
);

alter PROCEDURE getrestdetails
(
@restname varchar(100)
)
as
 select RestuarantAddress,RestuarantEmail,RestuarantPhone,Cuisines,OpeningTime,ClosingTime from Restarants where RestuarantName=@restname;
	RETURN

 EXEC getrestdetails NavisInn

	alter PROCEDURE UpdateRestuarantInfo
	(
	@restname varchar(100),
	@restaddress varchar(100),
	@restemailid varchar(100),
	@RestPhoneno varchar(15),
	@cuisines varchar(100),
	@opentime varchar(100),
	@clostime varchar(100)
	)
AS
	update Restarants set RestuarantAddress = @restaddress,RestuarantEmail=@restemailid,RestuarantPhone=@RestPhoneno,Cuisines=@cuisines,OpeningTime=@opentime,ClosingTime=@clostime where RestuarantName=@restname;
	RETURN

	