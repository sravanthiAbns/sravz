﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantEntities
{
    public class RestEntities
    {
        public int RestID { get; set; }
        public string Restname { get; set; }
        public string RestAddress { get; set; }
        public string RestEmail { get; set; }

        public string RestPhone { get; set; }
        public string Cuisines { get; set; }

        public string opentime{ get; set; }
        public string closetime { get; set; }


    }
}
