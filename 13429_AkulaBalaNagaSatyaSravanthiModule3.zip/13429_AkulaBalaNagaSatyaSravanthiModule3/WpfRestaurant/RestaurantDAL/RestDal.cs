﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantEntities;
using RestaurantExceptions;
using System.Data;
using System.Data.Common;

namespace RestaurantDAL
{
    public class RestDal
    {
        //getting or display information
        public RestEntities getrestDetails(string restname)
        {
            RestEntities getrest = null;
            try
            {
                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getrestdetails";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@restname";
                param.DbType = DbType.String;
                param.Value = restname;
                command.Parameters.Add(param);

                // creating a datatable fro selcting 

                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count >= 0)
                {
                    getrest = new RestEntities();
                  
                    //getrest.Restname = dataTable.Rows[0][0].ToString();
                    getrest.RestAddress = dataTable.Rows[0][0].ToString();
                    getrest.RestEmail =dataTable.Rows[0][1].ToString();
                    getrest.RestPhone = dataTable.Rows[0][2].ToString();
                    getrest.Cuisines = dataTable.Rows[0][3].ToString();
                    getrest.opentime = dataTable.Rows[0][4].ToString();
                    getrest.closetime = dataTable.Rows[0][5].ToString();
                    
                }
            
            }
            catch (DbException ex)
            {
                throw new RestExceptions(ex.Message);
            }
            return getrest;


        }

        //update information
        public bool UpdateprojDAL(RestEntities updateproj)
        {
            bool projUpdated = false;
            try
            {
                DbCommand command = DataConnections.createCommand();
                command.CommandText = "UpdateRestuarantInfo";

                DbParameter param = command.CreateParameter();
               
               
                param.ParameterName = "@restname";
                param.DbType = DbType.String;
                param.Value = updateproj.Restname;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@restaddress";
                param.DbType = DbType.String;
                param.Value = updateproj.RestAddress;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@restemailid";
                param.DbType = DbType.String;
                param.Value = updateproj.RestEmail;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@RestPhoneno";
                param.DbType = DbType.String;
                param.Value = updateproj.RestPhone;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@cuisines";
                param.DbType = DbType.String;
                param.Value = updateproj.Cuisines;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@opentime";
                param.DbType = DbType.String;
                param.Value = updateproj.opentime;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@closetime";
                param.DbType = DbType.String;
                param.Value = updateproj.closetime;
                command.Parameters.Add(param);

                int affectedRows = DataConnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    projUpdated = true;
            }
            catch (DbException ex)
            {
                throw new RestExceptions(ex.Message);
            }
            return projUpdated;

        }

        // getting all rest information
        public List<RestEntities> getAllprojDet()
        {
            List<RestEntities> restList = null;
            try
            {
                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getrestdetails";

                // creating a datatable fro selcting 

                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    restList = new List<RestEntities>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        RestEntities getrest = new RestEntities();
                        getrest.Restname = dataTable.Rows[0][0].ToString();
                        getrest.RestAddress = dataTable.Rows[0][1].ToString();
                        getrest.RestEmail = dataTable.Rows[0][2].ToString();
                        getrest.RestPhone = dataTable.Rows[0][3].ToString();
                        getrest.Cuisines = dataTable.Rows[0][4].ToString();
                        getrest.opentime = dataTable.Rows[0][5].ToString();
                        getrest.closetime = dataTable.Rows[0][6].ToString();
                        restList.Add(getrest);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new RestExceptions(ex.Message);
            }
            return restList;
        }

        // search list
        public RestEntities SearchProjDAL(int searchGuestID)
        {
            RestEntities searchGuest = null;
            try
            {
                DbCommand command = DataConnections.createCommand();
                command.CommandText = "Searchproj ";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@projID";
                param.DbType = DbType.Int32;
                param.Value = searchGuestID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchGuest = new RestEntities();
                    searchGuest.RestAddress = dataTable.Rows[0][0].ToString();
                    searchGuest.RestEmail = dataTable.Rows[0][1].ToString();
                    searchGuest.RestPhone = dataTable.Rows[0][2].ToString();
                    searchGuest.Cuisines = dataTable.Rows[0][3].ToString();
                    searchGuest.opentime = dataTable.Rows[0][4].ToString();
                    searchGuest.opentime = dataTable.Rows[0][4].ToString();
                }
            }
            catch (DbException ex)
            {
                throw new RestExceptions(ex.Message);
            }
            return searchGuest;
        }


    }
    }
