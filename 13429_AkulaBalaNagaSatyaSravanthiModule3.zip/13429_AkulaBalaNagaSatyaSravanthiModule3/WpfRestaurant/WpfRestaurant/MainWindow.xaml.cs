﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RestaurantEntities;
using RestaurantDAL;
using RestaurantExceptions;
using RestuarantBAL;

namespace WpfRestaurant
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //List<RestEntities> restList = null;
            //RestDal getallres = new RestDal();
            //restList = getallres.getAllprojDet();
            //comboBox.ItemsSource = restList;
            //comboBox.DisplayMemberPath = "Mariott";
        }
        
        //using combobox
        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string restname;
            restname = textBox.Text;
            RestEntities searchproj = RestBAL.SearchprojBL(restname);
            var obj = comboBox.SelectedItem;
            if (comboBox.SelectedIndex > 0)
            {

                textBox1.Text = searchproj.RestAddress;
                textBox2.Text = searchproj.RestEmail;
                textBox3.Text = searchproj.RestPhone.ToString();
                textBox4.Text = searchproj.Cuisines.ToString();
                textBox5.Text = searchproj.opentime.ToString();
                textBox6.Text = searchproj.closetime.ToString();
            }
        }

        // using textbox
        private void DisplayInformation_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string restname;
                restname = textBox.Text;
                RestEntities searchproj = RestBAL.SearchprojBL(restname);
                if (searchproj != null)
                {
                    textBox1.Text = searchproj.RestAddress;
                    textBox2.Text = searchproj.RestEmail;
                    textBox3.Text = searchproj.RestPhone.ToString();
                    textBox4.Text = searchproj.Cuisines.ToString();
                    textBox5.Text = searchproj.opentime.ToString();
                    textBox6.Text = searchproj.closetime.ToString();

                }
                else
                {
                    MessageBox.Show("restname not found");
                }
            }
            catch (RestExceptions ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        // update information
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string restname;
            restname =textBox1.Text;
           RestEntities updatedGuest = RestBAL.SearchprojBL(restname);
            if (updatedGuest != null)
            {
                //updatedGuest.Restname = textBox.Text;
                updatedGuest.RestAddress = textBox1.Text;
                updatedGuest.RestEmail = textBox2.Text;
                updatedGuest.RestPhone = textBox3.Text;
                updatedGuest.Cuisines = textBox4.Text;
                updatedGuest.opentime = textBox5.Text;
                updatedGuest.closetime = textBox6.Text;

                bool guestUpdated = RestBAL.Updaterest(updatedGuest);
                if (guestUpdated)
                    MessageBox.Show("rest Details Updated");
                else
                    MessageBox.Show("project Details not Updated ");
            }
        }

        // using combobox
        private void combodisplay_Click(object sender, RoutedEventArgs e)
        {
            string restname;
            restname = textBox1.Text;

            RestEntities updaterest = RestBAL.SearchprojBL(restname);
            textBox1.Text = updaterest.RestAddress;
            textBox2.Text = updaterest.RestEmail;
            textBox3.Text = updaterest.RestPhone.ToString();
            textBox4.Text = updaterest.Cuisines.ToString();
            textBox5.Text = updaterest.opentime.ToString();
            textBox6.Text = updaterest.closetime.ToString();

        }
    }
}
