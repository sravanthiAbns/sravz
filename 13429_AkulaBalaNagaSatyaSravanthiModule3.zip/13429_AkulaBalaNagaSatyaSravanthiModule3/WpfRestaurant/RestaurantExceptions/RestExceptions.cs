﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantExceptions
{
    public class RestExceptions : ApplicationException
    {
        public RestExceptions()
            : base()
        {
        }

        public RestExceptions(string message)
            : base(message)
        {
        }
        public RestExceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
