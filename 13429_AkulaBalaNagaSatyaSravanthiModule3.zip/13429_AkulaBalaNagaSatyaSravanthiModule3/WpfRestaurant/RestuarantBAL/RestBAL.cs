﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantDAL;
using RestaurantExceptions;
using RestaurantEntities;
using System.Windows;

namespace RestuarantBAL
{
    public class RestBAL
    {
        private static bool Validproject(RestEntities pent)
        {
            StringBuilder sb = new StringBuilder();
            bool validproj = true;
            //if (pent.projID <= 0)
            //{
            //    validproj = false;
            //    sb.Append(Environment.NewLine + "Invalid Project ID");
            //}
            if (pent.RestEmail == string.Empty)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "Email id Required");
            }
            if (pent.RestPhone.Length != 10)
                {
                   validproj = false;
                   sb.Append(Environment.NewLine + "Phone Number should be 10");
               }

                if (validproj == false)
                throw new RestExceptions(sb.ToString());
            return validproj;

        }

        public static RestEntities SearchprojBL(string searchname)
        {
            RestEntities searchproj = null;
            try
            {
                RestDal projdAL = new RestDal();
                searchproj = projdAL.getrestDetails(searchname);
            }
            catch (RestExceptions ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw ex;
            }
            return searchproj;

        }
        public static bool Updaterest(RestEntities updateproj)
        {
            bool projUpdated = false;
            try
            {
                if (Validproject(updateproj))
                {
                    RestDal guestdAL = new RestDal();
                    projUpdated = guestdAL.UpdateprojDAL(updateproj);
                }
            }
            catch (RestExceptions ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projUpdated;
        }

        public static RestEntities Mainsearch(int searchGuestID)
        {
            RestEntities searchGuest = null;
            try
            {
                RestDal guestDAL = new RestDal();
                searchGuest = guestDAL.SearchProjDAL(searchGuestID);
            }
            catch (RestExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;

        }


    }
}
