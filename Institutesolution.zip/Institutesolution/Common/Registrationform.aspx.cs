﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using InstitBAL;
using InstitExceptions;
using IstitEntities;
using System.Windows.Forms;

namespace Institutesolution
{
    public partial class Registrationform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<Student> corsname = Insbal.GetcourseBL();

                DropDownList2.DataSource = corsname;
                DropDownList2.DataTextField = "CorseName";
                DropDownList2.DataValueField = "CorseID";
                DropDownList2.DataBind();


                List<Student> brname = Insbal.GetBranch();
                DropDownList1.DataSource = brname;
                DropDownList1.DataTextField = "City";
                DropDownList1.DataValueField = "InstiID";
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
               Student newProj = new Student();

                //newProj.projID = Convert.ToInt32(txtprojd.Text);

                newProj.StudName = textbox1.Text;
                newProj.DOB = TextBox2_CalendarExtender.SelectedDate.Value;
               
                newProj.CorseID = Convert.ToInt32(DropDownList2.SelectedItem.Value);
                newProj.InstiID = Convert.ToInt32(DropDownList1.SelectedItem.Value);
                bool projAdded =Insbal.Addstud(newProj);

                if (projAdded)
                    Label8.Text = "Student Added";
                  
                else
                    Label8.Text = "Student not Added";
            }
            catch (Exception ex)
            {
                Label8.Text = ex.ToString();
            }
        }

        protected void Unnamed1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
