﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IstitEntities
{
   public class Courses
    {
        //public int CorseID { get; set; }
        //public string CorseName { get; set; }
       
    }
}
