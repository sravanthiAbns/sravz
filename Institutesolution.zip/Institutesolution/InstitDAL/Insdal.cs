﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InstitExceptions;
using IstitEntities;
using System.Data;
using System.Data.Common;



namespace InstitDAL
{
    public class Insdal
    {
        public List<Student> getpolicyname()
        {

            List<Student> getpolicy = null;
            try
            {

                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getcoursename";
                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count >= 0)
                {
                    getpolicy = new List<Student>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                       Student getrest = new Student();
                        getrest.CorseName = dataTable.Rows[rowCounter][0].ToString();
                        getrest.CorseID = Convert.ToInt32(dataTable.Rows[rowCounter][1]);
                        getpolicy.Add(getrest);
                    }
                }
            }
            catch (InsExceptions ex)
            {
                throw new InsExceptions(ex.Message);
            }
            return getpolicy;
        }

        public List<Student> getcityname()
        {

            List<Student> getcity = null;
            try
            {

                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getcity";
                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count >= 0)
                {
                    getcity = new List<Student>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Student getrest = new Student();
                        getrest.City = dataTable.Rows[rowCounter][0].ToString();
                       getrest.InstiID = Convert.ToInt32(dataTable.Rows[rowCounter][1]);
                        getcity.Add(getrest);
                    }
                }
            }
            catch (InsExceptions ex)
            {
                throw new InsExceptions(ex.Message);
            }
            return getcity;
        }

        public bool addproj(Student newproj)
        {
            bool addguest = false;
            try
            {
                // how to relate dis with dataconnection layer
                DbCommand command = DataConnections.createCommand();
                command.CommandText = "addstud";

                DbParameter param = command.CreateParameter();


                param = command.CreateParameter();
                param.ParameterName = "@studName";
                param.DbType = DbType.String;
                param.Value = newproj.StudName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dob";
                param.DbType = DbType.Date;
                param.Value = newproj.DOB.Date;
                command.Parameters.Add(param);

                //param = command.CreateParameter();
                //param.ParameterName = "@city";
                //param.DbType = DbType.String;
                //param.Value = newproj.City;
                //command.Parameters.Add(param);

                //param = command.CreateParameter();
                //param.ParameterName = "@coursename";
                //param.DbType = DbType.Int32;
                //param.Value = newproj.CorseName;
                //command.Parameters.Add(param);

                //param = command.CreateParameter();
                //param.ParameterName = "@admisndtae";
                //param.DbType = DbType.Date;
                //param.Value = newproj.AdminDate.Date;
                //command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@corseId";
                param.DbType = DbType.Int32;
                param.Value = newproj.CorseID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@InstiId";
                param.DbType = DbType.Int32;
                param.Value = newproj.InstiID;
                command.Parameters.Add(param);

                int affectedRows = DataConnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    addguest = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.ToString()+ex.Message;
                        break;
                }
                throw new InsExceptions(errormessage);
            }
            return addguest;
        }

    }
}
