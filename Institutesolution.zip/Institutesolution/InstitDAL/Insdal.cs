﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InstitExceptions;
using IstitEntities;


namespace InstitDAL
{
    public class Insdal
    {
        public List<Policy> getpolicyname()
        {

            List<Policy> getpolicy = null;
            try
            {

                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getpolicyname";
                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count >= 0)
                {
                    getpolicy = new List<Policy>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Policy getrest = new Policy();
                        getrest.PolicyName = dataTable.Rows[rowCounter][0].ToString();
                        getrest.PolicyID = Convert.ToInt32(dataTable.Rows[rowCounter][1]);
                        getpolicy.Add(getrest);
                    }
                }
            }
            catch (Exceptions ex)
            {
                throw new Exceptions(ex.Message);
            }
            return getpolicy;
        }

        public List<Branches> getbranchname()
        {

            List<Branches> getbranch = null;
            try
            {

                DbCommand command = DataConnections.createCommand();
                command.CommandText = "getbranchname";
                DataTable dataTable = DataConnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count >= 0)
                {
                    getbranch = new List<Branches>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Branches getrest = new Branches();
                        getrest.BranchName = dataTable.Rows[rowCounter][0].ToString();
                        getrest.BranchId = Convert.ToInt32(dataTable.Rows[rowCounter][1]);
                        getbranch.Add(getrest);
                    }
                }
            }
            catch (Exceptions ex)
            {
                throw new Exceptions(ex.Message);
            }
            return getbranch;
        }

    }
}
