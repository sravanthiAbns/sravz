﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace InstitDAL
{
    class DataConfiguration
    {
        private static string providername;

        public static string providerName
        {
            get { return DataConfiguration.providername; }
            set { DataConfiguration.providername = value; }
        }
        private static string connectionstring;
        public static string connectionString
        {
            get { return DataConfiguration.connectionstring; }
            set { DataConfiguration.connectionstring = value; }
        }

        // use of constructor
        static DataConfiguration()
        {
            //defined in constructor
            // y only field name but property , meaning of this sentence

            providername = ConfigurationManager.ConnectionStrings["projectConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["projectConnection"].ConnectionString;
        }

    }
}
