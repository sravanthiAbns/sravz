﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataControlssnew
{
    public partial class WebwidMaster1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Text = "Products of CategoryID -" + GridView1.SelectedValue + ",CategoryName - " + GridView1.SelectedRow.Cells[2].Text;
        }
    }
}