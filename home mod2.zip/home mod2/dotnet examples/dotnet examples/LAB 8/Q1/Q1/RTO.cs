﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Q1
{
    class RTO
    {
        public string RtoId { get; set; }
        public string District { get; set; }

        Hashtable rto = new Hashtable();

        public void AddRecord(string id, string dis)
        {
            rto.Add(id, dis);
        }

        public void Search(string id)
        {
            string result;
            foreach (DictionaryEntry item in rto)
            {
                if ((string)item.Key == id)
                {
                    result = (string)item.Value;
                    Console.WriteLine("RTO {0} has District {1}",id,result);
                    break;
                }
            } 
        }

        public void DisplayAll()
        {
            foreach (DictionaryEntry item in rto)
            {
                string id = (string)item.Key;
                string name = (string)item.Value;
                Console.WriteLine("RTO ID: {0}\tDistrict: {1}",id,name);
            }
        }

        public void CountRecords()
        {
            Console.WriteLine(@"Total No. of Key/Value pairs are {0}",rto.Count);
        }

        public void DeleteRecord(string id)
        {
            foreach (DictionaryEntry item in rto)
            {
                if ((string)item.Key == id)
                {
                    rto.Remove(id);
                    break;
                }
            }
        }
    }
}
