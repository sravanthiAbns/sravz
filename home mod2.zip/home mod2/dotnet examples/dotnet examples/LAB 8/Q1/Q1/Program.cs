﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Q1
{
    class Program
    {
        static RTO obj = new RTO();
        static void Main(string[] args)
        {
            int choice = 0;
            do
            {
                Menu();
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddRecord();
                        break;
                    case 2:
                        Search();
                        break;
                    case 3:
                        DisplayAll();
                        break;
                    case 4:
                        CountRecords();
                        break;
                    case 5:
                        DeleteRecord();
                        break;
                    case 6:
                        break;
                    default:
                        break;
                }
            } while (choice != 6);
        }

        static void AddRecord()
        {
            Console.WriteLine("Enter RTO ID");
            obj.RtoId = Console.ReadLine();
            Console.WriteLine("Enter district");
            obj.District = Console.ReadLine();

            obj.AddRecord(obj.RtoId,obj.District);
        }

        static void Search()
        {
            Console.WriteLine("Enter the RTO id");
            string search = Console.ReadLine();
            obj.Search(search);
        }

        static void DisplayAll()
        {
            obj.DisplayAll();
        }

        static void CountRecords()
        {
            obj.CountRecords();
        }

        static void DeleteRecord()
        {
            Console.WriteLine("Enter id of the record");
            string id = Console.ReadLine();
            obj.DeleteRecord(id);
        }

        static void Menu()
        {
            Console.WriteLine("1. Add Record\n2. Search\n3. Display All Records\n4. Display Count of Records\n5. Delete a Record\n6. EXIT");
        }
    }
}
