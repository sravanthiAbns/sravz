﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable main = GetHashtable();
            //Task 1
            Console.WriteLine(main.ContainsKey("Perimeter"));
            Console.WriteLine(main.Contains("Perimeter"));

            //Task 2
           

            //Task 3
            main.Remove("Mortgage");
            foreach (DictionaryEntry item in main)
            {
                Console.WriteLine(item.Key);
            }
        }

        static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }

    }

}
