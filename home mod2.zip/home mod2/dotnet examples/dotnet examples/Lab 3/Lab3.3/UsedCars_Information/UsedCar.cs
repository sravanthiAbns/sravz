﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsedCars_Information
{
    public class UsedCar
    {
        string make;
        public string Make { get { return make; } set { make = value; } }

        string model;
        public string Model { get { return model; } set { model = value; } }

        DateTime year;
        public DateTime Year { get { return year; } set { year = value; } }

        int price;
        public int SalesPrice { get { return price; } set { price = value; } }

        public void CarsInfo()
        {

        }

        public void CarsInfo(string Make, string Model, DateTime Year, int Saleprice)
        {
            make = Make;
            model = Model;
            year = Year;
            price = Saleprice;
        }

        public void PrintDetails()
        {
            Console.WriteLine("Make:{0} Model:{1} Year:{2} Sales Price:{3}",
                Make,Model,Year.ToShortDateString(),SalesPrice);
        }
    }
}
