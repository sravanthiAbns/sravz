﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UsedCars_Information;
namespace UsedCars
{
    class Program
    {
        static UsedCar usec = new UsedCar();
        static UsedCar[] usercar = new UsedCar[100];
        static void Main(string[] args)
        {
            PrintMenu();
        }



        static void PrintMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("Hello! What would you like to do");
                Console.WriteLine();
                Console.WriteLine("1.Add a new car.\n2.Modify the details\n3.Search\n4.List all cars\n5.Exit");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCar();
                        Console.WriteLine("Information added successfully");
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        PrintAll();
                        Console.WriteLine();
                        break;
                    case 5:
                        break;
                  
                    default:
                        break;
                }

            } while (choice != 5);
            }
        static void AddCar()
        {
            Console.WriteLine("Enter the number of cars information to be added");
            int num = int.Parse(Console.ReadLine());
            for(int i=0;i<num;i++)
            {
                SetData();
                usercar[i] = usec;
            }
        }

        static void SetData()
        {
            usec = new UsedCar();
            Console.WriteLine("Enter the maker of the car");
            usec.Make = Console.ReadLine();
            Console.WriteLine("Enter the Model");
            usec.Model = Console.ReadLine();
            Console.WriteLine("Enter the year");
            usec.Year = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Sales Price");
            usec.SalesPrice = int.Parse(Console.ReadLine());
        }

        static void PrintAll()
        {
            foreach (UsedCar item in usercar)
            {
                item.PrintDetails();
                Console.WriteLine();
            }
        }
    }
}
