﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SupplierTest;
namespace Supplier
{
    class Program
    {
        static void Main(string[] args)
        {
            SupplierDetails supdetails = new SupplierDetails();
            Console.WriteLine("Enter the id");
            supdetails.SupplierID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name");
            supdetails.SupplierName = Console.ReadLine();
            Console.WriteLine("Enter the city");
            supdetails.City = Console.ReadLine();
            Console.WriteLine("Enter the PhoneNumber");
            supdetails.PhoneNo = Console.ReadLine();
            Console.WriteLine("Enter the email");
            supdetails.Email = Console.ReadLine();
            supdetails.DisplayDetails();
               
        }
       
    }
}
