﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTest
{
    public class SupplierDetails
    {
        int supplierID;
        string supplierName;
        string city;
        string phoneNo;
        string email;

        

        public int SupplierID
        {
            get { return supplierID; }
            set { supplierID = value; }
        }
                public string SupplierName
        {
            get { return supplierName; }
            set { supplierName = value; }
        }

      
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        
        public string PhoneNo
        {
            get { return phoneNo; }
            set { phoneNo = value; }
        }

       
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public void AcceptDetails(int id,string name,string City,string phone,string Email)
        {
            supplierID = id;
            supplierName = name;
            city = City;
            phoneNo = phone;
            email = Email;
        }

        public void DisplayDetails()
        {
            Console.WriteLine("ID:{0} Name:{1} City:{2} PhoneNo:{3} Email:{4}",
                SupplierID,SupplierName,City,PhoneNo,Email);
        }





    }
}
