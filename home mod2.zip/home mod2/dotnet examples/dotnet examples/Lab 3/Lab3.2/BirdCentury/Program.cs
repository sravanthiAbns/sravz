﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirdCentury
{
    class Program
    {
        static void Main(string[] args)
        {
            Bird b = new Bird("Eagle", 200);
            b.fly();
            b.fly(300);
            Console.ReadKey();
        }
    }
}
