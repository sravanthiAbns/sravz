﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Details
{
    public class Participant
    {
        private int empId;
        public int EmpId { get { return empId; } set { empId = value; } }

        private string name;
        public string Name { get { return name; } set { name = value; } }

        private static string companyName;
        public string CompanyName { get { return companyName; } set { companyName = value; } }

        private int foundationMarks;
        public int FoundationMarks
        {
            get
            {
                return foundationMarks;
            }
            set
            {
                if (value > 0 && value <= 100)
                {
                    foundationMarks = value;
                }
                else
                {
                    throw new Exception("Marks should be between 0 to 100");
                }
            }
        }

        private int webBasicMarks;
        public int WebBasicMarks
        {
            get
            {
                return webBasicMarks;
            }
            set
            {
                if (value > 0 && value <= 100)
                {
                    webBasicMarks = value;
                }
                else
                {
                    throw new Exception("Marks should be between 0 to 100");
                }

            }
        }

        private int dotNetMarks;
        public int DotNetMarks
        {
            get
            {
                return dotNetMarks;
            }
            set
            {
                if (value > 0 && value <= 100)
                {
                    dotNetMarks = value;
                }
                else
                {
                    throw new Exception("Marks should be between 0 to 100");
                }

            }
        }

        private int obtainedMarks;
        public int ObtainedMarks { get; set; }

        private int totalMarks = 300;
        public int TotalMarks { get; set; }

        private double percentage;
        public double Percentage { get; set; }

        public Participant()
        {
            empId = 101;
            name = "sagar";
            companyName = "capgemini";
            foundationMarks = 70;
            webBasicMarks = 89;
            dotNetMarks = 67;
        }

        public Participant(int empid, string name1, string companyname, int foundationmarks, int webbasicmarks, int dotnetmarks)

        {
            empId = empid;
            name = name1;
            companyName = companyname;
            foundationMarks = foundationmarks;
            webBasicMarks = webbasicmarks;
        }

        static Participant()
        {
            companyName = "Accenture";
        }

        public int ObtainedMarks1(int foundationmarks, int webbasicmarks, int dotnetmarks)
        {
            int obtainedmarks = foundationmarks + webbasicmarks + dotnetmarks;
            return obtainedmarks;
        }

        public float CalPercent(int obtainedmarks)
        {
            float Percent = ((float)obtainedmarks / (float)totalMarks) * 100;
            return Percent;
        }
    }
}
