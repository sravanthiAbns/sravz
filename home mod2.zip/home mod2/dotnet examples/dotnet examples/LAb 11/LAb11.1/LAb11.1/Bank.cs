﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAb11._1
{
    delegate void MyDelegate(int amount);
    class Bank
    {
        public string CreditCardNo { get; set; }
        public string CardHolderName { get; set; }
        public double BalanceAmount { get; set; }
        public int CreditLimit { get; set; }
        public event MyDelegate Successful;
        public event MyDelegate Unsuccessful;

        public double GetBalance()
        {
            return BalanceAmount;
        }

        public int GetCreditLimit()
        {
            return CreditLimit;
        }
        public void MakePayment(int amount)
        {
            if (amount < CreditLimit)
            {
                BalanceAmount -= amount;
                MakePaymentSuccessful(amount);
            }
            else
            {
                MakePaymentUnsuccessful(amount);
            }

        }
        public void MakePaymentSuccessful(int amount)
        {
            Successful(amount);
        }
        public void MakePaymentUnsuccessful(int amount)
        {
            Unsuccessful(amount);
        }
    }
}
