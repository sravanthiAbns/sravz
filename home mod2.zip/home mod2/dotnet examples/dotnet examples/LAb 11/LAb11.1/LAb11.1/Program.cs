﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAb11._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank b = new Bank();

            Console.WriteLine("Enter Your Balance");
            b.BalanceAmount = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Credit Limit");
            b.CreditLimit = int.Parse(Console.ReadLine());
            b.Successful += new MyDelegate(ICICIPolicy.MakePaymentSuccessful);
            b.Unsuccessful += new MyDelegate(ICICIPolicy.MakePaymentUnsuccessful);
            Console.WriteLine("Enter Withdrawal Amount");
            int amount = int.Parse(Console.ReadLine());
            double balance = b.GetBalance();
            Console.WriteLine("Your Balance is {0}", balance);
            int creditLimit = b.GetCreditLimit();
            Console.WriteLine("Your Withdrawal Limit is Rs.{0}", creditLimit);
            b.MakePayment(amount);
        }
    }
    static class ICICIPolicy
    {

        public static void MakePaymentSuccessful(int amount)
        {
            Console.WriteLine("Withdrawal Completed of amount:{0}", amount);
        }
        public static void MakePaymentUnsuccessful(int amount)
        {
            Console.WriteLine("Withdrawal Unsuccessful of amount:{0}", amount);
        }
    }
}
