﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Book Details - Book Title, Author, Publisher, Price");
            BookDetails b = new BookDetails();
            b.BookDetail();
        }
    }
}
