﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringArrayOneD
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[3];
            Console.WriteLine("Enter Array Elements : ");
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Console.ReadLine();
            }
            Console.WriteLine("The Array Elements Entered Are : ");
            foreach (string item in arr)
            {
                Console.WriteLine(item);
            }
        }
           
        }
    }

