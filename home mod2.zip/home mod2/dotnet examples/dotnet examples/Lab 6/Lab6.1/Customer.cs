﻿using System;
namespace Lab6._1
{
    class Customer
    {
       // Properties
        int custId;
        public int CustId { get; set; }
        string custName;
        public string CustName { get; set; }
        string address;
        public string Address { get; set; }
        string city;
        public string City { get; set; }
        string phoneNo;
        public string PhoneNo { get; set; }
        int limit;

        public int Limit
        {
            get
            {
                return limit;
            }
            set
            {
                if (value > 50000)
                {
                    throw (new InvalidCreditLimitException("Credit Limit cannot be greater than 50000"));
                }
                else
                {
                    limit = value;
                }
            }
        }

        // Constructors

        public Customer()
        {

        }
        public Customer(int a, string b, string c, string f, string d, int e)
        {
            custId = a;
            custName = b;
            address = c;
            city = f;
            phoneNo = d;
            limit = e;
        }


    }
}