﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Employee
    {
        public int Empno { get; set; }
        public string Name { get; set; }
        public int BasicSalary { get; set; }
        public int PF { get; set; }

       public Employee()
        {
            Empno = 123;
            Name = "hetvi";
            BasicSalary = 5000;
            PF = 1000;
        }

     public   Employee(int empno,string name,int basicsalary,int pf)
        {
            Empno = empno;
            Name = name;
            BasicSalary = basicsalary;
            PF = pf;

        }
    }
}
