﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using System.Collections;

namespace _7._3
{
    class Program
    {
        static List<Employee> emplist = new List<Employee>();
        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddEmployee();
                            break;
                        case 2:
                            DeleteRecords();
                            break;
                        case 3:
                            SearchRecords();
                            break;
                        case 4:
                            DisplayAll();
                            break;

                        case 5:

                            break;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;
                    }
                } while (choice != 5);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {

            Console.WriteLine("\n1. Add Employee Details");
            Console.WriteLine("\n2.Delete Employee Details");
            Console.WriteLine("\n3.Search Records");//search
            Console.WriteLine("\n4.View all Records");
            Console.WriteLine("\n5. Exit");
        }


        static void AddEmployee()
        {
            Employee e = new Employee();
           
            Console.WriteLine("Enter Employee no:");
            e.Empno= Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Name:");
            e.Name = Console.ReadLine();

            Console.WriteLine("Enter Basic Salary:");
            e.BasicSalary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter PF:");
            e.PF = Convert.ToInt32(Console.ReadLine());

            emplist.Add(e);
        }


        static void DisplayAll()
        {
            try
            {
                foreach (Employee item in emplist)
                {
                    Console.WriteLine("EmployeeNo:{0}\n EmployeeName:{1}\nBasic Salary:{2}\nPF:{3}",
                        item.Empno, item.Name, item.BasicSalary,item.PF);
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


        static void DeleteRecords()
        {
            try
            {
                bool result = false;
                Console.WriteLine("Enter Employee No");
                int eno = Convert.ToInt32(Console.ReadLine());
                Employee pobj = null;

                foreach (Employee item in emplist)
                {
                    if (item.Empno == eno)
                    {
                        pobj = item;
                        break;
                    }
                }

                if (pobj != null)

                {
                    emplist.Remove(pobj);
                    result = true;
                }

                if (result)
                {
                    Console.WriteLine("Record deleted\n");
                }
                else
                {
                    Console.WriteLine("No Record Found!");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }


        static void SearchRecords()
        {
            Employee e = null;
            Console.WriteLine("Enter the EmployeeNo");
            int eno = Convert.ToInt32(Console.ReadLine());


            foreach (Employee item in emplist)
            {
                if (item.Empno == eno)
                {
                    e = item;
                    break;
                }
            }

            if (e != null)

            {
                Console.WriteLine("EmployeeNo:{0}\n EmployeeName:{1}\nBasic Salary:{2}\nPF:{3}",
                        e.Empno, e.Name, e.BasicSalary, e.PF);
            }
            else
            {
                Console.WriteLine("No Product Found!");
            }
        }
    }
    
}
