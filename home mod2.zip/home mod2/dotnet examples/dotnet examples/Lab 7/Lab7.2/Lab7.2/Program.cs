﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab7._2
{
    class Program
    {
       static  ArrayList al = new ArrayList();
        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddProduct();
                            break;
                        case 2:
                            DeleteProduct();
                            break;
                        case 3:
                            SearchProduct();
                            break;
                        case 4:
                            SortProduct();
                            break;

                        case 5:
                            break;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;
                    }
                } while (choice != 5);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {

            Console.WriteLine("\n1. Add Products");
            Console.WriteLine("\n2.Delete curently searched Product");
            Console.WriteLine("\n3.Search Product");//search
            Console.WriteLine("\n4.Save Product");//sort
            Console.WriteLine("\n5. Exit");
        }

        static void AddProduct()
        {
            Product obj = new Product();
            Console.WriteLine("Enter Product No:");
            obj.ProductNo = Convert.ToInt32(Console.ReadLine());
           
            Console.WriteLine("Enter Product Name:");
            obj.Name = Console.ReadLine();

            Console.WriteLine("Enter Unit Price:");
            obj.Rate = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Product Stock:");
            obj.Stock = Convert.ToInt32(Console.ReadLine());
            al.Add(obj);
        }

        static void SearchProduct()
        {
            try
            {
                Console.WriteLine("Enter Product No:");
                int pno = Convert.ToInt32(Console.ReadLine());


                Product pobj = null;
                foreach (Product item in al)
                {
                    if (item.ProductNo == pno)
                    {
                        pobj = item;
                        break;
                    }
                }
                if (pobj != null)

                {
                    Console.WriteLine("ProductNo:{0}\n ProductName:{1}\nUnitPrice:{2}\nStock:{3}",
                       pobj.ProductNo , pobj.Name, pobj.Rate, pobj.Stock);
                }
                else
                {
                    Console.WriteLine("No Product Found!");
                }
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }

            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        static void DeleteProduct()
        {
            try
            {
                Console.WriteLine("Enter Product No");
                int pno = Convert.ToInt32(Console.ReadLine());


                bool result = false;
                Product pobj = null;

                foreach (Product item in al)
                {
                    if (item.ProductNo == pno)
                    {
                        pobj = item;
                        break;
                    }
                }

                if (pobj != null)

                {
                    al.Remove(pobj);
                    result = true;
                }
                
                if (result)
                {
                    Console.WriteLine("Product deleted\n");
                }
                else
                {
                    Console.WriteLine("No Product Found!");
                }
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        static void SortProduct()
        {
            try
            {
                al.Sort();
                Console.WriteLine("after sorting on id");
            foreach (Product item in al)
            {
                    Console.WriteLine("ProductNo:{0}\n ProductName:{1}\nUnitPrice:{2}\nStock:{3}",
                           item.ProductNo, item.Name, item.Rate, item.Stock);
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
    }
}
