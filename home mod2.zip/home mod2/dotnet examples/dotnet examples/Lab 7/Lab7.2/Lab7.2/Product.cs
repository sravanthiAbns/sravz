﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab7._2
{
    class Product:IComparable
    {
        public  int ProductNo { get; set; }

        public string Name { get; set; }

        public double Rate { get; set; }

        public int Stock { get; set; }

        public int CompareTo(object obj)
        {

            Product pro = (Product)obj;
            if (this.ProductNo > pro.ProductNo)
            {
                return 1;

            }
            else if (this.ProductNo == pro.ProductNo)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}
