﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace lab_7
{
   
    class Program
    {
        static List<Contact> contactlist = new List<Contact>();
        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddContacts();
                            break;
                        case 2:
                            ShowAllContact();
                            break;
                        case 3:
                            DisplayContact();
                            break;
                        case 4:
                            Editcontact();
                            break;
                       
                        case 5:
                            break;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;
                    }
                } while (choice != 5);
            }
            
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        static void PrintMenu()
        {
           
            Console.WriteLine("\n1. Add Contacts");
            Console.WriteLine("\n2. ShowAll Contacts");
            Console.WriteLine("\n3. Display Contact");//search
            Console.WriteLine("\n4. Edit Contact");     
            Console.WriteLine("\n5. Exit");
        }

        static void AddContacts()
        {
            Contact c1 = new Contact();
            Console.WriteLine("Enter the ContactNo");
            c1.ContactNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter contact name");
            c1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Cell No");
            c1.CellNO = Console.ReadLine();
            contactlist.Add(c1);
        }

        static void ShowAllContact()
        {
            try
            {
                foreach (Contact item in contactlist)
                {
                    Console.WriteLine("ContactNo:{0}\n ContactName:{1}\nCellNo:{2}",
                        item.ContactNo, item.ContactName, item.CellNO);
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

        static void DisplayContact()
        {
            Contact c1 = null;
            Console.WriteLine("Enter the ContactNo");
            int cno = Convert.ToInt32(Console.ReadLine());

           
            foreach (Contact item in contactlist)
            {
                if (item.ContactNo == cno)
                {
                    c1 = item;
                    break;
                }
            }

            if (c1 != null)

            {

                Console.WriteLine("ContactNo:{0}\n ContactName:{1}\nCellNo:{2}",
                   c1.ContactNo,c1.ContactName, c1.CellNO);
            }
            else
            {
                Console.WriteLine("No Product Found!");
            }

        }

        static void Editcontact()
        {
            bool result = false;
            Contact c1 = null;
            Console.WriteLine("Enter the ContactNo");
            int cno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the ContactName");
           string cname = Console.ReadLine();
            Console.WriteLine("Enter the Cell No");
            string cellno = Console.ReadLine();
            foreach (Contact item in contactlist)
            {
                if (item.ContactNo == cno)
                {
                    c1 = item;
                    break;
                }
            }

            if (c1 != null)
            {
                c1.ContactNo = cno;
                c1.ContactName = cname;
                c1.CellNO = cellno;
                result = true;
            }
            else
            {
                Console.WriteLine("no matching contact.So cannot update details");
            }
            if (result)
            {
                Console.WriteLine("Product updated successfully");
            }
        }
    }
}
