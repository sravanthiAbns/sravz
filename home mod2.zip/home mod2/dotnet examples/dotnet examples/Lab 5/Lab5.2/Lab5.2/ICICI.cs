﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank;

namespace Lab5._1
{
    class ICICI : Banks
    {
        public override double GetBalance()
        {
            balance = balance + 5000;
            return balance;
        }

        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            bool flag = false;
            double transfer = balance - amount;
            if (transfer >= 5000)
            {

                flag = true;
                Console.WriteLine("Transfer Possible");
            }
            else
            {

                flag = false;
                Console.WriteLine("Transfer not possible");
            }

            return flag;
        }

        public override bool Withdraw(double amount)
        {
            double WithDraw = balance - amount;
            if (WithDraw >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override void CalculateInterest()
        {
            Console.WriteLine("Your Bank is ICICI and your Interest is 7%");
        }

    }
}