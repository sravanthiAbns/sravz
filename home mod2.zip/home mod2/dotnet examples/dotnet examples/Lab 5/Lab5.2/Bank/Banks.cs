﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public abstract class Banks : IBankAccount
    {
        protected double balance;
        public double Balance { get; set; }
        public void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Your Amount is Deposited");
        }


        abstract  public double GetBalance();

        abstract public bool Transfer(IBankAccount toAccount, double amount);

        abstract public bool Withdraw(double amount);
        public abstract void CalculateInterest();

        public enum BankAccountTypeEnum
        {
            Current = 1,
            Saving = 1
        }
        public BankAccountTypeEnum AccountType { get; set; }
    }
}

