﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank;

namespace Lab5._1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            ICICI i1 = new ICICI();
            i1.AccountType = Banks.BankAccountTypeEnum.Saving;
            i1.Deposit(60000);
            double b1 = i1.GetBalance();
            Console.WriteLine("Your Balance is {0}",b1);
            Console.WriteLine("----------------------------------");
            

            ICICI i2 = new ICICI();
            i2.AccountType = Banks.BankAccountTypeEnum.Current;
            i2.Deposit(20000);
            double b2 = i2.GetBalance();
            Console.WriteLine("Your Balance is {0}", b2);
            Console.WriteLine("-----------------------------------------------");

            i1.Transfer(i2, 5000);
            Console.WriteLine("-------------------------------------------------");
            HSBC h1 = new HSBC();
            h1.AccountType = Banks.BankAccountTypeEnum.Saving;
            h1.Deposit(50000);
            double b3 = h1.GetBalance();
            Console.WriteLine("Your Balance is {0}", b3);
            Console.WriteLine("-------------------------------------------------");

            HSBC h2 = new HSBC();
            h2.AccountType = Banks.BankAccountTypeEnum.Current;
            h2.Deposit(60000);
            double b4 = h2.GetBalance();
            Console.WriteLine("Your Balance is {0}", b4);
            Console.WriteLine("--------------------------------------------------");

            

            h1.Transfer(h2, 3000);
            Console.WriteLine("-------------------------------------------------");

            Console.Read();
        }
    }
}
