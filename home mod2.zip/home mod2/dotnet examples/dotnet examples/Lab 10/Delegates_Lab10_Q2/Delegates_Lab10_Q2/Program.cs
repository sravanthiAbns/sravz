﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch = 0;
            Console.WriteLine("Enter First Number");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second Number");
            int n2 = Convert.ToInt32(Console.ReadLine());
            do
            {
                ArithematicOperation obj = new ArithematicOperation();
                Console.WriteLine("\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.MaximumNumber\n6.Exit");
                Console.WriteLine("Enter Your Choice");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                          
                        PerformArithematicOperation(n1,n2,new MathDel(obj.Add));
                        Console.WriteLine();
                        break;
                    case 2:
                        PerformArithematicOperation(n1, n2, new MathDel(obj.Sub));
                        Console.WriteLine();
                      
                        break;
                    case 3:
                        PerformArithematicOperation(n1, n2, new MathDel(obj.Mul));
                        Console.WriteLine();
                        break;
                    case 4:
                        PerformArithematicOperation(n1, n2, new MathDel(obj.Div));
                        Console.WriteLine();
                        break;
                    case 5:
                        PerformArithematicOperation(n1, n2, new MathDel(obj.Max));
                        Console.WriteLine();
                        break;
                    case 6:
                        break;
                    default:
                        Console.WriteLine("Wrong Choice Entered");
                        break;
                }
            } while (ch != 6);
        }

        static void PerformArithematicOperation(int num1,int num2,MathDel md)
        {
            md(num1, num2);
        }
    }
}
