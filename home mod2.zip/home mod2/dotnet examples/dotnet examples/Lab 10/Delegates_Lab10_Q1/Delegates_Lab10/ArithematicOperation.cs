﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Lab10
{
    delegate void MathDel(int n1, int n2);
    class ArithematicOperation
    {
        public void Add(int num1,int num2)
        {
            Console.WriteLine("Result is :{0}",num1 + num2);
        }
        public void Sub(int num1, int num2)
        {
            Console.WriteLine("Result is :{0}", num1 - num2);
        }
        public void Mul(int num1, int num2)
        {
            Console.WriteLine("Result is :{0}", num1 * num2);
        }
        public void Div(int num1, int num2)
        {
            Console.WriteLine("Result is :{0}", num1 / num2);
        }
        public void Max(int num1, int num2)
        {
            if (num1 > num2)
            {
                Console.WriteLine("Result is :{0}", num1);
            }
            else
            {
                Console.WriteLine("Result is :{0}", num2);
            }
        }
    }
}
