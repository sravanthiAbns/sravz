﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Details;
using Q1Assignment1;

namespace Lab1._1
{
   class Program
    {
        static void Main(string[] args)
        {
       
            Console.WriteLine("1.Contract Employee\n2.Permanent Employee");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {

                case 1:
                    Console.WriteLine("Salary for Contract Employee");
                    ContractEmployee cemp1 = new ContractEmployee();
                    cemp1.GetSalary(cemp1.Sal, cemp1.Perks);

                    break;


                case 2:
                    Console.WriteLine("Salary for Permanent Employee");
                    PermanentEmployee pemp1 = new PermanentEmployee();
                   pemp1.GetSalary1(pemp1.Sal, pemp1.PF);
                    
                    break;
                    
                default:
                    Console.WriteLine("Invalid Choice");
                    break;

            }
           

            PermanentEmployee[] emp = new PermanentEmployee[2];
            for (int i = 0; i < 3; i++)
            {
               PermanentEmployee emp1 = new PermanentEmployee();
                emp[i] = new PermanentEmployee();
                Console.WriteLine("Enter the EmpId");
                emp1.EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the EmpName");
                emp1.EmpName = Console.ReadLine();
                Console.WriteLine("Enter the address");
                emp1.Address1 = Console.ReadLine();
                Console.WriteLine("Enter the city");
                emp1.City1 = Console.ReadLine();
                Console.WriteLine("Enter the dept");
                emp1.Dept = Console.ReadLine();
                Console.WriteLine("Enter the salary");
                emp1.Sal = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Enter the Perks");
                emp1.Perks = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Enter the PF");
                emp1.PF = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Welcome \n Your details are as follows:\n Employee ID:{0}\n Employee Name:{1}\n Address:{2} \n City:{3} \n Department:{4}\n Salary:{5} Perks:{6} PF:{7}", emp1.EmpId, emp1.EmpName, emp1.Address1, emp1.City1, emp1.Dept, emp1.Sal, emp1.Perks, emp1.PF);

                //Console.WriteLine("The total salary is");

                //int res = emp1.GetSalary(emp1.Sal,emp1.Perks);
                //Console.WriteLine(res);
                //int res1 = emp1.GetSalary1(emp1.Sal,emp1.PF);
                //Console.WriteLine(res1);

                Console.WriteLine("Salary for Permanent Employee");
                PermanentEmployee pemp1 = new PermanentEmployee();
               
                Console.WriteLine(pemp1.GetSalary1(emp1.Sal, emp1.PF));

                Console.WriteLine("Salary for Contract Employee");
                ContractEmployee cemp1 = new ContractEmployee();
               
                Console.WriteLine(cemp1.GetSalary(emp1.Sal, emp1.Perks));
                Console.ReadLine();


            }
        }
    }
}