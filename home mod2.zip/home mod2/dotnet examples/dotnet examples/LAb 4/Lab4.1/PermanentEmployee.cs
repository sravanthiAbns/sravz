﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Details;


namespace Q1Assignment1
{
    class PermanentEmployee : Employee
    {
        public override int GetSalary(int Sal, int Perks)
        {
            int salary = Sal + Perks;
            return salary;
        }

        public override int GetSalary1(int Sal, int PF)
        {
            {
                int salary = Sal - PF;
                return salary;

            }
        }
    }
}
