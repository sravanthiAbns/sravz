﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    public class Shape
    {
        public void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }
    }
    class Triangle : Shape
    {
        public virtual void WhoamI()
        {
            Console.WriteLine("I m Triangle");
        }
    }

    class Circle : Shape
{ 
    public virtual void WhoamI()
    {
        Console.WriteLine("I m Circle");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Shape s;
        s = new Triangle();
        s.WhoamI();
        s = new Circle();
        s.WhoamI();
        Console.ReadKey();
    }
}

}
