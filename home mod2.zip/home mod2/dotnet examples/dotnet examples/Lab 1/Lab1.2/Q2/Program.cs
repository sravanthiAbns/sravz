﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArithmeticOperations;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();

            Console.WriteLine("Welcome!");
            Console.WriteLine("Press 1 to perform calculations on integer values.");
            Console.WriteLine("Press 2 to perform calulations on floating values.");
            int firstChoice = int.Parse(Console.ReadLine());

            if (firstChoice == 1)
            {
                Console.WriteLine("Enter values:");
                int firstNumber = int.Parse(Console.ReadLine());
                int secondNumber = int.Parse(Console.ReadLine());

                Console.WriteLine("Choose your option");
                Console.WriteLine("1. Addition\n2. Subtraction\n3. Multipication\n4. Division\n5. Modulus");
                int secondChoice = int.Parse(Console.ReadLine());

                switch (secondChoice)
                {
                    case 1:
                        Console.WriteLine(obj.Add(firstNumber, secondNumber)); 
                        break;
                    case 2:
                        Console.WriteLine(obj.Sub(firstNumber, secondNumber));
                        break;
                    case 3:
                        Console.WriteLine(obj.Multiply(firstNumber, secondNumber)); 
                        break;
                    case 4:
                        Console.WriteLine(obj.Divide(firstNumber, secondNumber)); 
                        break;
                    case 5:
                        Console.WriteLine(obj.Modulus(firstNumber, secondNumber));
                        break;
                    default:
                        break;
                }
            }
            else if (firstChoice == 2)
            {
                Console.WriteLine("Enter values:");
                double firstNumber = double.Parse(Console.ReadLine());
                double secondNumber = double.Parse(Console.ReadLine());

                Console.WriteLine("Choose your option");
                Console.WriteLine("1. Addition\n2. Subtraction\n3. Multipication\n4. Division\n5. Modulus");
                int secondChoice = int.Parse(Console.ReadLine());

                switch (secondChoice)
                {
                    case 1:
                        Console.WriteLine(obj.Add(firstNumber, secondNumber));
                        break;
                    case 2:
                        Console.WriteLine(obj.Sub(firstNumber, secondNumber));
                        break;
                    case 3:
                        Console.WriteLine(obj.Multiply(firstNumber, secondNumber));
                        break;
                    case 4:
                        Console.WriteLine(obj.Divide(firstNumber, secondNumber));
                        break;
                    case 5:
                        Console.WriteLine(obj.Modulus(firstNumber, secondNumber));
                        break;
                    default:
                        break;
                }
            }
            else
            {
                Console.WriteLine("Wrong choice! Please restart the application.");
            }
            
        }
    }
}
