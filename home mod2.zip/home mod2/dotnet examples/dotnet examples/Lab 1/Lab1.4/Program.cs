﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._4
{
    class Program
    {
        static void Main(string[] args)
        {
            SchoolDemo sd = new SchoolDemo();
            SchoolDemo[] s = new SchoolDemo[3];
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Enter the student rollno");
                sd.PRno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Studentname");
                sd.SName = Console.ReadLine();
                Console.WriteLine("Enter the age of student");
                sd.SAge = Convert.ToByte(Console.ReadLine());
                Console.WriteLine("Enter the dateofbirth:");
                sd.SDateOfBirth = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter the address of the student:");
                sd.SAddress = Console.ReadLine();
                Console.WriteLine("Enter the percentage");
                sd.SPercentage = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Rollno :{0}\n Studentname:{1}\n Age:{2}\n DateOfBirth:{3}\n Address:{4}\n Percentage:{5}", sd.PRno, sd.SName, sd.SAge, sd.SDateOfBirth, sd.SAddress, sd.SPercentage);
                Console.ReadLine();
            }
        }
    }
}
