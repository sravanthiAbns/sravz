﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// To store the records of students 
/// </summary>
namespace Lab1._4
{
    public class SchoolDemo
    {
        int rollNumber;
        string studentName;
        byte age;
        char gender;
        DateTime dateOfBirth;
        string address;
        float percentage;

        public SchoolDemo()
        {
            studentName = "";
            age = 0;
            address = "";
            percentage = 0;


        }
        public SchoolDemo(int rollNumber, string studentName, byte age, char gender, DateTime dateOfBirth, string address, float percentage)
        {
            this.rollNumber = rollNumber;
            this.studentName = studentName;
            this.age = age;
            this.gender = gender;
            this.dateOfBirth = dateOfBirth;
            this.address = address;
            this.percentage = percentage;
        }
        public int PRno
        {
            get
            {
                return rollNumber;
            }
            set
            {
                rollNumber = value;
            }

        }
        public string SName
        {
            get
            {
                return studentName;
            }
            set
            {
                studentName = value;
            }

        }
        public byte SAge
        {
            get { return age; }
            set { age = value; }
        }
        public char SGender
        {
            get { return gender; }
            set { gender = value; }
        }
        public DateTime SDateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }
        public string SAddress
        {
            get { return address; }
            set { address = value; }
        }
        public float SPercentage
        {
            get { return percentage; }
            set { percentage = value; }
        }
        public override string ToString()
        {
            string s = "";
            s += "\nPlayer ID\t:\t" + rollNumber;
            s += "\nName\t\t:\t" + studentName;
            s += "\nRuns\t\t:\t" + age;
            s += "\ngender\t\t:\t" + gender;
            s += "\ndateOfBirth\t:\t" + dateOfBirth;
            s += "\naddress\t\t:\t" + address;
            s += "\npercentage\t:\t" + percentage;
            return s;
        }
    }
}
