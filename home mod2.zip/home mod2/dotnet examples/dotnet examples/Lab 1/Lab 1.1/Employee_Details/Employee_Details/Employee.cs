﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Details
{
    public class Employee_D
    {
       
            public int empID;
            public string name;
            public string address;
            public string city;
            public string department;
            public int salary;

            public  void SetData(int empid, string ename, string eaddress, string ecity, string edepartment, int esalary)
            {
                empID = empid;
                name = ename;
                address = eaddress;
                city = ecity;
                department = edepartment;
                salary = esalary;
            }
      
 

    }
}
