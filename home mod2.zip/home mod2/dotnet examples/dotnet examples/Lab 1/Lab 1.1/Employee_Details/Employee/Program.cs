﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee_Details;

namespace Employee
{
    class Program
    {
        public static void Main(string[] args)
        {
            Employee_D emp = new Employee_D();
            Console.WriteLine("Enter Employee ID");
            emp.empID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            emp.name = Console.ReadLine();
            Console.WriteLine("Enter Employee Address");
            emp.address= Console.ReadLine();
            Console.WriteLine("Enter Employee City");
            emp.city= Console.ReadLine();
            Console.WriteLine("Enter Employee Department");
            emp.department= Console.ReadLine();
            Console.WriteLine("Enter Employee Salary");
            emp.salary= int.Parse(Console.ReadLine());

            
            emp.SetData(emp.empID, emp.name, emp.address, emp.city, emp.department, emp.salary);

            Console.WriteLine("Employee ID:{0}",emp.empID);
            Console.WriteLine("Employee Name:{0}", emp.name);
            Console.WriteLine("Address:{0}", emp.address);
            Console.WriteLine("City:{0}", emp.city);
            Console.WriteLine("Department:{0}", emp.department);
            Console.WriteLine("Salary:{0}", emp.salary);

        }
    }
}
