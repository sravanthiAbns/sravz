﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// Console application to test usage of Switch case construct by accepting 1,2,3,4,5 numbers from user as command line argument using a switch case construct
/// </summary>
namespace Lab1._4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter the number : ");
            n = int.Parse(Console.ReadLine());

            switch (n)
            {
                case 1:
                    Console.WriteLine("First....");
                    break;
                case 2:
                    Console.WriteLine("Second....");
                    break;
                case 3:
                    Console.WriteLine("Third....");
                    break;
                case 4:
                    Console.WriteLine("Fourth....");
                    break;
                case 5:
                    Console.WriteLine("Fifth....");
                    break;
                default:
                    Console.WriteLine("Error");
                    break;
            }
            Console.Read();
        }

    }
}