﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9Dictionary
{
    class Dictionary
    {

        static void Main(string[] args)
        {
            Dictionary<string, string> Students = new Dictionary<string, string>();
            //Adding Values to the Dictionary
            Students.Add("S101", "Ramesh");
            Students.Add("S102", "Suresh");
            Students.Add("S103", "Bhavesh");
            Students.Add("S104", "Bhavesh");
            Students.Add("S105", "Ramesh");
           

            Console.WriteLine("============= Student List ===============");

            foreach (KeyValuePair<string,string> item in Students)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            //Trying to add an item which already exists
            try
            {
                Students.Add("S101", "Ravi");
            }
            catch (ArgumentException e)
            {

                Console.WriteLine(e.Message);
            }
            Console.WriteLine();


            // The indexer throws an exception if the requested key is not in the dictionary.
            try
            {
                Console.WriteLine("Enter The Key You Want To See");
                string r3 = Console.ReadLine();
                Console.WriteLine("For key = \"{0}\", value = {1}.",
                    r3,Students[r3]);
            }
            catch (KeyNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }


            //Indexers to change a specific Value in a Dictionary
            Console.WriteLine("Enter The Key You Want To Rename");
            string r1 = Console.ReadLine();
            Students[r1] = "Shiladitya";
            Console.WriteLine("For Key \"{0}\" the present Value = {1}",r1,Students[r1]);
            Console.WriteLine();
            //Printing The updated Values
            foreach (KeyValuePair<string, string> item in Students)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            // If a key does not exist, setting the indexer for that key adds a new key/value pair.
            Console.WriteLine("Enter The Key You Want To Add");
            string r2 = Console.ReadLine();
            Students[r2] = "Ranjana";
            //Printing The updated Values
            foreach (KeyValuePair<string, string> item in Students)
            {
                Console.WriteLine(item);
            }


            //Removing An Item
            Console.WriteLine("Enter the Element to remove");
            string r = Console.ReadLine();
            Students.Remove(r);
            Console.WriteLine();
            //Printing The updated Values
            foreach (KeyValuePair<string, string> item in Students)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
       }
  }
}

