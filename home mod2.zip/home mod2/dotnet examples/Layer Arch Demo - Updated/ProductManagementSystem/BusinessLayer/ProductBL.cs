﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using DataAccessLayer;
using System.Text.RegularExpressions;

namespace BusinessLayer
{
    public class ProductBL
    {
        // Check the product entity for correct values
        public bool Validation(Product pobj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            

            if (pobj.ProductId <= 0)
            {
                sb.Append("ProductId can't be negative.");
                isValid = false;
            }

            if (!Regex.IsMatch(pobj.ProductId.ToString(),"\\d{6}"))
            {
                sb.Append("ProductId must be exactly 6 digits");
                isValid = false;
            }

            if (pobj.ProductName == string.Empty)
            {
                sb.Append("ProductName can't be empty.");
                isValid = false;
            }

            if (!Regex.IsMatch(pobj.ProductName, @"[A-Za-z\S]{3,}"))
            {
                sb.Append("ProductName must be letters and should be 3 or more characters.");
                isValid = false;
            }

            if (pobj.UnitPrice < 50)
            {
                sb.Append("Unit price should be 50 or more.");
                isValid = false;
            }

            if (pobj.Stock < 0)
            {
                sb.Append("Stock can be 0 or more.");
                isValid = false;
            }

            if (pobj.ManufactureDate.ToShortDateString() != DateTime.Now.ToShortDateString())
            {
                sb.Append("Manufacture Date should be the current Date.");
                isValid = false;
            }

            if (!(pobj.Category.ToLower() == "mobile" || pobj.Category.ToLower() == "laptop"))
            {
                sb.Append("Category can be either Mobile or Laptop");
                isValid = false;
            }

            if (isValid == false)
            {
                throw new ProductException(sb.ToString());
            }

            return isValid;
        }

        // A method to add a new product
        public bool AddProduct(Product pobj)
        {
            bool result = false;

            // checking if the product object is valid
            if (Validation(pobj))
            {
                // Creating DAL class object
                ProductOperations po = new ProductOperations();
                // Invoking its AddProduct method
                result = po.AddProduct(pobj);
            }

            return result;
        }

        // A method to dispaly all product
        public List<Product> DisplayProducts()
        {
            // Creating DAL class object
            ProductOperations po = new ProductOperations();
            // Invoking its DisplayProducts method
            return po.DisplayProducts();
        }

        // A method to search a product
        public Product Search(int productId)
        {
            // Creating DAL class object
            ProductOperations po = new ProductOperations();
            // Invoking its Search method
            return po.Search(productId);
        }

        // A method to delete a product
        public bool DeleteProduct(int productId)
        {
            // Creating DAL class object
            ProductOperations po = new ProductOperations();
            // Invoking its DeleteProduct method
            return po.DeleteProduct(productId);
        }

        // A method to update product information
        public bool UpdateProduct(Product pobj)
        {
            bool result = false;

            // checking if the product object is valid
            if (Validation(pobj))
            {
                // Creating DAL class object
                ProductOperations po = new ProductOperations();
                // Invoking its UpdateProduct method
                result = po.UpdateProduct(pobj);
            }

            return result;
        }

        // A method to serialize product list
        public bool Serialize()
        {
            // Creating DAL class object
            ProductOperations po = new ProductOperations();
            // Invoking its Serialize method
            return po.Serialize();
        }

        // A method to Deserialize product list
        public List<Product> Deserialize()
        {
            // Creating DAL class object
            ProductOperations po = new ProductOperations();
            // Invoking its Deserialize method
            return po.Deserialize();
        }
    }
}
