﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer;
using Entities;
using Exceptions;
using System.IO;

namespace PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddProduct();
                            break;
                        case 2:
                            DisplyProducts();
                            break;
                        case 3:
                            Search();
                            break;
                        case 4:
                            UpdateProduct();
                            break;
                        case 5:
                            DeleteProduct();
                            break;
                        case 6:
                            Serialize();
                            break;
                        case 7:
                            Deserialize();
                            break;
                        case 8:
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                while (choice != 8);
            }
            catch (ProductException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintMenu()
        {
            Console.WriteLine("Welcome to Product Management System");
            Console.WriteLine("\n1. Add Product");
            Console.WriteLine("2. Display Products");
            Console.WriteLine("3. Search Product");
            Console.WriteLine("4. Edit Product");
            Console.WriteLine("5. Delete Product");
            Console.WriteLine("6. Serialize");
            Console.WriteLine("7. Deserialize");
            Console.WriteLine("8. Exit");
            Console.WriteLine();
        }

        static void AddProduct()
        {
            try
            {
                // create obj of the entity class
                Product obj = new Product();

                // store all the product attributes
                Console.WriteLine("Enter Product Id");
                obj.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                obj.ProductName = Console.ReadLine();
                Console.WriteLine("Enter Unit Price");
                obj.UnitPrice = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter Product Stock");
                obj.Stock = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Category - [Mobile or Laptop]");
                obj.Category = Console.ReadLine();
                Console.WriteLine("Enter Manufacture Date");
                obj.ManufactureDate = DateTime.Parse(Console.ReadLine());

                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its AddProduct method
                bool result = pbl.AddProduct(obj);
                if (result)
                {
                    Console.WriteLine("Product Added successfully.\n");
                }
            }            
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void DisplyProducts()
        {
            try
            {
                // create the oject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its DisplayProducts method
                List<Product> list = pbl.DisplayProducts();
                // loop through the list
                foreach (Product item in list)
                {
                    // print the product details
                    Console.WriteLine("ProductId:{0}\nProductName:{1}\nUnitPrice:{2}\nStock:{3}\nCategory:{4}\nManufactureDate:{5}",
                        item.ProductId,item.ProductName,item.UnitPrice,item.Stock,item.Category,item.ManufactureDate);
                    Console.WriteLine();
                }
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Search()
        {
            try
            {
                Console.WriteLine("Enter Product Id");
                int pid = Convert.ToInt32(Console.ReadLine());

                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its Search method
                Product p = pbl.Search(pid);

                // Product is found
                if (p != null)
                {
                    // Print its details
                    Console.WriteLine("ProductId:{0}\nProductName:{1}\nUnitPrice:{2}\nStock:{3}\nCategory:{4}\nManufactureDate:{5}\n",
                        p.ProductId, p.ProductName, p.UnitPrice, p.Stock, p.Category, p.ManufactureDate);
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("No Product found.");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void DeleteProduct()
        {
            try
            {
                Console.WriteLine("Enter Product Id");
                int pid = Convert.ToInt32(Console.ReadLine());

                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its DeleteProduct method
                bool result = pbl.DeleteProduct(pid);
                if (result)
                {
                    Console.WriteLine("Product Deleted.\n");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void UpdateProduct()
        {
            try
            {
                // create obj of the entity class
                Product obj = new Product();

                // store all the product attributes
                Console.WriteLine("Enter Product Id");
                obj.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                obj.ProductName = Console.ReadLine();
                Console.WriteLine("Enter Unit Price");
                obj.UnitPrice = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter Product Stock");
                obj.Stock = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Category - [Mobile or Laptop]");
                obj.Category = Console.ReadLine();
                Console.WriteLine("Enter Manufacture Date");
                obj.ManufactureDate = DateTime.Parse(Console.ReadLine());

                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its UpdateProduct method
                bool result = pbl.UpdateProduct(obj);
                if (result)
                {
                    Console.WriteLine("Product updated successfully.\n");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Serialize()
        {
            try
            {
                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its Serialze method
                bool result = pbl.Serialize();
                if (result)
                {
                    Console.WriteLine("Product List Serialized.\n");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Deserialize()
        {
            try
            {
                // create the boject of Business Layer class
                ProductBL pbl = new ProductBL();
                // invoke its Deserialze method
                List<Product> plist = pbl.Deserialize();
                // loop through the list
                foreach (Product item in plist)
                {
                    // print the product details
                    Console.WriteLine("ProductId:{0}\nProductName:{1}\nUnitPrice:{2}\nStock:{3}\nCategory:{4}\nManufactureDate:{5}",
                        item.ProductId, item.ProductName, item.UnitPrice, item.Stock, item.Category, item.ManufactureDate);
                    Console.WriteLine();
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
