﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    // Entity Class
    [Serializable]
    public class Product
    {
        // should be excatly 6 digits
        public int ProductId { get; set; }

        // Allows letters and space
        public string ProductName { get; set; }

        // should be 50 or greater
        public double UnitPrice { get; set; }

        // can't be negative
        public int Stock { get; set; }

        // cab ne either Mobile or Laptop
        public string Category { get; set; }

        // should be current date
        public DateTime ManufactureDate { get; set; }

    }
}
