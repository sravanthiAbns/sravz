﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DataAccessLayer
{
    // Data Access Layer class
    public class ProductOperations
    {
        // A generic list to store all the products
        static List<Product> productList = new List<Product>();

        // A method to add a new product
        // Returns true is success. False if the product is not added
        public bool AddProduct(Product pobj)
        {
            bool result = false;
            try
            {
                productList.Add(pobj);
                result = true;
            }
            catch (ProductException)
            {
                throw;
            }
            return result;
        }

        // A method to display all products from the product list
        public List<Product> DisplayProducts()
        {
            return productList;
        }

        // A method to search a given product from the list
        public Product Search(int productId)
        {
            Product pobj = null;
            foreach (Product item in productList)
            {
                if (item.ProductId == productId)
                {
                    pobj = item;
                    break;
                }
            }
            if (pobj == null)
            {
                throw new Exception("No Product Found.");
            }
            return pobj;
        }

        // A method to delete a product from the list
        public bool DeleteProduct(int productId)
        {
            bool result = false;

            // search prodcut 
            Product pobj = null;
            foreach (Product item in productList)
            {
                if (item.ProductId == productId)
                {
                    pobj = item;
                    break;
                }
            }
            // If found. Remove from the list
            if (pobj != null)
            {
                productList.Remove(pobj);
                result = true;
            }
            else
            {
                throw new ProductException("No Product found to delete.");
            }

            return result;
        }

        // A method to update the product information
        public bool UpdateProduct(Product pobj)
        {
            bool result = false;

            // Search the product
            Product p = null;
            foreach (Product item in productList)
            {
                if (item.ProductId == pobj.ProductId)
                {
                    p = item;
                    break;
                }
            }

            // If found. Update the product information
            if (p!=null)
            {
                p.ProductId = pobj.ProductId;
                p.ProductName = pobj.ProductName;
                p.UnitPrice = pobj.UnitPrice;
                p.Stock = pobj.Stock;
                p.Category = pobj.Category;
                p.ManufactureDate = pobj.ManufactureDate;
                result = true;
            }
            else
            {
                throw new ProductException("No Product found to update.");
            }

            return result;
        }

        // A method to serialize the product list
        public bool Serialize()
        {
            bool result = false;
            try
            {
                // Create FileStream object and specify the file path and FileMode
                FileStream fs = new FileStream("Product.txt", FileMode.Create);
                // Create the binaryFormatter object
                BinaryFormatter formatter = new BinaryFormatter();
                // Invoke the Serialize method and pass FileStream object with ProductList object
                formatter.Serialize(fs, productList);
                // Close the FileStream Object
                fs.Close();
                result = true;
            }
            catch (IOException)
            {
                throw;
            }
            catch(SystemException)
            {
                throw;
            }
            return result;
        }

        // A method to Deserialize the binary data
        public List<Product> Deserialize()
        {
            List<Product> plist = null;

            try
            {
                // Create FileStream object and specify the file path and FileMode
                FileStream fs = new FileStream("Product.txt", FileMode.Open);
                // Create the binaryFormatter object
                BinaryFormatter formatter = new BinaryFormatter();
                // Invoke the Deserialize method and pass FileStream object.
                // Type cast the result to List<Product> and store it in plist
                plist = (List<Product>)formatter.Deserialize(fs);
                // Close the FileStream Object
                fs.Close();               
            }
            catch (IOException)
            {
                throw;
            }
            catch(SystemException)
            {
                throw;
            }

            return plist;
        }
    }
}
