﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    // Product Exception class
    public class ProductException : ApplicationException
    {
        // Default constructor
        public ProductException() 
            : base()
        { }

        // Parameterized constructor which take one string parameter
        public ProductException(string message) 
            : base(message)
        { }

        // Parameterized constructor which take two parameters
        public ProductException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}
