﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;

namespace RestaurantDAL
{
    class DataConnections
    {
        public static DbCommand createCommand()
        {
            //obtain d provider name
            string dataprovname = DataConfiguration.providerName;
            // obtain d connction string
            string connectnstrng = DataConfiguration.connectionString;
            // provide the factory
            DbProviderFactory factory = DbProviderFactories.GetFactory(dataprovname);
            // obtain dtabase conection object
            DbConnection con = factory.CreateConnection();
            //set the connectnn string
            con.ConnectionString = connectnstrng;
            // create a database specific cmnd object
            DbCommand cmd = con.CreateCommand();
            // set d command typr to stored procedure
            cmd.CommandType = CommandType.StoredProcedure;
            // return the command obj
            return cmd;
        }

        // execute select comnd n returns records as datatable
        // Execute a select command and returns Records as DataTable

        public static DataTable ExecuteSelectCommand(DbCommand command)
        {
            //The Datatable to be returned
            DataTable dataTable = null;
            //Execute the command making sure the connection gets closed in the end
            try
            {
                //open the connection
                command.Connection.Open();
                //Execute the Command and store the results in a datatable
                DbDataReader dataReader = command.ExecuteReader();
                dataTable = new DataTable();
                dataTable.Load(dataReader);
                //Close the reader
                dataReader.Close();
            }
            catch (DbException ex)
            {
                throw ex;
            }
            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            return dataTable;
        }

        // execute an update, delete, or insert command 
        // and return the number of affected rows
        public static int ExecuteNonQueryCommand(DbCommand command)
        {
            // The number of affected rows 
            int affectedRows = -1;
            // Execute the command making sure the connection gets closed in the end
            try
            {
                // Open the connection of the command
                command.Connection.Open();
                // Execute the command and get the number of affected rows
                affectedRows = command.ExecuteNonQuery();
            }
            catch (DbException ex)
            {
                throw ex;
            }
            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            // return the number of affected rows
            return affectedRows;
        }

        // execute a select command and return a single result as a string
        public static object ExecuteScalarCommand(DbCommand command)
        {

            // The value to be returned 
            object result = null;
            // Execute the command making sure the connection gets closed in the end
            try
            {
                // Open the connection of the command
                command.Connection.Open();
                // Execute the command and get the aggregate value
                result = command.ExecuteScalar();
            }
            catch (DbException ex)
            {
                throw ex;
            }

            finally
            {
                //Close the Connection
                if (command.Connection.State == ConnectionState.Open)
                    command.Connection.Close();
            }
            // return the result
            return result;
        }
    }
}
