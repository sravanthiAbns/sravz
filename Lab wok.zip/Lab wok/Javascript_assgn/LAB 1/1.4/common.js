var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";
function addNos(headVar,bodyVar)
{

//TODO: display the contents of the variable "msg"
//TODO: display the addition of two numbers
document.getElementById('msg').innerHTML = addNos();

}