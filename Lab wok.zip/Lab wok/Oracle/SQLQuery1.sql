create table Projects(
ProjectID bigint Primary key,
Projectname varchar(25) not null,
StartDate date,
Client varchar(50),
Cost numeric(10,2) check(cost>1000000)
);

alter table Projects add Duration int; 

insert into Projects values(1,'sravanthi','6-may-2015','Apple','2000000',3);
select * from Projects

insert into Projects(ProjectID,ProjectName)
values(2,'Berger');

insert into Projects values(
3,'HDFC',NULL,NULL,NULL,NULL);

insert into Projects values(
4,'ICICI',NULL,NULL,600000,NULL);

select * from Projects;

---->There are 2 Types Of transaction
--->1. Statement Level Transaction: Every SQL Statement have separate transaction
--->2. Bulk Transaction: Many SQL Statements

begin transaction;
insert into Projects(ProjectID,ProjectName)
values(8,'Spicejet');

insert into Projects(ProjectID,ProjectName)
values(9,'FoodGiant');

commit transaction;









