﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ListBoxes
{
    public partial class ListBoxes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        protected void ListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        //adding items

        protected void Button1_Click(object sender, EventArgs e)
        {
            //ListBox1.Items.Clear();
            string checkitem = TextBox1.Text;

            ListItem item = new ListItem(checkitem);
            if ( (ListBox1.Items.Contains(item)== false))
            {
                ListBox1.Items.Add(item);
            }
            else {
                Label1.Text = "The product already exists";
            }
        }

        protected  void addremove(ListBox ListBox1, ListBox ListBox2)
        {
            if(ListBox1.SelectedIndex != -1)
            {
                foreach(ListItem li in ListBox1.Items)
                {
                    if (li.Selected)
                    {
                        ListBox2.Items.Add(li);
                    }
                    
                }

                foreach (ListItem li in ListBox2.Items)
                {
                    ListBox1.Items.Remove(li.Value);

                }
                Label1.Text = "";
                ListBox2.ClearSelection();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            addremove(ListBox1,ListBox2);
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            addremove(ListBox2, ListBox1);
        }
    }
}