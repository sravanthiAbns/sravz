﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsynchroAJAX
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int getcount()
        {
            Thread.Sleep(5000);
            return 1000;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int count = getcount();
            label1.Text = "Done... got" + count;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text="Form is now responsive";
        }

        private async void  button3_Click(object sender, EventArgs e)
        {
            Task<int> task = new Task<int>(getcount);
            task.Start();
            label3.Text = "Loading...!!!";
            int count = await task;
            // can perform other task on the thread
            label3.Text = "Donee  .. got" +task.Result;

        }
    }
}
