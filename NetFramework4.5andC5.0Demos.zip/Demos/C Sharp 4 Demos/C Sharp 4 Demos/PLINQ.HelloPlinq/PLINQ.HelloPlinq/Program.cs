﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PLINQ.HelloPlinq
{
    class Program
    {
        static void Main(string[] args)
        {           
            RunSort();
            RunSortParallel();
            Console.ReadKey();
        }

             
        private static void RunSort()
        {
            var integerList = new List<int> { 5, 63, 23, 1, 0, 91 };
            var sortedIntegerList = from integer in integerList
                                    orderby integer ascending
                                    select integer;
            foreach (int number in sortedIntegerList)
                Console.WriteLine(number);

        }

        //We are now calling the extension method .AsParallel on the list of integers. 
        //This tells PLINQ that it is OK to go ahead and try to parallelize the LINQ query. 
        //   Instead of the LINQ query returning an IEnumerable type, 
        //it is returning an IParallelEnumerable. IParallelEnumerable derives from IEnumerable, 
        //    so existing code should work fine with this change.
        private static void RunSortParallel()
        {
            var integerList = new List<int> { 5, 63, 23, 1, 0, 91 };
            var sortedIntegerList = from integer in integerList.AsParallel()
                                    orderby integer ascending
                                    select integer;
            foreach (int number in sortedIntegerList)
                Console.WriteLine(number);
        }
    }
}
