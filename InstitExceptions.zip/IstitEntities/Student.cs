﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IstitEntities
{
   public class Student
    {
       // public int StudID { get; set; }
        public string StudName { get; set; }
        public DateTime DOB { get; set; }
        public string City { get; set; }

        public int CorseID { get; set; }
        public string CorseName { get; set; }

        //public DateTime AdminDate { get; set; }

        public int InstiID { get; set; }

    }
}
