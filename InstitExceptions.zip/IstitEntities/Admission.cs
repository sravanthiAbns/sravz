﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IstitEntities
{
    public class Admission
    {
        //public int AdminID { get; set; }
        //public DateTime AdminDate { get; set; }
        //public int StudID { get; set; }
        //public int CorseID { get; set; }

       
    }
}
