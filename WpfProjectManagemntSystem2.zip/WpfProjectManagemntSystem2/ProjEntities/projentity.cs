﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjEntities
{
    public class projentity
    {
        public int projID { get; set; }
        public string projname { get; set; }
        public string projlocation { get; set; }
        public float projBudget { get; set; }
        public DateTime dateofStart { get; set; }
        
    }
}
