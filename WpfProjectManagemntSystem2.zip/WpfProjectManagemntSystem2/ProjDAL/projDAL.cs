﻿using System;
using System.Collections.Generic;
using System.Linq;
using ProjEntities;
using ProjExceptions;
using System.Data;
using System.Data.Common;

namespace ProjDAL
{
    class projDAL
    {
        public bool addproj(projentity newproj)
        {
            bool addguest = false;
            try
            {
                // how to relate dis with dataconnection layer
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "addprojdet";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@projid";
                param.DbType = DbType.Int32;
                param.Value = newproj.projID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projName";
                param.DbType = DbType.String;
                param.Value = newproj.projname;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projloaction";
                param.DbType = DbType.String;
                param.Value = newproj.projlocation;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projbudget";
                param.DbType = DbType.String;
                param.Value = newproj.projlocation;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dateofstrt";
                param.DbType = DbType.String;
                param.Value = newproj.projlocation;
                command.Parameters.Add(param);

                int affectedRows = Dataconnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    addguest = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new Projexceptions(errormessage);
            }
            return addguest;
        }

        public List<projentity> GetAlGuestsDAL()
        {
            List<projentity> guestList = null;
            try
            {
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "getproj";

                // creating a datatable fro selcting 

                DataTable dataTable = Dataconnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    guestList = new List<projentity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                       projentity getproj = new projentity();
                        getproj.projID = (int)dataTable.Rows[rowCounter][0];
                        getproj.projname = (string)dataTable.Rows[rowCounter][1];
                        getproj.projlocation = (string)dataTable.Rows[rowCounter][2];
                        getproj.projBudget = (float)dataTable.Rows[rowCounter][3];
                        getproj.dateofStart = (DateTime)dataTable.Rows[rowCounter][4];
                        guestList.Add(getproj);
                    }
                }
            }


            // how the exception is throwed
            catch (DbException ex)
            {
                throw new Projexceptions(ex.Message);
            }
            return guestList;
        }
        public bool UpdateGuestDAL(projentity updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                DbCommand command =Dataconnections.createCommand();
                command.CommandText = "uspUpdateGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = updateGuest.GuestID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestName";
                param.DbType = DbType.String;
                param.Value = updateGuest.GuestName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestContactNumber";
                param.DbType = DbType.String;
                param.Value = updateGuest.GuestContactNo;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestUpdated = true;
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return guestUpdated;

        }

        public bool DeleteGuestDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspDeleteGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = deleteGuestID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestDeleted = true;
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return guestDeleted;

        }
        // can we use void in place of guest
        public guestEntity SearchGuestDAL(int searchGuestID)
        {
            guestEntity searchGuest = null;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspSearchGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = searchGuestID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchGuest = new guestEntity();
                    searchGuest.GuestID = (int)dataTable.Rows[0][0];
                    searchGuest.GuestName = (string)dataTable.Rows[0][1];
                    searchGuest.GuestContactNo = (string)dataTable.Rows[0][2];

                }
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return searchGuest;
        }
    }
}
