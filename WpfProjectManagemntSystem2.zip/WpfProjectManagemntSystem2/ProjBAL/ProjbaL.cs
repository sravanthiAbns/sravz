﻿using System;
using System.Collections.Generic;
using System.Text;
using ProjEntities;
using ProjDAL;
using ProjExceptions;

namespace ProjBAL
{
    public class ProjbaL
    {
        private static bool Validproject(projentity pent)
        {
            StringBuilder sb = new StringBuilder();
            bool validproj = true;
            if (pent.projID <= 0)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "Invalid Project ID");
            }
            if (pent.projname == string.Empty)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "Guest Name Required");
            }
            if (pent.projBudget < 25000)
            {
                validproj = false;
                sb.Append(Environment.NewLine + "budget should be above the limit");
            }
            if (validproj == false)
                throw new Projexceptions(sb.ToString());
            return validproj;

        }


    }
}
