﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IGATEPATNI.Winforms.Demo04
{
    public delegate void CalculationHandler(int firstNumber,int secondNumber);
    public delegate void DisplayEmployeeHandler(Employee employee);
}
