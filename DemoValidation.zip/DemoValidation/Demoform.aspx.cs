﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoValidation
{
    public partial class Demoform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            try
            {
                int num = int.Parse(args.Value);
                args.IsValid = ((num % 5)==0);
            }
            catch(Exception ex)
            {
                args.IsValid = false;

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(Page.IsValid)
            {
                Label8.Text = "Data Correct - Page is valid";
            }
           else
            {
                Label8.Text = "Data not correct - page is not valid";
            }
        }

       
    }
}