<!DOCTYPE HTML>
<html>
<head>
</head>
<title>JavaScript window example</title>
<script>
var confirmvalue=window.confirm("Do you want to exit?");
alert(confirmvalue);
</script>
</html>