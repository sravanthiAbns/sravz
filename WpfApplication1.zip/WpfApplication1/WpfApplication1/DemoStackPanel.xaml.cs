﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for DemoStackPanel.xaml
    /// </summary>
    public partial class DemoStackPanel : Window
    {
        public DemoStackPanel()
        {
            InitializeComponent();
        }

        private void checkBox_Checked(object sender, RoutedEventArgs e)
        {
            Stackpanel1.Orientation = Orientation.Horizontal;
        }

       

     

        private void checkBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            Stackpanel1.Orientation = Orientation.Vertical;
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
