﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventMobileClass
{
    enum CallType { Audio, Video};
    class CallEventArgs : EventArgs
    {
        public CallType calltype;

        public CallEventArgs()
        {
            Random r = new Random();
            calltype = r.Next() % 2 == 0 ?
                CallType.Audio : CallType.Video;

        }

    }
    class Mobile { 
        public string MobileName { get; set; }
        // create an eventhandler
        public delegate void CallEvent(object o, CallEventArgs ce);
        //  event calling
        public  event CallEvent CallRings;

        // onclick using event
        public Mobile(string mobilename)
        {
            MobileName = mobilename;
        }

        public void OnCallRing()
        {
            if (CallRings != null)
                CallRings(this, new CallEventArgs());
        }

    }
    class DemoEventArgs
    {
        static void Main(string[] args)
        {
            Mobile SamsungMobile = new Mobile("Samsung Note8");
            Mobile IPhoneMobile = new Mobile("IPhone8");
            SamsungMobile.CallRings += MyMobileRings;
            SamsungMobile.OnCallRing();

            IPhoneMobile.CallRings += MyMobileRings;
            IPhoneMobile.OnCallRing();
            Console.ReadLine();

        }
        public static void MyMobileRings(Object o, CallEventArgs ce)
        {
            Console.WriteLine("My{0} Mobile gets a {1} call", ((Mobile)o).MobileName,ce.calltype);
        }
    }
}
