﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDALayer;
using PEntityLayer;
using PExceptionLayer;

namespace PBALayer
{
    public class PanBal
    {
        private static bool ValidatePan(PanEntites pan)
        {
            StringBuilder sb = new StringBuilder();
            bool validPan = true;
            if (pan.PANNO <= 0)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Invalid Pan Number");

            }
            if (pan.PERSONNAME == string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Person Name Required");

            }
            if (pan.CITY==string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "City required");
            }
            if (pan.ADDRESS == string.Empty)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Address required");
            }
            if (pan.DATEOFCREATION >DateTime.Today)
            {
                validPan = false;
                sb.Append(Environment.NewLine + "Date should be greater than today");
            }
            if (validPan == false)
                throw new PanException(sb.ToString());
            return validPan;
        }

        public static bool AddGuestBL(PanEntites pan)
        {
            bool panAdded = false;
            try
            {
                if (ValidatePan(pan))
                {
                    PanDal pandal = new PanDal();
                    panAdded = pandal.AddPanDAL(pan);
                }
            }
            catch (PanException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panAdded;
        }

        //public static PanEntites SearchPanBL(object searchPan)
        //{
        //    throw new NotImplementedException();
        //}

        public static List<PanEntites> GetAllPanBL()
        {
            List<PanEntites> panList = null;
            try
            {
                PanDal pandal = new PanDal();
                panList = pandal.ShowAllDAL();
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return panList;
        }

        public static PanEntites SearchPanBL(int pan)
        {
            PanEntites searchPan = null;
            try
            {
                PanDal pandal = new PanDal();
                searchPan = pandal.SearchPanDAL(pan);
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPan;

        }

        public static bool UpdatepanBL(PanEntites updatePan)
        {
            bool panUpdated = false;
            try
            {
                if (ValidatePan(updatePan))
                {
                    PanDal pandal = new PanDal();
                    panUpdated = pandal.UpdatePanDAL(updatePan);
                }
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panUpdated;
        }

        public static bool DeletePanBL(int pan)
        {
            bool panDeleted = false;
            try
            {
                if (pan > 0)
                {
                    PanDal pandal = new PanDal();
                    panDeleted = pandal.DeletePanDAL(pan);
                }
                else
                {
                    throw new PanException("Invalid Pan Number");
                }
            }
            catch (PanException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return panDeleted;
        }
    }
}

