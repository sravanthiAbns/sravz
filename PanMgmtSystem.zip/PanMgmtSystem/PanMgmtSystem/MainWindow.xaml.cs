﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using PBALayer;
using PEntityLayer;
using PExceptionLayer;

namespace PanMgmtSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object panNo;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowAll_Click(object sender, RoutedEventArgs e)
        {
            List<PanEntites> panlist = PanBal.GetAllPanBL();
            dataGrid.ItemsSource = panlist;
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int panID = Convert.ToInt32(pan.Text);
                PanEntites searchPan = PanBal.SearchPanBL(panID);

                if (searchPan != null)
                {

                    name.Text = searchPan.PERSONNAME;
                    city.Text = searchPan.CITY;
                    address.Text = searchPan.ADDRESS;
                    dateOfCreation.SelectedDate = Convert.ToDateTime(searchPan.DATEOFCREATION);
                    label5.Content = "Pan details available";
                }
                else
                    label5.Content = "No Pan details available";
            }

            catch (PanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int updatePan = Convert.ToInt32(pan.Text);
                PanEntites updatedPan = PanBal.SearchPanBL(updatePan);
                if (updatedPan != null)
                {

                    updatedPan.PERSONNAME = name.Text;

                    updatedPan.CITY = city.Text;
                    updatedPan.ADDRESS = address.Text;
                    updatedPan.DATEOFCREATION = Convert.ToDateTime(dateOfCreation.Text);
                    bool panUpdated = PanBal.UpdatepanBL(updatedPan);
                    if (panUpdated)
                        label5.Content = "Pan Details Updated";
                    else
                        label5.Content = "Pan Details not Updated";
                }

            }
            catch (PanException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deletePan = Convert.ToInt32(pan.Text);
                PanEntites deletedPan = PanBal.SearchPanBL(deletePan);
                if (deletedPan != null)
                {
                    bool pandeleted = PanBal.DeletePanBL(deletePan);
                    if (pandeleted)
                        label5.Content = "Pan details Deleted";
                    else
                        label5.Content = ("Pan details not Deleted ");
                }
                else
                {
                    label5.Content = ("No Pan Details Available");
                }


            }
            catch (PanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PanEntites pobj = new PanEntites();
                pobj.PANNO = Convert.ToInt32(pan.Text);
                pobj.PERSONNAME = name.Text;
                pobj.CITY =city.Text;
                pobj.ADDRESS = address.Text;
                pobj.DATEOFCREATION = (DateTime)dateOfCreation.SelectedDate;

                PanBal.AddGuestBL(pobj);
                MessageBox.Show("Sucessfully added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGrid.SelectedIndex >= 0)
            {
                PanEntites pobj = (PanEntites)(object)dataGrid.SelectedItem;
                pan.Text = pobj.PANNO.ToString();
                name.Text = pobj.PERSONNAME;
                city.Text = pobj.CITY;
                address.Text = pobj.ADDRESS;
                dateOfCreation.SelectedDate = (DateTime)pobj.DATEOFCREATION;
            }
        }
    }
}
