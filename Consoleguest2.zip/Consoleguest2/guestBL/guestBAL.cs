﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Guestentity;
using guestBL;
using GuestException;
using GuestDaL;

namespace guestBL
{
    public class guestBAL
    {
        //can we pass class as object datatype
        private static bool Validateguest(guestEntity guest)
        {
            StringBuilder sb = new StringBuilder();
            bool validguest = true;
            if (guest.GuestID <= 0)
            {
                validguest = false;
                sb.Append(Environment.NewLine + "Invalid Guest ID");
            }
            if (guest.GuestName == string.Empty)
            {
                validguest = false;
                sb.Append(Environment.NewLine + "Guest Name Required");
            }
            if (guest.GuestContactNo.Length < 10)
            {
                validguest = false;
                sb.Append(Environment.NewLine + "Requied 10 digit contact number");
            }
            if (validguest == false)
                throw new guestexception(sb.ToString());


            return validguest;
        }
        public static bool AddGuestBL(guestEntity newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (Validateguest(newGuest))
                {
                    guestDAL guestdAL = new guestDAL();
                    guestAdded = guestdAL.AddguestDAL(newGuest);
                }
            }
            catch (guestexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return guestAdded;
        }


        public static List<guestEntity> GetAllGuestsBL()
        {
            List<guestEntity> guestList = null;
            try
            {
                guestDAL  guestdAL = new guestDAL();
                guestList = guestdAL.GetAlGuestsDAL();
            }
            catch (guestexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestList;
        }

        public static guestEntity SearchGuestBL(int searchGuestID)
        {
            guestEntity searchGuest = null;
            try
            {
                guestDAL guestdAL = new guestDAL();
                searchGuest = guestdAL.SearchGuestDAL(searchGuestID);
            }
            catch (guestexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;

        }

        public static bool UpdateGuestBL(guestEntity updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                if (Validateguest(updateGuest))
                {
                    guestDAL guestdAL = new guestDAL();
                    guestUpdated = guestdAL.UpdateGuestDAL(updateGuest);
                }
            }
            catch (guestexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return guestUpdated;
        }

        public static bool DeleteGuestBL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                if (deleteGuestID > 0)
                {
                    guestDAL guestdAL = new guestDAL();
                    guestDeleted = guestdAL.DeleteGuestDAL(deleteGuestID);
                }
                else
                {
                    throw new guestexception("Invalid Guest ID");
                }
            }
            catch (guestexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return guestDeleted;
        }

    }
}
