﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestException
{
    public class guestexception : ApplicationException
    {
        public guestexception() : base()
        {

        }

        public guestexception(string message) : base(message)
        {

        }
        public guestexception(string message,Exception innerexception) : base(message, innerexception)
        {

        }
    }
}
