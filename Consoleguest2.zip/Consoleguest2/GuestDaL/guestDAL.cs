﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Configuration;
using Guestentity;
using GuestException;
using System.Threading.Tasks;

namespace GuestDaL
{
    public class guestDAL
    {
        public bool AddguestDAL(guestEntity newguest)
        {
            bool addguest = false;
            try
            {
                // how to relate dis with dataconnection layer
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspAddGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = newguest.GuestID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestName";
                param.DbType = DbType.String;
                param.Value = newguest.GuestName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestContactNumber";
                param.DbType = DbType.String;
                param.Value = newguest.GuestContactNo;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    addguest = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new guestexception(errormessage);
            }
            return addguest;
        }
        // why to define again in BAL layer (already defined in DAL layer)

        public List<guestEntity> GetAlGuestsDAL()
        {
            List<guestEntity> guestList = null;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspGetAllGuests";

                // creating a datatable fro selcting 

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    guestList = new List<guestEntity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        guestEntity guest = new guestEntity();
                        guest.GuestID = (int)dataTable.Rows[rowCounter][0];
                        guest.GuestName = (string)dataTable.Rows[rowCounter][1];
                        guest.GuestContactNo = (string)dataTable.Rows[rowCounter][2];
                        guestList.Add(guest);
                    }
                }
            }
            // how the exception is throwed
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return guestList;
        }
        public bool UpdateGuestDAL(guestEntity updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspUpdateGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = updateGuest.GuestID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestName";
                param.DbType = DbType.String;
                param.Value = updateGuest.GuestName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestContactNumber";
                param.DbType = DbType.String;
                param.Value = updateGuest.GuestContactNo;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestUpdated = true;
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return guestUpdated;

        }

        public bool DeleteGuestDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspDeleteGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = deleteGuestID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestDeleted = true;
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return guestDeleted;

        }
        // can we use void in place of guest
        public guestEntity SearchGuestDAL(int searchGuestID)
        {
            guestEntity searchGuest = null;
            try
            {
                DbCommand command = DataConnection.createCommand();
                command.CommandText = "uspSearchGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = searchGuestID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchGuest = new guestEntity();
                    searchGuest.GuestID = (int)dataTable.Rows[0][0];
                    searchGuest.GuestName = (string)dataTable.Rows[0][1];
                    searchGuest.GuestContactNo = (string)dataTable.Rows[0][2];

                }
            }
            catch (DbException ex)
            {
                throw new guestexception(ex.Message);
            }
            return searchGuest;
        }

    }
}
