﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace GuestDaL
{
    class PhonebukConfig
    {
        // use of public and private and also use of static properties and set ka meaning
        private static string providername;

        public static string providerName
        {
            get { return PhonebukConfig.providername; }
            set { PhonebukConfig.providername = value; }
        }
        private static string connectionstring;
        public static string connectionString
        {
            get { return PhonebukConfig.connectionstring; }
            set {  PhonebukConfig.connectionstring = value; }
        }

        // use of constructor
        static PhonebukConfig()
        {
            //defined in constructor
            // y only field name but property , meaning of this sentence
            //providername=ConfigurationManager
            providername = ConfigurationManager.ConnectionStrings["guestBookConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["guestBookConnection"].ConnectionString;
        }

    }
}
