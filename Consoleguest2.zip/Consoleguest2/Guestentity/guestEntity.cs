﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guestentity
{
    public class guestEntity
    {
        public int GuestID { get; set; }
        public string GuestName { get; set; }
        public string GuestContactNo { get; set; }
    }
}
