﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsExample3 {
    public partial class MDI : Form {
        public MDI() {
            InitializeComponent();
        }

        private void menuFile_Form1_Click(object sender, EventArgs e) {
            Form form = new Form1();
            form.MdiParent = this;
            form.LayoutMdi(MdiLayout.TileVertical);
            form.Show();
        }
    }
}
