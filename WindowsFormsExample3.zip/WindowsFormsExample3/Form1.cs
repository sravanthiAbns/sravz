﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsExample3 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e) {
            string name = nameTextBox.Text;
            string doj = dojPicker.Text;
            string city = cityPicker.Text;
            string skills = "";
            foreach(string str in skillsPicker.SelectedItems) {
                skills += str + " ";
            }
            string experience = experienceInput.Text;
            string mobileNumber = mobileInput.Text;
            string gender;
            if (this.maleRadio.Checked) {
                gender = "Male";
            } else {
                gender = "Female";
            }
            string languages = "";
            if(this.hindiCB.Checked) {
                languages += "Hindi ";
            }
            if(this.englishCB.Checked) {
                languages += "English ";
            }
            if(this.frenchCB.Checked) {
                languages += "French";
            }
            string output = "Name: " + name + "\n" +
                "DOJ: " + doj + "\n" +
                "City: " + city + "\n" +
                "Skills: " + skills + "\n" +
                "Experience: " + experience + "\n" +
                "Mobile Number: " + mobileNumber + "\n" +
                "Gender: " + gender + "\n" +
                "Languages Known: " + languages;
            MessageBox.Show(output);

            richTextBox1.SaveFile(@"D:\RTFFile.rtf", RichTextBoxStreamType.RichText);
        }

        private void boldButton_Click(object sender, EventArgs e) {
            richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Bold);
        }

        private void italicsButton_Click(object sender, EventArgs e) {
            richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Italic);
        }

        private void underlineButton_Click(object sender, EventArgs e) {
            richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Underline);
        }
    }
}
