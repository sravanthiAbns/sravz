﻿namespace WindowsFormsExample3 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.nameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.dojLabel = new System.Windows.Forms.Label();
            this.dojPicker = new System.Windows.Forms.DateTimePicker();
            this.cityLabel = new System.Windows.Forms.Label();
            this.cityPicker = new System.Windows.Forms.ComboBox();
            this.skillsLabel = new System.Windows.Forms.Label();
            this.skillsPicker = new System.Windows.Forms.ListBox();
            this.genderGroup = new System.Windows.Forms.GroupBox();
            this.femaleRadoi = new System.Windows.Forms.RadioButton();
            this.maleRadio = new System.Windows.Forms.RadioButton();
            this.languagesGroup = new System.Windows.Forms.GroupBox();
            this.frenchCB = new System.Windows.Forms.CheckBox();
            this.englishCB = new System.Windows.Forms.CheckBox();
            this.hindiCB = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.experienceInput = new System.Windows.Forms.NumericUpDown();
            this.mobileLabel = new System.Windows.Forms.Label();
            this.mobileInput = new System.Windows.Forms.MaskedTextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.reviewLabel = new System.Windows.Forms.Label();
            this.boldButton = new System.Windows.Forms.Button();
            this.italicsButton = new System.Windows.Forms.Button();
            this.underlineButton = new System.Windows.Forms.Button();
            this.genderGroup.SuspendLayout();
            this.languagesGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.experienceInput)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(16, 14);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(41, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name: ";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(100, 10);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 1;
            // 
            // dojLabel
            // 
            this.dojLabel.AutoSize = true;
            this.dojLabel.Location = new System.Drawing.Point(16, 38);
            this.dojLabel.Name = "dojLabel";
            this.dojLabel.Size = new System.Drawing.Size(56, 13);
            this.dojLabel.TabIndex = 2;
            this.dojLabel.Text = "Enter DOJ";
            // 
            // dojPicker
            // 
            this.dojPicker.Location = new System.Drawing.Point(100, 38);
            this.dojPicker.Name = "dojPicker";
            this.dojPicker.Size = new System.Drawing.Size(100, 20);
            this.dojPicker.TabIndex = 3;
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(16, 69);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(57, 13);
            this.cityLabel.TabIndex = 4;
            this.cityLabel.Text = "Select City";
            // 
            // cityPicker
            // 
            this.cityPicker.FormattingEnabled = true;
            this.cityPicker.Items.AddRange(new object[] {
            "Ahmedabad",
            "Gandhinagar",
            "Pune",
            "Mumbai",
            "Bangalore",
            "Chennai"});
            this.cityPicker.Location = new System.Drawing.Point(100, 69);
            this.cityPicker.Name = "cityPicker";
            this.cityPicker.Size = new System.Drawing.Size(100, 21);
            this.cityPicker.TabIndex = 5;
            // 
            // skillsLabel
            // 
            this.skillsLabel.AutoSize = true;
            this.skillsLabel.Location = new System.Drawing.Point(16, 101);
            this.skillsLabel.Name = "skillsLabel";
            this.skillsLabel.Size = new System.Drawing.Size(64, 13);
            this.skillsLabel.TabIndex = 6;
            this.skillsLabel.Text = "Select Skills";
            // 
            // skillsPicker
            // 
            this.skillsPicker.FormattingEnabled = true;
            this.skillsPicker.Items.AddRange(new object[] {
            "Android",
            "iOS",
            "Java",
            ".NET",
            "C#",
            "C",
            "C++",
            "Swift"});
            this.skillsPicker.Location = new System.Drawing.Point(100, 101);
            this.skillsPicker.Name = "skillsPicker";
            this.skillsPicker.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.skillsPicker.Size = new System.Drawing.Size(100, 108);
            this.skillsPicker.TabIndex = 7;
            // 
            // genderGroup
            // 
            this.genderGroup.Controls.Add(this.femaleRadoi);
            this.genderGroup.Controls.Add(this.maleRadio);
            this.genderGroup.Location = new System.Drawing.Point(233, 13);
            this.genderGroup.Name = "genderGroup";
            this.genderGroup.Size = new System.Drawing.Size(158, 77);
            this.genderGroup.TabIndex = 8;
            this.genderGroup.TabStop = false;
            this.genderGroup.Text = "Gender";
            // 
            // femaleRadoi
            // 
            this.femaleRadoi.AutoSize = true;
            this.femaleRadoi.Location = new System.Drawing.Point(7, 44);
            this.femaleRadoi.Name = "femaleRadoi";
            this.femaleRadoi.Size = new System.Drawing.Size(59, 17);
            this.femaleRadoi.TabIndex = 1;
            this.femaleRadoi.TabStop = true;
            this.femaleRadoi.Text = "Female";
            this.femaleRadoi.UseVisualStyleBackColor = true;
            // 
            // maleRadio
            // 
            this.maleRadio.AutoSize = true;
            this.maleRadio.Location = new System.Drawing.Point(7, 20);
            this.maleRadio.Name = "maleRadio";
            this.maleRadio.Size = new System.Drawing.Size(48, 17);
            this.maleRadio.TabIndex = 0;
            this.maleRadio.TabStop = true;
            this.maleRadio.Text = "Male";
            this.maleRadio.UseVisualStyleBackColor = true;
            // 
            // languagesGroup
            // 
            this.languagesGroup.Controls.Add(this.frenchCB);
            this.languagesGroup.Controls.Add(this.englishCB);
            this.languagesGroup.Controls.Add(this.hindiCB);
            this.languagesGroup.Location = new System.Drawing.Point(233, 101);
            this.languagesGroup.Name = "languagesGroup";
            this.languagesGroup.Size = new System.Drawing.Size(158, 100);
            this.languagesGroup.TabIndex = 9;
            this.languagesGroup.TabStop = false;
            this.languagesGroup.Text = "Languages Known";
            // 
            // frenchCB
            // 
            this.frenchCB.AutoSize = true;
            this.frenchCB.Location = new System.Drawing.Point(7, 68);
            this.frenchCB.Name = "frenchCB";
            this.frenchCB.Size = new System.Drawing.Size(59, 17);
            this.frenchCB.TabIndex = 2;
            this.frenchCB.Text = "French";
            this.frenchCB.UseVisualStyleBackColor = true;
            // 
            // englishCB
            // 
            this.englishCB.AutoSize = true;
            this.englishCB.Location = new System.Drawing.Point(7, 44);
            this.englishCB.Name = "englishCB";
            this.englishCB.Size = new System.Drawing.Size(60, 17);
            this.englishCB.TabIndex = 1;
            this.englishCB.Text = "English";
            this.englishCB.UseVisualStyleBackColor = true;
            // 
            // hindiCB
            // 
            this.hindiCB.AutoSize = true;
            this.hindiCB.Location = new System.Drawing.Point(7, 20);
            this.hindiCB.Name = "hindiCB";
            this.hindiCB.Size = new System.Drawing.Size(50, 17);
            this.hindiCB.TabIndex = 0;
            this.hindiCB.Text = "Hindi";
            this.hindiCB.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Experience";
            // 
            // experienceInput
            // 
            this.experienceInput.Location = new System.Drawing.Point(100, 216);
            this.experienceInput.Name = "experienceInput";
            this.experienceInput.Size = new System.Drawing.Size(100, 20);
            this.experienceInput.TabIndex = 12;
            // 
            // mobileLabel
            // 
            this.mobileLabel.AutoSize = true;
            this.mobileLabel.Location = new System.Drawing.Point(16, 246);
            this.mobileLabel.Name = "mobileLabel";
            this.mobileLabel.Size = new System.Drawing.Size(73, 26);
            this.mobileLabel.TabIndex = 13;
            this.mobileLabel.Text = "Mobile\r\n(987)6543210";
            // 
            // mobileInput
            // 
            this.mobileInput.Location = new System.Drawing.Point(100, 246);
            this.mobileInput.Mask = "(999) 000-0000";
            this.mobileInput.Name = "mobileInput";
            this.mobileInput.Size = new System.Drawing.Size(100, 20);
            this.mobileInput.TabIndex = 15;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(340, 337);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 23);
            this.submitButton.TabIndex = 16;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(233, 243);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(122, 85);
            this.richTextBox1.TabIndex = 17;
            this.richTextBox1.Text = "";
            // 
            // reviewLabel
            // 
            this.reviewLabel.AutoSize = true;
            this.reviewLabel.Location = new System.Drawing.Point(233, 224);
            this.reviewLabel.Name = "reviewLabel";
            this.reviewLabel.Size = new System.Drawing.Size(43, 13);
            this.reviewLabel.TabIndex = 18;
            this.reviewLabel.Text = "Review";
            // 
            // boldButton
            // 
            this.boldButton.Location = new System.Drawing.Point(355, 243);
            this.boldButton.Name = "boldButton";
            this.boldButton.Size = new System.Drawing.Size(35, 23);
            this.boldButton.TabIndex = 19;
            this.boldButton.Text = "B";
            this.boldButton.UseVisualStyleBackColor = true;
            this.boldButton.Click += new System.EventHandler(this.boldButton_Click);
            // 
            // italicsButton
            // 
            this.italicsButton.Location = new System.Drawing.Point(355, 272);
            this.italicsButton.Name = "italicsButton";
            this.italicsButton.Size = new System.Drawing.Size(35, 23);
            this.italicsButton.TabIndex = 20;
            this.italicsButton.Text = "I";
            this.italicsButton.UseVisualStyleBackColor = true;
            this.italicsButton.Click += new System.EventHandler(this.italicsButton_Click);
            // 
            // underlineButton
            // 
            this.underlineButton.Location = new System.Drawing.Point(355, 301);
            this.underlineButton.Name = "underlineButton";
            this.underlineButton.Size = new System.Drawing.Size(35, 23);
            this.underlineButton.TabIndex = 21;
            this.underlineButton.Text = "U";
            this.underlineButton.UseVisualStyleBackColor = true;
            this.underlineButton.Click += new System.EventHandler(this.underlineButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 372);
            this.Controls.Add(this.underlineButton);
            this.Controls.Add(this.italicsButton);
            this.Controls.Add(this.boldButton);
            this.Controls.Add(this.reviewLabel);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.mobileInput);
            this.Controls.Add(this.mobileLabel);
            this.Controls.Add(this.experienceInput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.languagesGroup);
            this.Controls.Add(this.genderGroup);
            this.Controls.Add(this.skillsPicker);
            this.Controls.Add(this.skillsLabel);
            this.Controls.Add(this.cityPicker);
            this.Controls.Add(this.cityLabel);
            this.Controls.Add(this.dojPicker);
            this.Controls.Add(this.dojLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.genderGroup.ResumeLayout(false);
            this.genderGroup.PerformLayout();
            this.languagesGroup.ResumeLayout(false);
            this.languagesGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.experienceInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label dojLabel;
        private System.Windows.Forms.DateTimePicker dojPicker;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.ComboBox cityPicker;
        private System.Windows.Forms.Label skillsLabel;
        private System.Windows.Forms.ListBox skillsPicker;
        private System.Windows.Forms.GroupBox genderGroup;
        private System.Windows.Forms.RadioButton femaleRadoi;
        private System.Windows.Forms.RadioButton maleRadio;
        private System.Windows.Forms.GroupBox languagesGroup;
        private System.Windows.Forms.CheckBox frenchCB;
        private System.Windows.Forms.CheckBox englishCB;
        private System.Windows.Forms.CheckBox hindiCB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown experienceInput;
        private System.Windows.Forms.Label mobileLabel;
        private System.Windows.Forms.MaskedTextBox mobileInput;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label reviewLabel;
        private System.Windows.Forms.Button boldButton;
        private System.Windows.Forms.Button italicsButton;
        private System.Windows.Forms.Button underlineButton;
    }
}

