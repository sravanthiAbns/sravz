﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCFApplication.Models
{
    public class Employee
    {
        public int EID { get; set; }
        public string Ename {get; set;}

    }
}