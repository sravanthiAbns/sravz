﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Configuration;


namespace ProjDAL
{
    class DataConfiguration
    {
        // use of public and private and also use of static properties and set ka meaning
        private static string providername;

        public static string providerName
        {
            get { return DataConfiguration.providername; }
            set { DataConfiguration.providername = value; }
        }
        private static string connectionstring;
        public static string connectionString
        {
            get { return DataConfiguration.connectionstring; }
            set { DataConfiguration.connectionstring = value; }
        }

        // use of constructor
        static DataConfiguration()
        {
            //defined in constructor
            // y only field name but property , meaning of this sentence

            providername = ConfigurationManager.ConnectionStrings["projectConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["projectConnection"].ConnectionString;
        }

    }
}

