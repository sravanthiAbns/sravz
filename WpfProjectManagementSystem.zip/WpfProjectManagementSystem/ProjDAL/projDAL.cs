﻿using System;
using System.Collections.Generic;
using System.Linq;
using ProjEntities;
using ProjExceptions;
using System.Data;
using System.Data.Common;

namespace ProjDAL
{
    public class projDAL
    {
        public bool addproj(projentity newproj)
        {
            bool addguest = false;
            try
            {
                // how to relate dis with dataconnection layer
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "addProjdetails";

                DbParameter param = command.CreateParameter();
                //param.ParameterName = "@projid";
                //param.DbType = DbType.Int32;
                //param.Value = newproj.projID;
                //command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projName";
                param.DbType = DbType.String;
                param.Value = newproj.projname;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projloaction";
                param.DbType = DbType.String;
                param.Value = newproj.projlocation;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projbudget";
                param.DbType = DbType.Decimal;
                param.Value = newproj.projBudget;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dateofstrt";
                param.DbType = DbType.DateTime;
                param.Value = newproj.dateofStart;
                command.Parameters.Add(param);

                int affectedRows = Dataconnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    addguest = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new Projexceptions(errormessage);
            }
            return addguest;
        }

        // get all projectdetails
        public List<projentity> getAllprojDet()
        {
            List<projentity> projList = null;
            try
            {
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "GetAllProj";

                // creating a datatable fro selcting 

                DataTable dataTable = Dataconnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    projList = new List<projentity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                       projentity getalproj = new projentity();
                        getalproj.projID = Convert.ToInt32(dataTable.Rows[rowCounter][0]);
                        getalproj.projname = dataTable.Rows[rowCounter][1].ToString();
                        getalproj.projlocation = dataTable.Rows[rowCounter][2].ToString();
                        getalproj.projBudget = Convert.ToDouble(dataTable.Rows[rowCounter][3]);
                        getalproj.dateofStart = (DateTime)dataTable.Rows[rowCounter][4];
                        projList.Add(getalproj);
                    }
                }
            }


            // how the exception is throwed
            catch (DbException ex)
            {
                throw new Projexceptions(ex.Message);
            }
            return projList;
        }

        // upadte the project list
        public bool UpdateprojDAL(projentity updateproj)
        {
            bool projUpdated = false;
            try
            {
                DbCommand command =Dataconnections.createCommand();
                command.CommandText = "UpdateProject";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@projid";
                param.DbType = DbType.Int32;
                param.Value = updateproj.projID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@projName";
                param.DbType = DbType.String;
                param.Value = updateproj.projname;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@projloaction";
                param.DbType = DbType.String;
                param.Value = updateproj.projlocation;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@projbudget";
                param.DbType = DbType.Decimal;
                param.Value = updateproj.projBudget;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@dateofstrt";
                param.DbType = DbType.Date;
                param.Value = updateproj.dateofStart;
                command.Parameters.Add(param);

                int affectedRows = Dataconnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    projUpdated = true;
            }
            catch (DbException ex)
            {
                throw new Projexceptions(ex.Message);
            }
            return projUpdated;

        }

        public bool DeleteProjDAL(int delprojid)
        {
            bool projDeleted = false;
            try
            {
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "DelGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@projID";
                param.DbType = DbType.Int32;
                param.Value = delprojid;
                command.Parameters.Add(param);

                int affectedRows = Dataconnections.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    projDeleted = true;
            }
            catch (DbException ex)
            {
                throw new Projexceptions(ex.Message);
            }
            return projDeleted;

        }
        // can we use void in place of guest
        public projentity SearchProjDAL(int searchGuestID)
        {
            projentity searchGuest = null;
            try
            {
                DbCommand command = Dataconnections.createCommand();
                command.CommandText = "SearchGuest  ";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@projID";
                param.DbType = DbType.Int32;
                param.Value = searchGuestID;
                command.Parameters.Add(param);

                DataTable dataTable = Dataconnections.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchGuest = new projentity();
                    searchGuest.projID = Convert.ToInt32(dataTable.Rows[0][0]);
                    searchGuest.projname = dataTable.Rows[0][1].ToString();
                    searchGuest.projlocation = dataTable.Rows[0][2].ToString();
                    searchGuest.projBudget = Convert.ToDouble(dataTable.Rows[0][3]);
                    searchGuest.dateofStart = Convert.ToDateTime(dataTable.Rows[0][4]);
                }
            }
            catch (DbException ex)
            {
                throw new Projexceptions(ex.Message);
            }
            return searchGuest;
        }
    }
}
