﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace question4
{
    public partial class Assignment : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Assignment()
        {
            InitializeComponent();
        }

        private void Assignment_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=BLRWFD20620\SQLEXPRESS;Initial Catalog=training;Integrated Security=True");

            con.Open();
            ds = new DataSet();

            //select - For Data Retrieval
            da = new SqlDataAdapter("select * from Supplier", con);

            da.Fill(ds, "supplier");

            dataGrid_Suppliers.DataSource = ds.Tables["supplier"];
        }
    }
}
