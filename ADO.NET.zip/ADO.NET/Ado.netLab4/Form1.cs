﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace question4
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=BLRWFD20620\SQLEXPRESS;Initial Catalog=training;Integrated Security=True");

            con.Open();
            ds = new DataSet();
            
            //select - For Data Retrieval
            da = new SqlDataAdapter("select * from customer", con); 

            da.Fill(ds, "cust");

            datagridCustomers.DataSource = ds.Tables["cust"];
        }

        private void cmb_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = cmb_sort.Text;
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like '" + txt_City.Text + "'";
        }

        private void datagridCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
