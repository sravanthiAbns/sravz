﻿namespace question4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_City = new System.Windows.Forms.TextBox();
            this.btn_Show = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_sort = new System.Windows.Forms.ComboBox();
            this.datagridCustomers = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datagridCustomers)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer City";
            // 
            // txt_City
            // 
            this.txt_City.Location = new System.Drawing.Point(110, 26);
            this.txt_City.Name = "txt_City";
            this.txt_City.Size = new System.Drawing.Size(100, 20);
            this.txt_City.TabIndex = 1;
            // 
            // btn_Show
            // 
            this.btn_Show.Location = new System.Drawing.Point(257, 25);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(75, 23);
            this.btn_Show.TabIndex = 2;
            this.btn_Show.Text = "Show";
            this.btn_Show.UseVisualStyleBackColor = true;
            this.btn_Show.Click += new System.EventHandler(this.btn_Show_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Sort Details On:";
            // 
            // cmb_sort
            // 
            this.cmb_sort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_sort.FormattingEnabled = true;
            this.cmb_sort.Items.AddRange(new object[] {
            "City",
            "CreditLimit",
            "CustomerName"});
            this.cmb_sort.Location = new System.Drawing.Point(110, 64);
            this.cmb_sort.Name = "cmb_sort";
            this.cmb_sort.Size = new System.Drawing.Size(99, 21);
            this.cmb_sort.TabIndex = 4;
            this.cmb_sort.SelectedIndexChanged += new System.EventHandler(this.cmb_sort_SelectedIndexChanged);
            // 
            // datagridCustomers
            // 
            this.datagridCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridCustomers.Location = new System.Drawing.Point(12, 103);
            this.datagridCustomers.Name = "datagridCustomers";
            this.datagridCustomers.Size = new System.Drawing.Size(523, 173);
            this.datagridCustomers.TabIndex = 5;
            this.datagridCustomers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridCustomers_CellContentClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 288);
            this.Controls.Add(this.datagridCustomers);
            this.Controls.Add(this.cmb_sort);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.txt_City);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "x`";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridCustomers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_City;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_sort;
        private System.Windows.Forms.DataGridView datagridCustomers;
    }
}

