Use Training

Create table employee (
	empno int primary key,
	empname varchar(50) not null,
	empsal numeric(10,2) check(empsal >= 25000) ,
	emptype varchar(1) check(emptype in('C','P'))
)
Go

Create proc GetEmployeeById (
	@eno int
)
As
Begin
	Select * from employee where empno = @eno
End
Go

Create Sequence EmpNoSeq
As Int
Start With 1001
Increment By 1;


Go
Create proc AddEmployee (
	@empName varchar(50),
	@empSal numeric(10,2),
	@empType varchar(1)
)
As
Begin
	Insert into employee values (
		Next Value for EmpNoSeq,
		@empName,
		@empSal,
		@empType
	)
End