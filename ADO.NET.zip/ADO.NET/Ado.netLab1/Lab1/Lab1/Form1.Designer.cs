﻿namespace Lab1 {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.empNoLabel = new System.Windows.Forms.Label();
            this.empNoTextBox = new System.Windows.Forms.TextBox();
            this.empNameTextBox = new System.Windows.Forms.TextBox();
            this.empNameLabel = new System.Windows.Forms.Label();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.queryButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.payrollRadio = new System.Windows.Forms.RadioButton();
            this.consultantRadio = new System.Windows.Forms.RadioButton();
            this.newButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // empNoLabel
            // 
            this.empNoLabel.AutoSize = true;
            this.empNoLabel.Location = new System.Drawing.Point(12, 9);
            this.empNoLabel.Name = "empNoLabel";
            this.empNoLabel.Size = new System.Drawing.Size(70, 13);
            this.empNoLabel.TabIndex = 0;
            this.empNoLabel.Text = "Employee No";
            // 
            // empNoTextBox
            // 
            this.empNoTextBox.Location = new System.Drawing.Point(128, 6);
            this.empNoTextBox.Name = "empNoTextBox";
            this.empNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNoTextBox.TabIndex = 1;
            // 
            // empNameTextBox
            // 
            this.empNameTextBox.Location = new System.Drawing.Point(128, 32);
            this.empNameTextBox.Name = "empNameTextBox";
            this.empNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNameTextBox.TabIndex = 3;
            // 
            // empNameLabel
            // 
            this.empNameLabel.AutoSize = true;
            this.empNameLabel.Location = new System.Drawing.Point(12, 35);
            this.empNameLabel.Name = "empNameLabel";
            this.empNameLabel.Size = new System.Drawing.Size(84, 13);
            this.empNameLabel.TabIndex = 2;
            this.empNameLabel.Text = "Employee Name";
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.Location = new System.Drawing.Point(128, 58);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.salaryTextBox.TabIndex = 5;
            // 
            // salaryLabel
            // 
            this.salaryLabel.AutoSize = true;
            this.salaryLabel.Location = new System.Drawing.Point(12, 61);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(36, 13);
            this.salaryLabel.TabIndex = 4;
            this.salaryLabel.Text = "Salary";
            // 
            // queryButton
            // 
            this.queryButton.Location = new System.Drawing.Point(128, 121);
            this.queryButton.Name = "queryButton";
            this.queryButton.Size = new System.Drawing.Size(75, 23);
            this.queryButton.TabIndex = 6;
            this.queryButton.Text = "Query";
            this.queryButton.UseVisualStyleBackColor = true;
            this.queryButton.Click += new System.EventHandler(this.queryButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.consultantRadio);
            this.groupBox1.Controls.Add(this.payrollRadio);
            this.groupBox1.Location = new System.Drawing.Point(284, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(143, 72);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Type";
            // 
            // payrollRadio
            // 
            this.payrollRadio.AutoSize = true;
            this.payrollRadio.Location = new System.Drawing.Point(7, 20);
            this.payrollRadio.Name = "payrollRadio";
            this.payrollRadio.Size = new System.Drawing.Size(56, 17);
            this.payrollRadio.TabIndex = 0;
            this.payrollRadio.TabStop = true;
            this.payrollRadio.Text = "Payroll";
            this.payrollRadio.UseVisualStyleBackColor = true;
            // 
            // consultantRadio
            // 
            this.consultantRadio.AutoSize = true;
            this.consultantRadio.Location = new System.Drawing.Point(7, 44);
            this.consultantRadio.Name = "consultantRadio";
            this.consultantRadio.Size = new System.Drawing.Size(75, 17);
            this.consultantRadio.TabIndex = 1;
            this.consultantRadio.TabStop = true;
            this.consultantRadio.Text = "Consultant";
            this.consultantRadio.UseVisualStyleBackColor = true;
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(284, 121);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(75, 23);
            this.newButton.TabIndex = 8;
            this.newButton.Text = "New";
            this.newButton.UseVisualStyleBackColor = true;
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(366, 121);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 9;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(284, 144);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(75, 23);
            this.deleteButton.TabIndex = 10;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 179);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.newButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.queryButton);
            this.Controls.Add(this.salaryTextBox);
            this.Controls.Add(this.salaryLabel);
            this.Controls.Add(this.empNameTextBox);
            this.Controls.Add(this.empNameLabel);
            this.Controls.Add(this.empNoTextBox);
            this.Controls.Add(this.empNoLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label empNoLabel;
        private System.Windows.Forms.TextBox empNoTextBox;
        private System.Windows.Forms.TextBox empNameTextBox;
        private System.Windows.Forms.Label empNameLabel;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.Button queryButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton consultantRadio;
        private System.Windows.Forms.RadioButton payrollRadio;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button deleteButton;
    }
}

