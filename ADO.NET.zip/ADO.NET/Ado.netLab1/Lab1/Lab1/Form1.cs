﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Lab1 {
    public partial class Form1 : Form {
        SqlConnection conn = null;
        public Form1() {
            InitializeComponent();
            conn = new SqlConnection("Data Source=.;Initial Catalog=Training;Integrated Security=True");
            conn.Open();
        }

        private void queryButton_Click(object sender, EventArgs e) {
            try {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);
                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(empNoTextBox.Text);
                //execute
                dreader = cmd.ExecuteReader();
                //if employee record found
                if (dreader.Read()) {
                    empNameTextBox.Text = dreader["empname"].ToString();
                    salaryTextBox.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        payrollRadio.Checked = true;
                    else
                        consultantRadio.Checked = true;
                } else {
                    newButton_Click(newButton, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            } catch (Exception ex) {

            }
        }

        private void newButton_Click(object sender, EventArgs e) {
            empNoTextBox.Text = "";
            empNameTextBox.Text = "";
            salaryTextBox.Text = "";
            empNoTextBox.Focus();
        }

        private void saveButton_Click(object sender, EventArgs e) {
            try {
                //The Insert DML to add employee record
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "AddEmployee";

                SqlParameter param = new SqlParameter();
                param.ParameterName = "@empName";
                param.DbType = DbType.String;
                param.Value = empNameTextBox.Text;
                cmd.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@empSal";
                param.DbType = DbType.Decimal;
                param.Value = salaryTextBox.Text;
                cmd.Parameters.Add(param);

                param = new SqlParameter();
                param.ParameterName = "@empType";
                param.DbType = DbType.String;
                param.Value = payrollRadio.Checked ? 'P' : 'C';
                cmd.Parameters.Add(param);

                int affectedRows = cmd.ExecuteNonQuery();
                if(affectedRows > 0) {
                    MessageBox.Show("Employee Added Succcessfully");
                } else {
                    MessageBox.Show("Failed To Add Employee");
                }
            } catch (Exception ex) {

            }
        }

        private void deleteButton_Click(object sender, EventArgs e) {
            var confirmResult = MessageBox.Show("Are you sure to delete data?",
                "Confirm Delete", MessageBoxButtons.YesNo);
            try {
                if(confirmResult == DialogResult.Yes) {
                    SqlCommand cmd = new SqlCommand("Delete from employee where empno=" + empNoTextBox.Text,conn);
                    int affectedRows = cmd.ExecuteNonQuery();
                    if(affectedRows > 0) {
                        MessageBox.Show("Employee Deleted Successfully");
                    } else {
                        MessageBox.Show("No Record was Deleted");
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
