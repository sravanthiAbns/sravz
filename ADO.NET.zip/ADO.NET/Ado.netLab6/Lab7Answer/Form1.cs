﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Lab7Answer
{
    public partial class Form1 : Form
    {
        SqlDataAdapter daProduct;
        DataSet dsProduct;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string sqlConnectString = ConfigurationManager.ConnectionStrings["Training"].ConnectionString;
            SqlConnection connection = new SqlConnection(sqlConnectString);

            daProduct = new SqlDataAdapter("Select * from DNEmployee", connection);
            connection.Open();
            dsProduct = new DataSet();
            daProduct.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            daProduct.Fill(dsProduct, "DNEmployee");

            SqlCommandBuilder cb = new SqlCommandBuilder(daProduct);
        }

        private void btnSaveToXML_Click(object sender, EventArgs e)
        {
            //Save Schema and Data into xml file
            dsProduct.WriteXmlSchema("..\\..\\products.xsd");
            dsProduct.WriteXml("..\\..\\products.xml", XmlWriteMode.IgnoreSchema);
            MessageBox.Show("Data saved to disk");
        }

        private void btnLoadFromXML_Click(object sender, EventArgs e)
        {
            //Read Data from xml file into Data Set
            dsProduct.ReadXmlSchema("..\\..\\products.xsd");
            dsProduct = new DataSet();
            dsProduct.ReadXml("..\\..\\products.xml", XmlReadMode.IgnoreSchema);
            dataGridView1.DataSource = dsProduct.Tables["DNEmployee"];
            MessageBox.Show("Data read from XML");
        }

        private void btnLoadFromDB_Click(object sender, EventArgs e)
        {
            daProduct.Fill(dsProduct, "DNEmployee");
            dataGridView1.DataSource = dsProduct.Tables["DNEmployee"];
            btnLoadFromDB.Enabled = false;
        }

        private void btnSaveToDB_Click(object sender, EventArgs e)
        {
            try
            {
                daProduct.Update(dsProduct.Tables["DNEmployee"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }
    }
}
