﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Xml;

namespace Lab_8
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        XmlDataDocument doc;
        public Window1()
        {
            InitializeComponent();
        }

        private void btnload_Click(object sender, RoutedEventArgs e)
        {
             doc = new XmlDataDocument();
            // Load the schema file.
            doc.DataSet.ReadXmlSchema("BookStore.xsd");
            // Load the XML data.
            XmlTextReader reader = new XmlTextReader("Books.xml");
            // Move the reader to the root node and load xml data
            reader.MoveToContent();
            doc.Load(reader);
            // Update the price on the first book using the DataSet methods.
            // Working with data as relational model
            DataTable books = doc.DataSet.Tables["book"];
            books.Rows[0]["price"] = "101.95";
            grdbook.ItemsSource = doc.DataSet.Tables["book"].;
            btnload.IsEnabled = false;
            btnshowtitles.IsEnabled = true;
        }

        private void btnshowtitles_Click(object sender, RoutedEventArgs e)
        {
            // Get the node list of titles of type ‘novel’
            // Working with data as heirarchical model
            XmlNodeList nodelist = doc.DocumentElement.SelectNodes
            ("//title[../@genre = 'novel']");
            string msg = "";
            foreach (XmlNode node in nodelist)
            {
                msg += node.InnerText + "\n";
            }
            MessageBox.Show(msg);
        }
    }
}
