use SampleDatabase;

--lab 2
create table applicationusers  (  
	userid varchar(10) primary key,
	username varchar(30) not null, 
	city varchar(30) not null, 
    password varchar(30) check(len(password) >5)
)


insert into applicationusers values('E001','Gaurav','Bokaro','qwerty');

select * from applicationusers;


--lab 4

create table customer (
	customerid int identity primary key,
    customername varchar(50),
	city varchar(30),
	creditlimit numeric(10,2) 
)


insert into customer values('Gaurav','Bokaro',20000);
insert into customer values('Unmesh','Kolkata',20000);
insert into customer values('Sumit','Purnia',18000);
insert into customer values('Gambhir','Delhi',25000);
insert into customer values('Arnab','Bokaro',27000);

select * from customer;



create table Supplier(
	SupplierId int primary key identity,
	Suppliername varchar(30),
	City varchar(30),
	ContactNo varchar(10),
	CreditBalance numeric(10,2)
);


insert into Supplier values('Gaurav','Bokaro','9977345234',25000);
insert into Supplier values('Unmesh','Kolkata','9945678234',22000);
insert into Supplier values('Ajay','Bokaro','9987655274',23000);
insert into Supplier values('Dinesh','Delhi','7765348734',24500);
insert into Supplier values('Saurav','Hyderabad','9375647632',25000);
insert into Supplier values('Vishal','Delhi','8798343434',21000);
insert into Supplier values('Andy','Mumbai','9974545267',22000);
