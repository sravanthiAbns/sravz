﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace question_3
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                da.UpdateCommand = new SqlCommandBuilder(da).GetUpdateCommand();
                //Save Changes to Database                 
                da.Update(ds.Tables["appusers"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=SampleDatabase;Integrated Security=True");
            con.Open();
            ds = new DataSet();             //select - For Data Retrieval             
            da = new SqlDataAdapter("select * from applicationusers", con);

            //So that we should be able to save changes back to database....             SqlCommandBuilder bld = new SqlCommandBuilder(da); 

            da.Fill(ds, "appusers");

            grdUsers.DataSource = ds.Tables["appusers"];

        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            ds.Tables["appusers"].RejectChanges();
        }

        private void btn_RowState_Click(object sender, EventArgs e)
        {
            //Iterate through Rows of DataTable and display RowStates ..... 

            foreach (DataRow drow in ds.Tables["appusers"].Rows)
            {
                if (drow.RowState == DataRowState.Deleted)
                {
                    MessageBox.Show(drow["username", DataRowVersion.Original].ToString() + " deleted ");
                }
                else
                    MessageBox.Show(drow["username"].ToString() + "  " + drow.RowState.ToString());
            }
        }
    }
}
