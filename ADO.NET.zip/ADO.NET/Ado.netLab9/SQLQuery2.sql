Use Training

Create Table accmaster(
	accno int primary key, 
	accname varchar(30),
	accbal numeric(10,2) check(accbal >= 5000)
)

Create Table acctran(
	tranno int identity primary key,
	accno int references accmaster,
	trtype varchar(1),
	tramt numeric(10,2) check(tramt >= 500)
)

insert into accmaster values(1,'anand',50000)
insert into accmaster values(2,'milind',50000)