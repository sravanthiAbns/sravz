﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Lab9TransactionDemo {
    public partial class Form1 : Form {
        SqlConnection conn = null;
        SqlTransaction trans = null;
        public Form1() {
            InitializeComponent();
            string constr = ConfigurationManager.ConnectionStrings
                ["labdemoconnectstring"].ConnectionString;
            conn = new SqlConnection(constr);
            conn.Open();
        }

        private void UpdateBal(string accno, string trtype, double tranamt) {
            SqlCommand cmd_upd = new SqlCommand
            ("update accmaster set accbal = accbal + @amt where accno = @accno", conn);
            cmd_upd.Transaction = trans;
            cmd_upd.Parameters.Add("@amt", SqlDbType.Decimal);
            cmd_upd.Parameters.Add("@accno", SqlDbType.Int, 4);
            if (trtype.ToLower().Equals("w"))
                cmd_upd.Parameters["@amt"].Value = -1 * tranamt;
            else
                cmd_upd.Parameters["@amt"].Value = tranamt;
            cmd_upd.Parameters["@accno"].Value = accno;
            cmd_upd.ExecuteNonQuery();
        }

        private void SaveStatement(string accno, string trtype, double tranamt) {
            string constr = ConfigurationManager.ConnectionStrings
            ["labdemoconnectstring"].ConnectionString;
            SqlCommand cmd_ins = new SqlCommand
            ("insert into acctran values(@accno,@trtype,@tramt)", conn);
            cmd_ins.Transaction = trans;
            cmd_ins.Parameters.Add("@tramt", SqlDbType.Money, 4);
            cmd_ins.Parameters.Add("@accno", SqlDbType.Int, 4); cmd_ins.Parameters.Add("@trtype", SqlDbType.VarChar, 1);
            cmd_ins.Parameters["@accno"].Value = accno;
            cmd_ins.Parameters["@tramt"].Value = tranamt;
            cmd_ins.Parameters["@trtype"].Value = trtype;
            cmd_ins.ExecuteNonQuery();
        }

        private void saveButton_Click(object sender, EventArgs e) {
            if (!transTypeTextBox.Text.ToLower().Equals("w") && !transTypeTextBox.Text.ToLower().Equals("d")) {
                MessageBox.Show("Transaction type should be 'W' or 'D' ");
                return;
            }
            trans = conn.BeginTransaction();
            try {
                UpdateBal(accNoTextBox.Text, transTypeTextBox.Text, double.Parse(amountTextBox.Text));
                SaveStatement(accNoTextBox.Text, transTypeTextBox.Text, double.Parse(amountTextBox.Text));
                MessageBox.Show("Transaction Saved");
                trans.Commit();
            } catch (SqlException sqlex) {
                trans.Rollback();
                MessageBox.Show(sqlex.Message);
            } finally {
                trans = null;
            }
        }
    }
}
