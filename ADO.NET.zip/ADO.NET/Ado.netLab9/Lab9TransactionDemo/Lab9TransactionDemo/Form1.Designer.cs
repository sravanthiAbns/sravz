﻿namespace Lab9TransactionDemo {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.accountNoLabel = new System.Windows.Forms.Label();
            this.transTypeLabel = new System.Windows.Forms.Label();
            this.amountLabel = new System.Windows.Forms.Label();
            this.accNoTextBox = new System.Windows.Forms.TextBox();
            this.transTypeTextBox = new System.Windows.Forms.TextBox();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // accountNoLabel
            // 
            this.accountNoLabel.AutoSize = true;
            this.accountNoLabel.Location = new System.Drawing.Point(13, 13);
            this.accountNoLabel.Name = "accountNoLabel";
            this.accountNoLabel.Size = new System.Drawing.Size(64, 13);
            this.accountNoLabel.TabIndex = 0;
            this.accountNoLabel.Text = "Account No";
            // 
            // transTypeLabel
            // 
            this.transTypeLabel.AutoSize = true;
            this.transTypeLabel.Location = new System.Drawing.Point(13, 37);
            this.transTypeLabel.Name = "transTypeLabel";
            this.transTypeLabel.Size = new System.Drawing.Size(90, 13);
            this.transTypeLabel.TabIndex = 1;
            this.transTypeLabel.Text = "Transaction Type";
            // 
            // amountLabel
            // 
            this.amountLabel.AutoSize = true;
            this.amountLabel.Location = new System.Drawing.Point(16, 63);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(43, 13);
            this.amountLabel.TabIndex = 2;
            this.amountLabel.Text = "Amount";
            // 
            // accNoTextBox
            // 
            this.accNoTextBox.Location = new System.Drawing.Point(132, 10);
            this.accNoTextBox.Name = "accNoTextBox";
            this.accNoTextBox.Size = new System.Drawing.Size(100, 20);
            this.accNoTextBox.TabIndex = 3;
            // 
            // transTypeTextBox
            // 
            this.transTypeTextBox.Location = new System.Drawing.Point(132, 34);
            this.transTypeTextBox.Name = "transTypeTextBox";
            this.transTypeTextBox.Size = new System.Drawing.Size(100, 20);
            this.transTypeTextBox.TabIndex = 4;
            // 
            // amountTextBox
            // 
            this.amountTextBox.Location = new System.Drawing.Point(132, 60);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(100, 20);
            this.amountTextBox.TabIndex = 5;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(132, 104);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 6;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(this.transTypeTextBox);
            this.Controls.Add(this.accNoTextBox);
            this.Controls.Add(this.amountLabel);
            this.Controls.Add(this.transTypeLabel);
            this.Controls.Add(this.accountNoLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label accountNoLabel;
        private System.Windows.Forms.Label transTypeLabel;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.TextBox accNoTextBox;
        private System.Windows.Forms.TextBox transTypeTextBox;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.Button saveButton;
    }
}

