﻿using System;
using csharpfirstlib;

namespace NewConsoleApp
{
    class Program
    {
        //
        /*
         */
         /// <summary>
         /// 
         /// </summary>
         /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine(CSharpFirstClass.madd(100, 200));
            Console.WriteLine("My first program");
        }
    }
}
