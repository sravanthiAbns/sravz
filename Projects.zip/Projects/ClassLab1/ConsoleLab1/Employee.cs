﻿using System;


namespace ConsoleLab1
{
    class Employee
    {
        static void Main(string[] args)
        {
            int EmployeeID;
            string EmployeeName, Address, City, Dept;
            float sal;
            Console.WriteLine("Enter the employeeID:");
            EmployeeID = Convert.ToInt32(Console.ReadLine());
           public int EmployeeiD
        {
            get
            { return this.; }
            set { _adharid = value; }
        }

        EmployeeName = (Console.ReadLine());

            Console.WriteLine("Enter the address");
            Address = Console.ReadLine();

            Console.WriteLine("Enter the citty:");
            City = Console.ReadLine();

            Console.WriteLine("Enter the Dept:");
            Dept = Console.ReadLine();

            Console.WriteLine("Enter the sal:");
            sal = Convert.ToSingle(Console.ReadLine());


        }
    }
}
