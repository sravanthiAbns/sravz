﻿using System;


namespace ClassLab1
{
    public class Employee
    {
        static void Main(string[] args)
        {
            int EmployeeID;
            string EmployeeName, Address, City, Dept;
            float sal;
            


        }


   
    }
}
