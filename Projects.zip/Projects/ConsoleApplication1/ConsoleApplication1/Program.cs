﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ConsoleApplication1
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    class AuthorAttribute : Attribute
    {
        string _author;

        public AuthorAttribute(string author)
        {
            _author = author;
        }

        public string AuthorName
        {
            get
            {
                return _author;
            }
        }
    }

    [Author("sravs")]
       
    class Student
    {

    }
        
    
        class Program
    {


        static void Main(string[] args)
        {
            Type type= typeof(Student);
           // Console.WriteLine(type.IsAbstract);
            // Console.WriteLine(type.IsClass);
           // PropertyInfo[] pi = type.GetProperties();
            
            object[] attr =type.GetCustomAttributes(typeof(AuthorAttribute), false);
            foreach(object o in attr)
            {
                Console.WriteLine(((AuthorAttribute)o).AuthorName);
            }
            Console.ReadLine();
        }
    }
}
