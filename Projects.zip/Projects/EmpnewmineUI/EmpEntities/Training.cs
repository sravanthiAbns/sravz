﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpEntities
{
    public class Training
    {
        public string Location { get; set; }
        public int TrainingID { get; set; }
        public string Skill { get; set; }
        public int Days { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }


    }
}
