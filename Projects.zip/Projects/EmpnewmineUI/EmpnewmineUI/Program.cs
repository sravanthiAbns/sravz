﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpEntities;

namespace EmpnewmineUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Training> lobj = new List<Training>();
            Training[] trobj = new Training[1];

            for(int counter=0; counter<trobj.Length; counter++)
            {
                Console.WriteLine("Enter Location.");
                trobj[counter].Location = Console.ReadLine();
                Console.WriteLine("Enter training id.");
                trobj[counter].TrainingID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter skill.");
                trobj[counter].Skill = Console.ReadLine();
                Console.WriteLine("Enter Days");
                trobj[counter].Days = Convert.ToInt32(Console.ReadLine());


            }
        }
    }
}
