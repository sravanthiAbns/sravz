﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpEntities;
using System.Text.RegularExpressions;
namespace EmpBAL
{
    public class BusiAccesLayr
    {
        
        private static bool ValidateDetails(Training emp)
        {
            StringBuilder sb = new StringBuilder();
            bool detvalid = true;
            if (emp.Location == string.Empty)
            {
                detvalid = false;
                sb.Append(Environment.NewLine + "Invalid Loaction");
            }
            if (emp.Location == string.Empty)
            {
                detvalid = false;
                sb.Append(Environment.NewLine + "Invalid Loaction");
            }
            else if (emp.TrainingID <0)
            {
                detvalid = false;
                sb.Append(Environment.NewLine + "Invalid Training ID");
            }
            else if (Regex.IsMatch(emp.Skill, @"Dotnet") == false)
            {
                detvalid = false;
                sb.Append(Environment.NewLine + "Invalid Training ID");
            }
        }


}
}
