﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace ReflectionsAPIEX
{
    class Program
    {
        static void Main(string[] args)
        {
            //@ is instead of two doubles 
            Assembly asmobj = Assembly.LoadFile(@"c:\users\bakula\documents\visual studio 2015\Projects\ReflectionsAPIEX\ReflectionsAPIEX\");
            Type[] tobj = asmobj.GetTypes();
            foreach(var titem in tobj)
            {
                Console.WriteLine("Classes in the libvrary are:{0}", titem.Name);
                Console.WriteLine("-----");
                MethodInfo[] mobj = titem.GetMethods();
                foreach(var mitem in mobj)
                {
                    Console.WriteLine("Methods inn the ckass are: {0} ", mitem.Name);
                }
            }

        }
    }
}
