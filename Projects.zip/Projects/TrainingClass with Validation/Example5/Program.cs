﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5
{
    class Program {
        static void Main(string[] args) {
            Training[] training = new Training[2];
            for(int index=0;index<2;index++) {
                training[index] = new Training();
                Console.WriteLine(DateTime.Now.ToString());
                Console.Write("Enter Location: ");
                training[index].LOCATION = Console.ReadLine();
                Console.Write("Enter Skill(DotNet, Java, Testing): ");
                string skillInput = Console.ReadLine();
                if (skillInput.Equals("DotNet")) {
                    training[index].SKILL = Training.Skills.DotNet;
                } else if (skillInput.Equals("Java")) {
                    training[index].SKILL = Training.Skills.Java;
                } else if (skillInput.Equals("Java")) {
                    training[index].SKILL = Training.Skills.Testing;
                }
                Console.Write("Enter Days: ");
                training[index].DAYS = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter Starting Date in (mm/dd/yyyy): ");
                training[index].START_DATE = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Ending Date in (mm/dd/yyyy): ");
                training[index].END_DATE = Convert.ToDateTime(Console.ReadLine());
            }
            
            for(int index=0;index<2;index++)
            {
                Console.WriteLine("Location: " + training[index].LOCATION);
                Console.WriteLine("Training ID: " + training[index].TRAINING_ID);
                Console.WriteLine("Skill: " + training[index].SKILL);
                Console.WriteLine("Days: " + training[index].DAYS);
                Console.WriteLine("Start Date: " + training[index].START_DATE);
                Console.WriteLine("End Date: " + training[index].END_DATE);
            }
        }
    }
}
