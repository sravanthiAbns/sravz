﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethods
{
    public class CMaths
    {
        public int add(int num1, int num2= 30)
        {
            return num1 + num2;
        }
    }
}
