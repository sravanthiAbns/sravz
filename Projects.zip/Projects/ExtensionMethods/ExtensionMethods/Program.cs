﻿using System;


namespace ExtensionMethods
{
    public class person
    {
        public int PERSONID { get; set; }

        public string PERS_NAME { get; set; }

        public int AGE { get; set; }
    }
    public static class StringExtensionsClass
    {
        public static string RemoveNonNumeric(this string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
                if (Char.IsNumber(s[i]))
                    sb.Append(s[i]);
            return sb.ToString();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<person> listobj = new List<person>();
            listobj.Add(new person { PERSONID = 1,PERS_NAME="shlok",AGE=43 });
            foreach (person item in listobj)
            {
                Console.WriteLine(item.PERSONID);
                Console.WriteLine(item.PERS_NAME);
                Console.WriteLine(item.AGE);
            }
            int num = 50;
            CMaths mathobj = new CMaths();
           
         
            string str = "abc1234";
            Console.WriteLine(str.RemoveNonNumeric());

        }
    }
}

