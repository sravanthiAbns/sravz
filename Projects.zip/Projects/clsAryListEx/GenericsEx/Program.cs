﻿using System;
using System.Collections.Generic;

namespace GenericsEx
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Values as Number");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second values as number");
                int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Values Before Swap num1:{0}, num2:{1}",num1,num2);
            swap<int>(ref num1, ref num2);
            Console.WriteLine("Values after Swap num1:{0}, num2:{1}", num1, num2);
            Console.WriteLine("Enter First values as string");
            string str1 = Console.ReadLine();
            Console.WriteLine("Enter second values as string");
            string str2 = Console.ReadLine();
            Console.WriteLine("Values before swap str1:{0},str2:{1}", str1, str2);
            swap<string>(ref str1, ref str2);
            Console.WriteLine("Values after swap str1:{0},str2:{1}", str1, str2);
        }
        static void swap<T>(ref T num,ref T num1) {
            T temp;
            temp = num;
                num = num1;
            num1 = temp;
        }
    }
}
