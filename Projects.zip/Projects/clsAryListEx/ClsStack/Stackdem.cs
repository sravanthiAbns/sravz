﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsStack
{
    public class Stackdem<T>
    {
        T[] items;
        int count;
        int capacity;

        public void Push(T item) {
            if(count)
        }
        public T Pop() { ...}
        static void Main(string[] args)
        {
        }
    }
}
