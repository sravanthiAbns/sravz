﻿using System;
using System.Collections;


namespace clsAryListEx
{
    class SampleArrayList
    {
        static void Main(string[] args)
        {
            ArrayList myAl = new ArrayList();
            myAl.Add("One");
            myAl.Add("Two");
            myAl.Add("!");
            myAl.Add(20);
            //Displays the properties and values of he arraylist
            Console.WriteLine("\tCount: {0}", myAl.Count);
            Console.WriteLine("\tCapacity: {0}", myAl.Capacity);
            Console.WriteLine("\tValues:");
            foreach(var item in PrintValues(myAl))
            {
                Console.WriteLine(item.ToString());
            }
            Console.Read();
        }
        public static IEnumerable PrintValues(ArrayList myList)
        {
            foreach(var item in myList)
            {
                yield return item;
            }
        }

       /* public static void PrintValues(IEnumerable myList)
        {
            IEnumerator myEnumerator = myList.GetEnumerator();
            while (myEnumerator.MoveNext())
            {
                Console.WriteLine("\t{0}", myEnumerator.Current);
            }
            Console.WriteLine();
        }*/

    }
}
