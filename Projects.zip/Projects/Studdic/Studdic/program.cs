﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using System.Runtime.Serialization.Formatters.Binary;

namespace Studdic
{

    [Serializable]
    enum Gender { Male, Female }
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Standard { get; set; }
        public Gender gender {get; set;}
    
    }
    class program
    {

        static void Main(string[] args)
        {
            List<Student> students =
                new List<Student>()
            {
                new Student {StudentID=1, StudentName="abc", gender=Gender.Female, Standard=11 },
                new Student {StudentID=2, StudentName="gfh", gender=Gender.Female, Standard=10 },
                new Student {StudentID=3, StudentName="gj", gender=Gender.Male, Standard=9 }


            };
            Dictionary<Gender, double> percentages = new Dictionary<Gender, double>();
            double countmale = 0, countfemale = 0;
            double permale = 0.0, perfemale = 0.0;

            foreach (Student s in students)
            {
                if (s.gender == Gender.Male)
                {
                    countmale++;
                }
                else
                {
                    countfemale++;
                }

            }

            permale = countmale / students.Count * 100;
            perfemale = countfemale / students.Count * 100;
            percentages.Add(Gender.Male, permale);
            percentages.Add(Gender.Female, perfemale);

            foreach (KeyValuePair<Gender, double> kv in percentages)
            {
                Console.WriteLine("Gender {0} percentages {1}", kv.Key, kv.Value);
            }
            Console.ReadLine();
            



 
            FileStream fileStream = new FileStream("d:\\serialize.txt", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, students);
            fileStream.Flush();
            fileStream.Close();

            fileStream = new FileStream("d:\\serialize.txt", FileMode.Open);
            List<Student> list = (List<Student>)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();
            foreach (Student item in list)
            {
                Console.WriteLine(item.StudentID);
                Console.WriteLine(item.StudentName);
                Console.WriteLine(item.Standard);
                Console.WriteLine(item.gender);

            }
        }
        }

        
    }

//    List<Student> list= (List<Student>)