﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


namespace serialization
{
    [Serializable]

    public class Student : IDeserializationCallback
    {
        #region Property
        public int STUDENTID { get; set; }
        public string STUDENTNAME { get; set; }
        public int STANDARD { get; set; }
        public Gender GENDER { get; set; }
        #endregion
        public enum Gender { Male, Female }

        public void OnDeserialization(object sender)
        {
            //throw new NotImplementedException();

        }


    }

    class Program
    {
        static void Main(string[] args)
        {
            Student obj = new Student();

            Console.WriteLine("Student Id is");
            obj.STUDENTID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Student Name is", obj.STUDENTNAME);
            obj.STUDENTNAME = Console.ReadLine();

            Console.WriteLine("Standard is", obj.STANDARD);
            obj.STANDARD = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Gender is", obj.GENDER);
            obj.GENDER = (Student.Gender)Convert.ToInt32(Console.ReadLine());

            SerializeData(obj);
            //Deserialization
            Student empobj1 = DeserializeData();

            Console.WriteLine("Student Id is :{0}", obj.STUDENTID);
            Console.WriteLine("Student Name is :{0}", obj.STUDENTNAME);
            Console.WriteLine("Standard is :{0}", obj.STANDARD);
            Console.WriteLine("Gender is :{0}", obj.GENDER);

            Console.ReadKey();
        }

        private static void SerializeData(Student obj)
        {
            FileStream fileStream = new FileStream(@"d:\\serialize1.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, obj);
            fileStream.Close();
        }

        private static Student DeserializeData()
        {
            FileStream fileStream = new FileStream(@"d:\\serialize1.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            Student obj1 = (Student)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();
            return obj1;
        }

    }
}
