﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleStack
{
    class Emp: IComparable<Emp>
    {
        public string EName { get; set; }
        public int Salary { get; set; }
        public int CompareTo(Emp other)
        {
            if (this.Salary > other.Salary)
                return -1;
            else if (this.Salary < other.Salary)
                return 1;
            else
                return 0;
        }
    }
    class MyStack<T>: Stack<T> { }
    class Program
    {
        static void Main(string[] args)
        {
            List<Emp>

            //MyStack<string> cities = new MyStack<string>();
            //cities.Push("Delhi");
            //cities.Push("Mumbai");
            //cities.Push("chenmalhi");
            //cities.Push("bangloeri");
            //foreach(string s in cities)
            //{
            //    Console.WriteLine();
            //}
            //Console.WriteLine(cities.Contains("Mumbai"));
            //Console.WriteLine(cities.Count);
            //Console.ReadLine();

        }
    }
}
