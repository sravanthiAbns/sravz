﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mathlib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Mathlib.Tests
{
    [TestClass()]
    public class MymathTests
    {
        [TestMethod()]
        public void DosumTest()
        {
            int actual = 0;
            int expected = 30;
            Mymath obj = new Mymath();
            actual = obj.Dosum(4, 5, 6, 7, 8);
            Assert.AreEqual(actual, expected);
        }
    }
}