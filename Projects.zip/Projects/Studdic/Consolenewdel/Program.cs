﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mathlib;

namespace Consolenewdel
{
    delegate int mathdel(params int[] array);
    class Program
    {
        static void Main(string[] args)
        {
            Mymath obj = new Mymath();
            Console.WriteLine(obj.Dosum(4, 5, 6, 7, 8));
            mathdel del = obj.Dosum;
            del(4, 5, 6, 7, 8);
            Console.ReadLine();
        }
    }
}
