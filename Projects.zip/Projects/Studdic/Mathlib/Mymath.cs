﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mathlib
{
    public class Mymath
    {
        public int Dosum(params int[] numarray)
        {
            int sum = 0;
            foreach (int i in numarray)
            {
                sum += i;

            }
            return sum;
        }
    }
}
