﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace ConsoleSoapserl
{
    [Serializable]

    public class Employee 
    {
        public int EMPID { get; set; }
        public string EMPNAME { get; set; }

        public int AGE { get; set; }

        [NonSerialized]
        public string EMAILID;

        public void OnDeserialization(object sender)
        {
            //thrwo new not implemented exception
            EMAILID = "a@gmial.com";
            AGE = 30;
        }

    }
    class Program
    {

        static void Main(string[] args)
        {
            Employee empobj = new Employee();
            Console.WriteLine("Employee Id is: ", empobj.EMPID);
            empobj.EMPID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Employee Name is:", empobj.EMPNAME);
            empobj.EMPNAME = Console.ReadLine();
            Console.WriteLine("Employee Age is: ", empobj.AGE);
            empobj.AGE = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Employee Emial is:", empobj.EMAILID);
            empobj.EMAILID = Console.ReadLine();
            SerializeData(empobj);

            //Deserialization
            DeserializeData();
            Employee empobj1 = DeserializeData();
            Console.WriteLine("EmployeeID is: {0}", empobj1.EMPID);
            Console.WriteLine("Employee Name is: {0}", empobj1.EMPNAME);
            Console.WriteLine("Employee Age  is: {0}", empobj1.AGE);
            Console.WriteLine("Employee Age  is: {0}", empobj1.EMAILID);
            Console.ReadKey();
        }
        private static void SerializeData(Employee empobj)
        {
            //FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            FileStream fileStream = new FileStream("d:\\ser.xml", FileMode.Create);
            SoapFormatter soapobj = new SoapFormatter();
            soapobj.Serialize(fileStream, empobj);
            // BinaryFormatter binaryFormatter = new BinaryFormatter();
            //binaryFormatter.Serialize(fileStream, DateTime.Now);
            //binaryFormatter.Serialize(fileStream, empobj);
            fileStream.Close();
        }

        private static Employee DeserializeData()
        {
            bool flag = false;
            FileStream fileStream = new FileStream("d:\\ser.xml", FileMode.Open);

            // BinaryFormatter binaryFormatter = new BinaryFormatter();
            //DateTime dt = (DateTime)binaryFormatter.Deserialize(fileStream);
           // Employee empobj1 = (Employee)binaryFormatter.Deserialize(fileStream);
           // binaryFormatter.Serialize(fileStream, empobj1);
           // fileStream.Close();
           // Console.WriteLine(empobj1.ToString());
           // return empobj1;
        }
    }
}

