﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankBEntity
{
    public class CAccountEnt
    {
        #region Field


        #endregion

        #region Property
        public int ACCOUNTNO { get; set; }
        public string ACC_HOLD_NAME { get; set; }
        public string ACC_TYPE { get; set; }
        public string TRANS_TYPE { get; set; }
        public decimal  AMOUNT { get; set; }

        //public decimal BALANCE { get; private set; }
        #endregion

        #region Methods


        #endregion

        #region Constructor
        public CAccountEnt()
        {
            //BALANCE = AMOUNT;

        }
        public CAccountEnt(int accno,string name, string acctype, string transtype, decimal amt)
        {
            ACCOUNTNO = accno;
            ACC_HOLD_NAME = name;
            ACC_TYPE = acctype;
            TRANS_TYPE = transtype;
            AMOUNT = amt;
            //BALANCE = AMOUNT;

        }
        #endregion

    }
}
