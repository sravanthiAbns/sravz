﻿using System;
using BankBEntity;


namespace BankClassLiB
{
    public delegate void Onbalchange(CAccountEnt accobj);
    public class CSavingAccounts:CAccounts, ICalcInterest 
    {
        #region Field
        private decimal _balance;
        // Event Handler
        public event Onbalchange onbalchnage ;
        #endregion

        #region Property
        public decimal BALANCE { get { return _balance; } }

       

        #endregion

        #region Methods

        public override void mDeposit(BankBEntity.CAccountEnt accobj)
        {
            _balance += accobj.AMOUNT;
          
            if (onbalchnage != null)
            {
                onbalchnage(accobj);
            }

        }

        public override void mWithDraw(BankBEntity.CAccountEnt accobj)
        {
            if (_balance > 5000)
            {
                _balance += _balance;
            }
            else
            {
                throw new InsufficientFundException("You have In sufficient funds in your account");
            }
            

        }

        public decimal interestcalc(int time, float rate, decimal amt)
        {
            return ((decimal)time * (decimal)rate * amt);
        }
        public static void SMSAlert(CAccountEnt accentobj)
        {
            Console.WriteLine("SMS Alert");
            Console.WriteLine("Account No (0) has change in bsalance",accentobj.ACCOUNTNO);
        }
        #endregion

        #region Constructor
        public CSavingAccounts(CAccountEnt entobj)
        {
            _balance = entobj.AMOUNT;
        }


        #endregion
    }
}
