﻿using System;
using BankBEntity;


namespace BankClassLiB
{
    public class CSavingAccounts:CAccounts, ICalcInterest 
    {
        #region Field
        private decimal _balance;

        #endregion

        #region Property
        public decimal BALANCE { get { return _balance; } }

       

        #endregion

        #region Methods

        public override void mDeposit(BankBEntity.CAccountEnt accobj)
        {
            _balance += accobj.AMOUNT;

        }

        public override void mWithDraw(BankBEntity.CAccountEnt accobj)
        {
            if (_balance > 5000)
            {
                _balance += _balance;
            }
            else
            {
                throw new InsufficientFundException("You have In sufficient funds in your account");
            }
            

        }

        public decimal interestcalc(int time, float rate, decimal amt)
        {
            return ((decimal)time * (decimal)rate * amt);
        }
        #endregion

        #region Constructor
        public CSavingAccounts(CAccountEnt entobj)
        {
            _balance = entobj.AMOUNT;
        }


        #endregion
    }
}
