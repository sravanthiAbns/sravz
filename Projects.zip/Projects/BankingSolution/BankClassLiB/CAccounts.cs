﻿using System;
using BankBEntity;

namespace BankClassLiB
{
    public abstract class CAccounts
    {
        
        #region Field
        // private decimal _balance;

        #endregion

        #region Property
        // public decimal BALANCE { get { return _balance; } }

        #endregion

        #region Methods
        public abstract void mDeposit(CAccountEnt accobj);
        public abstract void mWithDraw(CAccountEnt accobj);

        #endregion

        #region Constructor


        #endregion

    }
    }
    
