﻿using System;

namespace BankClassLiB
{
    public class InsufficientFundException: ApplicationException
    {
        #region Constructor
        public InsufficientFundException() : base()
        {


        }
        public InsufficientFundException(string message): base(message)
        {


        }
        
        public InsufficientFundException(string message,Exception innerException): base(message , innerException)
        {
           
        }
        #endregion
    }
}
