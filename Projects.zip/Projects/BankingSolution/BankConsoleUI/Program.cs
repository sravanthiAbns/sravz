﻿using System;
using BankBEntity;
using BankClassLiB;
using System.Collections.Generic;
using System.IO;

namespace BankConsoleUI
{
    class Program
    {
        static void EmailAlert(CAccountEnt entobj)
        {
            Console.WriteLine("Your balance has been changed");
        }
        static void Main(string[] args)
        {
            List<CAccountEnt> listobj = new List<CAccountEnt>();
            CAccountEnt[] accentobj = new CAccountEnt[1];
            for(int counter = 0; counter < accentobj.Length; counter++)
            {
                accentobj[counter] = new CAccountEnt();
            }
            for (int counter = 0; counter < accentobj.Length; counter++)
            {
                Console.WriteLine("Enter account number");
                accentobj[counter].ACCOUNTNO = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter account holder name");
                accentobj[counter].ACC_HOLD_NAME = Console.ReadLine();
                Console.WriteLine("Enter account type");
                accentobj[counter].ACC_TYPE = Console.ReadLine();
                Console.WriteLine("Enter Transaction type");
                accentobj[counter].TRANS_TYPE = Console.ReadLine();
                Console.WriteLine("Enter amount");
                accentobj[counter].AMOUNT = Convert.ToDecimal(Console.ReadLine());
            }

            listobj.AddRange(accentobj);
            foreach(var item in listobj)
            {
                Console.WriteLine("Account No is {0} ", item.ACCOUNTNO);
                Console.WriteLine("Account name is {0} ", item.ACC_HOLD_NAME);
                Console.WriteLine("Account type is {0}", item.ACC_TYPE);
                Console.WriteLine("Account tarnsactiontype is {0}", item.TRANS_TYPE);
                Console.WriteLine("Account amount is {0}", item.AMOUNT);
                //Console.WriteLine("Account type is {0}", item.BALANCE);
            }

            // File input output streams

            FileStream fileStream01 = new FileStream("d:\\test.txt", FileMode.Append, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(fileStream01);
            foreach(var item in accentobj)
            {
                streamWriter.Write(item.ACCOUNTNO);
                streamWriter.Write(item.ACC_HOLD_NAME);
                streamWriter.Write(item.ACC_TYPE);
                streamWriter.Write(item.TRANS_TYPE);
                streamWriter.Write(item.AMOUNT);

            }


            FileStream fileStream02 = new FileStream("d:\\test.txt", FileMode.Open, FileAccess.Read);
            StreamReader streamReader = new StreamReader(fileStream02);
            CAccountEnt accentobj1 = streamReader.

            CSavingAccounts accobj = new CSavingAccounts(accentobj[0]);

            //email alert using event
            accobj.onbalchnage += new Onbalchange(EmailAlert);

            Console.WriteLine(accobj.BALANCE);
            accentobj[0].AMOUNT = 5000;
            try
            {
                accobj.mWithDraw(accentobj[0]);
            }
            catch(InsufficientFundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //accobj.mWithDraw(accentobj[0]);
            //Console.WriteLine(accentobj[0].BALANCE);
        }
    }
}
