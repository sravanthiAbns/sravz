﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace ReflectionsAPIEX
{
    class Calculation
    {
        public static int AddTwonumbers(int firstNumber,int secondNumber)
        {
            return firstNumber + secondNumber;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //@ is instead of two doubles 
            Assembly asmobj = Assembly.GetExecutingAssembly();
               // (@"C:\Users\bakula\Documents\Visual Studio 2015\Projects\BankingSolution\BankClassLiB\bin\Debug\BankClassLiB.dll");
            Type[] tobj = asmobj.GetTypes();
            foreach (var titem in tobj)
            {
                Console.WriteLine("Classes in the libvrary are:{0}", titem.Name);
                Console.WriteLine("-----");
                MethodInfo[] mobj = titem.GetMethods();
                foreach (var mitem in mobj)
                {
                    Console.WriteLine("Methods inn the ckass are: {0} ", mitem.Name);
                    Console.WriteLine("-----");
                    ParameterInfo[] probj = mitem.GetParameters();
                    foreach (var pritem in probj)
                    {
                        Console.WriteLine("Parameters in this method are : {0} and it's type is: {1}",pritem.Name,pritem.ParameterType);
                    }
                    PropertyInfo[] obj = titem.GetProperties();
                    Console.WriteLine("-----");
                    foreach (var pritem in probj)
                    {
                        Console.WriteLine("Propwerties i this class are : {0} and it's type",pritem.Name);
                    }
                }
            }

        }
    }
}

