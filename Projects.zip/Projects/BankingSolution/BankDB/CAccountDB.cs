﻿using System;


namespace BankDB
{
    public class CAccountDB
    {
        #region Field


        #endregion

        #region Property


        #endregion

        #region Methods


        #endregion

        #region Constructor


        #endregion

    }
}
