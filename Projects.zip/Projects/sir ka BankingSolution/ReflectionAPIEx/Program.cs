﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace ReflectionAPIEx
{
    class Calculation
    {
        public static int AddTwoNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
          // Assembly asmobj = Assembly.LoadFile(@"C:\Users\parkaur\Documents\Visual Studio 2012\Projects\BankingSolution\BankBEntities\bin\Debug\BankBEntities.dll");
          // Type[] tobj= asmobj.GetTypes();
            Assembly asmobj = Assembly.GetExecutingAssembly();
            Type[] tobj = asmobj.GetTypes();
           foreach (var titem in tobj)
           {
               Console.WriteLine("Classes in the Library are: {0}",titem.Name);
               Console.WriteLine("-------------------");
               MethodInfo[] mobj = titem.GetMethods();
               foreach (var mitem in mobj)
               {
                   Console.WriteLine("Methods in the class are: {0}",mitem.Name );
                   Console.WriteLine("-------------------------------------");
                   ParameterInfo[] probj = mitem.GetParameters();
                   foreach (var pritem in probj)
                   {
                       Console.WriteLine("Parameters in this method are:{0} and its type is:{1}",pritem.Name,pritem.ParameterType);
                   }
                   PropertyInfo[] pobj = titem.GetProperties();
                   foreach (var pitem in pobj)
                   {
                       Console.WriteLine("Properties in this class are:{0}",pitem.Name);
                   }

               }
           }


        }
    }
}
