﻿using System;


namespace BankClasslib
{
   public class NegativeBalanceException:ApplicationException
    {

        #region Constructor

       public NegativeBalanceException():base()
       {

       }

       public NegativeBalanceException( String message):base(message)
       {
            
       }

       public NegativeBalanceException(String message, Exception innerException): base(message, innerException)
       {

       }

        #endregion
    }
}
