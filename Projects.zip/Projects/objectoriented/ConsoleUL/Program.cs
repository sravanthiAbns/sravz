﻿using System;
using Encapsulation;
namespace ConsoleUL
{
   
        class Program
    {
        static void Main(string[] args)
        {
            int newage=30;
            int newnum1 = 30;
            int newnum2 = 40;
            CPerson perobj = new CPerson();
            CPerson persobj1 = new CPerson(231,"sravs",20);
        
            CPerson.Date1 dobj = new CPerson.Date1();
            dobj.Month = 13;
            Console.WriteLine("Month value:" + dobj.Month);
               
            Console.WriteLine("The sum of numbers are:"+CPerson.Sum(1,2,3));
            Console.WriteLine(persobj1.AADHARID);
            Console.WriteLine(persobj1.NAME);
            Console.WriteLine(persobj1.AGE);
     
            Console.WriteLine("The value of new age is" + newage);
           
            
            Console.WriteLine("Values  before swap are num1: {0},num2: {1}", newnum1, newnum2);
                CPerson.mSwap(num1:ref newnum1,num2:ref newnum2);
            Console.WriteLine("Values  after swap are num1: {0},num2: {1}", newnum1, newnum2);
      
        }
    }
}
