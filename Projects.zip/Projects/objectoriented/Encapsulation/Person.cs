﻿using System;


namespace Encapsulation 
{
    public class CPerson
    {
        #region Field
        int _adharid;
        string _name;
        byte _age;

        #endregion
        public static int Sum(params int[] param1)
        {
            int val = 0;
            foreach(int P in param1)
            {
                val = val + P;
            }
            return val;

        }
        
        #region Property

        public int AADHARID
        {
            get
            { return _adharid; }
            set { _adharid = value; }
        }
        public string NAME
        {
            get { return _name; }
          
        }
        public byte AGE
        {
            get { return _age; }
        
        }
        public string EMAILID { get; private set; }
        #endregion
        #region Method
        [Obsolete ("THis method is not available in next version")]
        public void mage(out int age)
        {
            age = 100;
            Console.WriteLine("age is{0} ", _age);
        }
        public static void mSwap(ref int num1,ref int num2)
        {
            //int temp;
            //temp = num1;
            //num1 = num2;
            //num2 = temp;
            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
        }
        #endregion
        #region Constructor
        public CPerson()
        {

        }
        public class Date1
        {
            private int month;
            public int Month
            {
                get { return month; }
                set
                {
                    if ((value > 0) && (value < 13))
                    {
                        month = value;
                    }


                }

            }
        }
        public CPerson(int adharid, string name, byte age)
        {
            this._adharid = adharid;
            this._age = age;
            this._name = name;

            #endregion
        }
    }
}
