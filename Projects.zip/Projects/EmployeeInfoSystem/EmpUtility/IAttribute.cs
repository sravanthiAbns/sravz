﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    public interface IAttribute
    {
        string _errormessage { get; set; }
        bool IsValid(object item);
    }
}
