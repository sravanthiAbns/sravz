﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Field|AttributeTargets.Property,AllowMultiple =true)]
    public class CheckRange: Attribute, IAttribute
    {
        public string errorMessage;
        int maxval, minval;
        public CheckRange(int maxval,int minval,string errmsg)
        {
            this.maxval = maxval;
            this.minval = minval;
            _errormessage= errmsg;

        }

        #region IAttribute Members

        public string _errormessage
        {
            get
            {
                return errorMessage;
                //throw new not impolemented Exception
            }
            set
            {
                errorMessage = value;
            }
        }

        public bool IsValid(object item)
        {
            bool flag=false;
            decimal basval = (decimal)item;
            if(basval<maxval && basval > minval)
            {
                flag = true;
            }

            return flag;
            //try
            //{
            //    string s = (string)item;
            //    if (s.Trim().Equals(String.Empty))
            //        result = false;
            //}
            //catch (InvalidCastException)
            //{
            //    result = false;
            //}
            //return result;
        }
        #endregion
    }
}

