﻿using System;


namespace EmpDAL
{
    public class Class1 { }
    
}


