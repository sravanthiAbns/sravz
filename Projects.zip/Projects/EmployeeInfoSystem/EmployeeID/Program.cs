﻿using System;
using System.Reflection;
using EmpEntity;
using EmpUtility;

namespace EmployeeID
{
    class Program
    {
        static void Main(string[] args)
        {
            PropertyInfo[] properties = Assembly.LoadFile(@"C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.Drawing.dll");
            foreach (Type t in assembly.GetTypes())
            {
                Console.WriteLine(t.Name);
            }

            Console.ReadKey();
        }
    }
}
