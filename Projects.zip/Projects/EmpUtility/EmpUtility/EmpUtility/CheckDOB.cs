﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Property)]
    class CheckDOB : Attribute, IAttribute
    {
        private string _errormessage;
        public CheckDOB(string errormessage)
        {
            _errormessage = errormessage;
        }
        public string Message
        {
            get
            {
                return _errormessage;
            }

            set
            {
                _errormessage = value; ;
            }
        }

        public bool isValid(object item)
        {
            bool flag = true;
            try
            {
                string s = (string)item;
                string subs = s.Substring(s.Length - 4);
                if (Convert.ToInt32(subs) > 1995)
                    flag = false;
                else
                    flag = true;
            }
            catch (InvalidCastException)
            {
                flag = false;
            }
            return flag;
        }
    }
}
