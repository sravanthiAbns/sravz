﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
   public class AttributeError
    {
        #region Fields
        private List<Error> _errorlist = new List<Error>();
        #endregion

        #region Property
        public List<Error> ERRORLIST { get {return _errorlist; } set { _errorlist = value;} }
        #endregion

    }
}
