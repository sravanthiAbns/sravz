﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Property)]
    class CheckBlank : Attribute, IAttribute
    {
        private string _errormessage;
        public CheckBlank(string errormessage)
        {
            _errormessage = errormessage;
        }

        public string Message
        {
           
            get
            {
                return _errormessage ;
            }

            set
            {
                _errormessage = value; ;
            }
        }

        public bool isValid(object item)
        {
            bool flag = true;
            try
            {
                string s = (string)item;
                if (s.Trim().Equals(string.Empty))
                    flag = false;
            }
            catch (InvalidCastException)
            {
                flag = false;
            }
            return flag;
        }
    }
}
