﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
   public class EmployeeeConditions : AttributeError
    {
        [CheckBlank("Employee ID is Required")]
        [CheckLength(6, 6, "Employee ID Must be 6 Characters")]
        public string EmployeeID { get; set; }

        [CheckBlank("Employee Name is Required")]
        [CheckLength(4, 10, "Employee Name must be between 4 to 10 characters")]
        [CheckUpper("Employee Name should be in UpperCase")]
        public string EmployeeName { get; set; }

        [CheckBlank("Employee Age is Required")]
        [CheckDOB("Employee year of DOB must be less than 1995")]
        public string EmployeeDOB { get; set; }
    }
}
