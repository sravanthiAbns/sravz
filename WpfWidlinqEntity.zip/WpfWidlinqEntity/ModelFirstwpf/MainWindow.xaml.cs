﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ModelFirstwpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
            ModelFirstApproachContainer context = new ModelFirstApproachContainer();




        private void btnCondSearch_Click(object sender, RoutedEventArgs e)
        {
            int param = Convert.ToInt32(textBox.Text);
            var result = from emp in context.Buses
                         where emp.Starttime.Year > param
                         select emp;

            dataGrid.ItemsSource = result.ToList();

        }

        private void btnSearc_Click(object sender, RoutedEventArgs e)
        {
            int busID = Convert.ToInt32(txtID.Text);
            var result = (from bus in context.Buses
                          where bus.Id == busID
                          select bus).FirstOrDefault();

            context.SaveChanges();
            //txtEmpName.Text = result.Employname;
            datepick.Text = result.Starttime.ToString();
            txtID.Text = Convert.ToString(result.Id);
            txtSalary.Text = result.Fare.ToString();

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Bus newEmp = new Bus();
            //newEmp.Employname = txtEmpName.Text;
            newEmp.Fare = Convert.ToDecimal(txtSalary.Text);
            newEmp.Starttime = Convert.ToDateTime(datepick.Text);
            context.Buses.Add(newEmp);
            context.SaveChanges();
            var result2 = from emp in context.Buses
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnGetAllDetails_Click(object sender, RoutedEventArgs e)
        {
            var result = from emp in context.Buses
                         select emp;
            dataGrid.ItemsSource = result.ToList();
            context.SaveChanges();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int tobeupdated = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.Buses
                          where emp.Id == tobeupdated
                          select emp).FirstOrDefault();
            //result.Employname = txtEmpName.Text;
            result.Fare = Convert.ToDecimal(txtSalary.Text);
            result.Starttime = Convert.ToDateTime(datepick.Text);
            context.SaveChanges();
            var result2 = from emp in context.Buses
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.Buses
                          where emp.Id == empID
                          select emp).FirstOrDefault();
            context.Buses.Remove(result);

            context.SaveChanges();

            var result2 = from emp in context.Buses
                          select emp;
            //dataGrid.ItemsSource = result2.ToList();
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void txtSalary_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
    }


