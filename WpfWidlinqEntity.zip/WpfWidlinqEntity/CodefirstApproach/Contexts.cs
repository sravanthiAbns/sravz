﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace CodefirstApproach
{
    class Contexts : DbContext
    {
        public Contexts() : base("DBConString") { }

        public DbSet<Eemployee> emp { get; set; }
    }
}
