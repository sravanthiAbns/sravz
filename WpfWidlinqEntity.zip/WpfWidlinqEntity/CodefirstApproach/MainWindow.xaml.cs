﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodefirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }
        Contexts context = new Contexts();


        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnCondSearch_Click(object sender, RoutedEventArgs e)
        {
            int param = Convert.ToInt32(textBox.Text);
            var result = from emp in context.emp
                         where emp.Startdate.Year > param
                         select emp;

            dataGrid.ItemsSource = result.ToList();

        }

        private void btnSearc_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.emp
                          where emp.EmployeID == empID
                          select emp).FirstOrDefault();

            context.SaveChanges();
            txtEmpName.Text = result.Employname;
            datepick.Text = result.Startdate.ToString();
            txtID.Text = Convert.ToString(result.EmployeID);
            txtSalary.Text = result.sal.ToString();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Eemployee newEmp = new Eemployee();
            newEmp.Employname = txtEmpName.Text;
            newEmp.sal = Convert.ToDouble(txtSalary.Text);
            newEmp.Startdate = Convert.ToDateTime(datepick.Text);
            context.emp.Add(newEmp);
            context.SaveChanges();
            var result2 = from emp in context.emp
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnGetAllDetails_Click(object sender, RoutedEventArgs e)
        {
            var result = from emp in context.emp
                         select emp;
            dataGrid.ItemsSource = result.ToList();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int tobeupdated = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.emp
                          where emp.EmployeID == tobeupdated
                          select emp).FirstOrDefault();
            result.Employname = txtEmpName.Text;
            result.sal = Convert.ToDouble(txtSalary.Text);
            result.Startdate = Convert.ToDateTime(datepick.Text);
            context.SaveChanges();
            var result2 = from emp in context.emp
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.emp
                          where emp.EmployeID == empID
                          select emp).FirstOrDefault();
            context.emp.Remove(result);

            context.SaveChanges();

            var result2 = from emp in context.emp
                          select emp;
            dataGrid.ItemsSource = result2.ToList();

        }

        private void txtSalary_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
