﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace CodefirstApproach
{
    class Eemployee
    {
        [Key]
        public int EmployeID { get; set; }
        public string Employname { get; set; }
        public double sal { get; set; }
        public DateTime Startdate { get; set; }
    }
}
