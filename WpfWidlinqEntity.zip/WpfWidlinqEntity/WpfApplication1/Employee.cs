namespace WpfApplication1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Employee")]
    public partial class Employee
    {
        [Key]
        [Column(TypeName = "numeric")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal EmployeID { get; set; }

        [StringLength(100)]
        public string EmployName { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? EmpSal { get; set; }

        [StringLength(100)]
        public string Emptype { get; set; }
    }
}
