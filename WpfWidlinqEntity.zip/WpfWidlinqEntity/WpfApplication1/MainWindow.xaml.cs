﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        trainingEntities context = new trainingEntities();

        private void btnCondSearch_Click(object sender, RoutedEventArgs e)
        {
            int param = Convert.ToInt32(textBox.Text);
            var result = from emp in context.Employees
                         where emp.EmpSal > param
                         select emp;

            dataGrid.ItemsSource = result.ToList();
        }

        private void btnSearc_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.Employees
                          where emp.EmployeID == empID
                          select emp).FirstOrDefault();

            context.SaveChanges();
            txtEmpName.Text = result.EmployName;
            txtEmptype.Text = result.Emptype;
            txtID.Text = Convert.ToString(result.EmployeID);
            txtSalary.Text = result.EmpSal.ToString();

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Employee newEmp = new Employee();
            newEmp.EmployName = txtEmpName.Text;
            newEmp.EmpSal = Convert.ToDecimal(txtSalary.Text);
            newEmp.Emptype = txtEmptype.Text;
            context.Employees.Add(newEmp);
            context.SaveChanges();
            var result2 = from emp in context.Employees
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnGetAllDetails_Click(object sender, RoutedEventArgs e)
        {
            var result = from emp in context.Employees
                         select emp;
            dataGrid.ItemsSource = result.ToList();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int tobeupdated = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.Employees
                          where emp.EmployeID == tobeupdated
                          select emp).FirstOrDefault();
            result.EmployName = txtEmpName.Text;
            result.EmpSal = Convert.ToDecimal(txtSalary.Text);
            result.Emptype = txtEmptype.Text;
            context.SaveChanges();
            var result2 = from emp in context.Employees
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(txtID.Text);
            var result = (from emp in context.Employees
                          where emp.EmployeID == empID
                          select emp).FirstOrDefault();
            context.Employees.Remove(result);

            context.SaveChanges();

            var result2 = from emp in context.Employees
                          select emp;
            dataGrid.ItemsSource = result2.ToList();
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
