﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LinqEntityLab
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        trainingEntities context = new trainingEntities();
        public MainWindow()
        {
            InitializeComponent();
        }
        // add
        private void button_Click(object sender, RoutedEventArgs e)
        {
            Employee newEmp = new Employee();
            newEmp.EmpID = Convert.ToInt32(textBox.Text);
            newEmp.EmpName = textBox1.Text;
            newEmp.DOB = Convert.ToDateTime(textBox2.Text);
            newEmp.DOJ = Convert.ToDateTime(textBox3.Text);
           
            newEmp.Designation = textBox4.Text;
            newEmp.Salary = Convert.ToDecimal(textBox5.Text);

            context.Employees.Add(newEmp);
            
            var result2 = from emp in context.Employees
                          select emp;
            context.SaveChanges();
            MessageBox.Show("Details added");

        }

        // update
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            int tobeupdated = Convert.ToInt32(textBox.Text);
            var result = (from emp in context.Employees
                          where emp.EmpID == tobeupdated
                          select emp).FirstOrDefault();
            result.EmpName = textBox1.Text;
            result.DOB = Convert.ToDateTime(textBox2.Text);
            result.DOJ = Convert.ToDateTime(textBox3.Text);
           
            result.Designation = textBox4.Text;
            result.Salary = Convert.ToDecimal(textBox5.Text);

            context.SaveChanges();
            MessageBox.Show("details updated successfully");
        }

        //search
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(textBox.Text);
            var result = (from emp in context.Employees
                          where emp.EmpID == empID
                          select emp).FirstOrDefault();

            context.SaveChanges();
           textBox1.Text = result.EmpName;
            textBox2.Text =  result.DOB.ToString();
            textBox3.Text = result.DOJ.ToString();
            textBox4.Text = result.Designation;
            textBox5.Text = result.Salary.ToString();
           

        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            int empID = Convert.ToInt32(textBox.Text);
            var result = (from emp in context.Employees
                          where emp.EmpID == empID
                          select emp).FirstOrDefault();
            context.Employees.Remove(result);

            context.SaveChanges();
            MessageBox.Show("details deleted successfully");
        }
    }
}
