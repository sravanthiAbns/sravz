﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace LINQEFConsoleApp
{
    class Program
    {

        static void Main(string[] args)
        {
            
            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddEmployee();
                            break;
                        
                        case 2:
                            SearchEmployee();
                            break;
                        case 3:
                            UpdateEmployee();
                            break;
                        case 4:
                            DeleteProduct();
                            break;
                        
                        case 5:
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                while (choice != 8);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
           
        }

        static void PrintMenu()
        {
            
            Console.WriteLine("\n1. Add Employee");
            Console.WriteLine("2. Search Employee");
            Console.WriteLine("3. Update Employee");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");
            Console.WriteLine();
        }
       

        static void AddEmployee()
        {
            try
            {
                Console.WriteLine("Enter Employee Id");
                var result2 = from emp in con
                              select emp;
            }
            catch
            {

            }
            return;
        }


    }

}

